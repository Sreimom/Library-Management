﻿Public Class FrmLibraryProcessing

    Private Sub refreshPictureBox1()
        If Not PictureBox1.IsDisposed Then
            ImageAnimator.UpdateFrames(PictureBox1.BackgroundImage)
            PictureBox1.Invalidate()
        End If
    End Sub

    Private Sub FrmStudentProcessing_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If ProgressBar1.Value = 0 Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If

    End Sub

    Private Sub FrmStudentProcessing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ImageAnimator.Animate(PictureBox1.BackgroundImage, AddressOf refreshPictureBox1)
        Me.Height = 235
        UseWaitCursor = True
        MaximizeBox = False
        MinimizeBox = False

    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value <= 95 Then
            ProgressBar1.Value += 1
        Else
            Timer1.Stop()
            ProgressBar1.Value = 100
            System.Media.SystemSounds.Asterisk.Play()
            Me.Height = 282
            UseWaitCursor = False
        End If
    End Sub

    Private Sub OkCButton_Click(sender As Object, e As EventArgs) Handles OkCButton.Click
        ProgressBar1.Value = 0
        Me.Close()
    End Sub
End Class