﻿Public Class FrmLibraryCancel

    Private Sub YesCloseButton_Click(sender As Object, e As EventArgs) Handles YesCloseButton.Click
        FrmLibraryAddBorrowUser.Close()
        FrmLibraryAddnew.Close()
        Me.Close()
    End Sub

    Private Sub NoCloseButton_Click(sender As Object, e As EventArgs) Handles NoCloseButton.Click
        Me.Close()
    End Sub

    Private Sub FrmLibraryCancel_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class