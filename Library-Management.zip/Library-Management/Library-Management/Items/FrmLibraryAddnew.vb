﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class FrmLibraryAddnew
    Private Sub frmaddnew_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LibraryAutoComplete.Categorys()
        LibraryAutoComplete.Languages()
        LibraryAutoComplete.Cabinets()
        LibraryAutoComplete.Shelfs()
    End Sub
    Private Sub IsEmpty()
        If TitleTextBox.Text = "" Then
            TitleLabel.ForeColor = Color.Red
            TitleTextBox.Focus()
        ElseIf AuthorTextBox.Text = "" Then
            AuthorLabel.ForeColor = Color.Red
            AuthorTextBox.Focus()
        ElseIf EidterTextBox.Text = "" Then
            EditerLabel.ForeColor = Color.Red
            EidterTextBox.Focus()
        ElseIf HowManyTextBox.Text = "" Then
            HowManyLabel.ForeColor = Color.Red
            HowManyTextBox.Focus()
        ElseIf HowMuchForSellTextBox.Text = "" Then
            HowMuchLabel.ForeColor = Color.Red
            HowMuchForSellTextBox.Focus()
        ElseIf HowMuchForBorrowTextBox.Text = "" Then
            HowMuchForBorrowLabel.ForeColor = Color.Red
            HowMuchForBorrowTextBox.Focus()
        Else
            TitleLabel.ForeColor = Color.Black
            AuthorLabel.ForeColor = Color.Black
            EditerLabel.ForeColor = Color.Black
            HowManyLabel.ForeColor = Color.Black
            HowMuchLabel.ForeColor = Color.Black
            HowMuchForBorrowLabel.ForeColor = Color.Black
        End If

    End Sub
    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        Call IsEmpty()
        If TitleTextBox.Text <> "" And AuthorTextBox.Text <> "" And EidterTextBox.Text <> "" And HowManyTextBox.Text <> "" And HowMuchForSellTextBox.Text <> "" And HowMuchForBorrowTextBox.Text <> "" Then

            FrmLibraryProcessing.Timer1.Start()
            FrmLibraryProcessing.Timer1.Enabled = True
            FrmLibraryProcessing.Timer1.Interval = 10

            Dim PicRename As String = TimeOfDay.ToString("hh-mm-ss")
            PicRename = Replace(PicRename, "-", "")
            If IsNothing(ItemsPictureBox.Image) Then
                PicRename = "Items.png"
            Else
                PicRename = PicRename & ".jpg"
                Dim path As String = Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Items\ " & PicRename)
                ItemsPictureBox.Image.Save(path, Drawing.Imaging.ImageFormat.Jpeg)
            End If


            CMDTextBox.Text = "INSERT INTO items " & _
                "(item_title" & _
                ", item_author" & _
                ", item_editer " & _
                ", item_publiser" & _
                ",lan_id" & _
                ",item_how_many" & _
                ",item_for_sell" & _
                ",item_for_borrow" & _
                ",item_pic" & _
                ",cat_id" & _
                ",cab_id" & _
                ",she_id" & _
                ",note" & _
                ",user_id) value  " & _
                "('" & TitleTextBox.Text & _
                "','" & AuthorTextBox.Text & _
                "','" & EidterTextBox.Text & _
                "','" & PubliserDateTimePicker.Text & _
                "','" & LanguageComboBox.SelectedValue & _
                "','" & HowManyTextBox.Text & _
                "','" & HowMuchForSellTextBox.Text & _
                "','" & HowMuchForBorrowTextBox.Text & _
                "','" & PicRename & _
                "','" & CategoryComboBox.SelectedValue & _
                "','" & CabComboBox.SelectedValue & _
                "','" & SheComboBox.SelectedValue & _
                "','" & NoteTextBox.Text & _
                "','" & FrmLibraryMain.IDToolStripLabel.Text & _
                "');"
            LibraryCommand.SQL(CMDTextBox.Text)
            LibraryGetData.ToListViewAll()
            Me.Close()
        End If
    End Sub

    Private Sub AddCancelButton_Click(sender As Object, e As EventArgs) Handles AddCancelButton.Click
        FrmLibraryCancel.ShowDialog()
    End Sub

    Private Sub UploadsButton_Click(sender As Object, e As EventArgs) Handles UploadsButton.Click
        Dim OpenFileDialog1 As New OpenFileDialog
        OpenFileDialog1.Filter = "JPEG (*.jpg;.*jpeg)|*.jpg;.*jpeg|GIF (*.gif)|*.gif|All File (*.*)|*.*" 'ចំណត់ប្រភេទរូប (Extension)
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            ItemsPictureBox.Image = Image.FromFile(OpenFileDialog1.FileName)
        End If
    End Sub
End Class