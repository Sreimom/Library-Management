﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryCancel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryCancel))
        Me.NoCloseButton = New System.Windows.Forms.Button()
        Me.YesCloseButton = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StuDelInfoLabel = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NoCloseButton
        '
        Me.NoCloseButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.NoCloseButton.Location = New System.Drawing.Point(369, 154)
        Me.NoCloseButton.Name = "NoCloseButton"
        Me.NoCloseButton.Size = New System.Drawing.Size(94, 34)
        Me.NoCloseButton.TabIndex = 18
        Me.NoCloseButton.Text = "ទេ"
        Me.NoCloseButton.UseVisualStyleBackColor = True
        '
        'YesCloseButton
        '
        Me.YesCloseButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.YesCloseButton.Location = New System.Drawing.Point(263, 154)
        Me.YesCloseButton.Name = "YesCloseButton"
        Me.YesCloseButton.Size = New System.Drawing.Size(94, 34)
        Me.YesCloseButton.TabIndex = 17
        Me.YesCloseButton.Text = "បាទ, ចាស៎"
        Me.YesCloseButton.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Location = New System.Drawing.Point(124, 64)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(143, 74)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox2.Location = New System.Drawing.Point(12, 11)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(43, 37)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 16
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(145, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(221, 25)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "ទិន្នន័យដែលអ្នកបញ្ចូលនឹងត្រូវសម្អាត"
        '
        'StuDelInfoLabel
        '
        Me.StuDelInfoLabel.AutoSize = True
        Me.StuDelInfoLabel.BackColor = System.Drawing.Color.Transparent
        Me.StuDelInfoLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.StuDelInfoLabel.Location = New System.Drawing.Point(52, 11)
        Me.StuDelInfoLabel.Name = "StuDelInfoLabel"
        Me.StuDelInfoLabel.Size = New System.Drawing.Size(215, 25)
        Me.StuDelInfoLabel.TabIndex = 14
        Me.StuDelInfoLabel.Text = "តើអ្នកពិតជាចង់បោះបង់ពិតមែនទេ?"
        '
        'FrmLibraryCancel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(475, 198)
        Me.Controls.Add(Me.NoCloseButton)
        Me.Controls.Add(Me.YesCloseButton)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.StuDelInfoLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryCancel"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NoCloseButton As System.Windows.Forms.Button
    Friend WithEvents YesCloseButton As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents StuDelInfoLabel As System.Windows.Forms.Label
End Class
