﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryDelete
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryDelete))
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.DelInfoLabel = New System.Windows.Forms.Label()
        Me.DelPictureBox = New System.Windows.Forms.PictureBox()
        Me.YesButton = New System.Windows.Forms.Button()
        Me.NoButton = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.OnDateLabel = New System.Windows.Forms.Label()
        Me.CountLabel = New System.Windows.Forms.Label()
        Me.AutherLabel = New System.Windows.Forms.Label()
        Me.TitleNameLabel = New System.Windows.Forms.Label()
        Me.IDLabel = New System.Windows.Forms.Label()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DelPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CMDTextBox
        '
        Me.CMDTextBox.Location = New System.Drawing.Point(0, 206)
        Me.CMDTextBox.Multiline = True
        Me.CMDTextBox.Name = "CMDTextBox"
        Me.CMDTextBox.Size = New System.Drawing.Size(495, 121)
        Me.CMDTextBox.TabIndex = 35
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox2.Location = New System.Drawing.Point(10, 10)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(34, 37)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 29
        Me.PictureBox2.TabStop = False
        '
        'DelInfoLabel
        '
        Me.DelInfoLabel.AutoSize = True
        Me.DelInfoLabel.BackColor = System.Drawing.Color.Transparent
        Me.DelInfoLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.DelInfoLabel.Location = New System.Drawing.Point(50, 10)
        Me.DelInfoLabel.Name = "DelInfoLabel"
        Me.DelInfoLabel.Size = New System.Drawing.Size(288, 25)
        Me.DelInfoLabel.TabIndex = 28
        Me.DelInfoLabel.Text = "តើអ្នកពិតជាចង់លុបទិន្នន័យ 1 នេះចោលមែនទេ?"
        '
        'DelPictureBox
        '
        Me.DelPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.DelPictureBox.BackgroundImage = CType(resources.GetObject("DelPictureBox.BackgroundImage"), System.Drawing.Image)
        Me.DelPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.DelPictureBox.Location = New System.Drawing.Point(45, 44)
        Me.DelPictureBox.Name = "DelPictureBox"
        Me.DelPictureBox.Size = New System.Drawing.Size(114, 111)
        Me.DelPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DelPictureBox.TabIndex = 27
        Me.DelPictureBox.TabStop = False
        '
        'YesButton
        '
        Me.YesButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.YesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.YesButton.ImageIndex = 1
        Me.YesButton.Location = New System.Drawing.Point(292, 161)
        Me.YesButton.Name = "YesButton"
        Me.YesButton.Size = New System.Drawing.Size(92, 30)
        Me.YesButton.TabIndex = 25
        Me.YesButton.Text = "បាទ,ចាស៎"
        Me.YesButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.YesButton.UseVisualStyleBackColor = True
        '
        'NoButton
        '
        Me.NoButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NoButton.ImageIndex = 0
        Me.NoButton.Location = New System.Drawing.Point(390, 161)
        Me.NoButton.Name = "NoButton"
        Me.NoButton.Size = New System.Drawing.Size(92, 30)
        Me.NoButton.TabIndex = 26
        Me.NoButton.Text = "ទេ"
        Me.NoButton.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TextBox1.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.TextBox1.HideSelection = False
        Me.TextBox1.Location = New System.Drawing.Point(165, 42)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(312, 111)
        Me.TextBox1.TabIndex = 36
        '
        'OnDateLabel
        '
        Me.OnDateLabel.BackColor = System.Drawing.Color.Transparent
        Me.OnDateLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.OnDateLabel.Location = New System.Drawing.Point(161, 133)
        Me.OnDateLabel.Name = "OnDateLabel"
        Me.OnDateLabel.Size = New System.Drawing.Size(321, 23)
        Me.OnDateLabel.TabIndex = 30
        Me.OnDateLabel.Text = "កាលបរិច្ឆេទ : 12/Dec/2017"
        '
        'CountLabel
        '
        Me.CountLabel.BackColor = System.Drawing.Color.Transparent
        Me.CountLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.CountLabel.Location = New System.Drawing.Point(161, 110)
        Me.CountLabel.Name = "CountLabel"
        Me.CountLabel.Size = New System.Drawing.Size(321, 23)
        Me.CountLabel.TabIndex = 31
        Me.CountLabel.Text = "មានចំនួន : 0"
        '
        'AutherLabel
        '
        Me.AutherLabel.BackColor = System.Drawing.Color.Transparent
        Me.AutherLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.AutherLabel.Location = New System.Drawing.Point(161, 87)
        Me.AutherLabel.Name = "AutherLabel"
        Me.AutherLabel.Size = New System.Drawing.Size(321, 23)
        Me.AutherLabel.TabIndex = 32
        Me.AutherLabel.Text = "អ្នកនិពន្ធ :  សែម គឹមសាន"
        '
        'TitleNameLabel
        '
        Me.TitleNameLabel.BackColor = System.Drawing.Color.Transparent
        Me.TitleNameLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.TitleNameLabel.Location = New System.Drawing.Point(161, 64)
        Me.TitleNameLabel.Name = "TitleNameLabel"
        Me.TitleNameLabel.Size = New System.Drawing.Size(321, 23)
        Me.TitleNameLabel.TabIndex = 33
        Me.TitleNameLabel.Text = "ចំណង់ជើង  :  សែម គឹមសាន"
        '
        'IDLabel
        '
        Me.IDLabel.BackColor = System.Drawing.Color.Transparent
        Me.IDLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.IDLabel.Location = New System.Drawing.Point(161, 41)
        Me.IDLabel.Name = "IDLabel"
        Me.IDLabel.Size = New System.Drawing.Size(321, 23)
        Me.IDLabel.TabIndex = 34
        Me.IDLabel.Text = "លេខរៀង :  0"
        '
        'FrmLibraryDelete
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(494, 201)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.DelInfoLabel)
        Me.Controls.Add(Me.DelPictureBox)
        Me.Controls.Add(Me.YesButton)
        Me.Controls.Add(Me.NoButton)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.OnDateLabel)
        Me.Controls.Add(Me.CountLabel)
        Me.Controls.Add(Me.AutherLabel)
        Me.Controls.Add(Me.TitleNameLabel)
        Me.Controls.Add(Me.IDLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryDelete"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DelPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents DelInfoLabel As System.Windows.Forms.Label
    Friend WithEvents DelPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents YesButton As System.Windows.Forms.Button
    Friend WithEvents NoButton As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents OnDateLabel As System.Windows.Forms.Label
    Friend WithEvents CountLabel As System.Windows.Forms.Label
    Friend WithEvents AutherLabel As System.Windows.Forms.Label
    Friend WithEvents TitleNameLabel As System.Windows.Forms.Label
    Friend WithEvents IDLabel As System.Windows.Forms.Label
End Class
