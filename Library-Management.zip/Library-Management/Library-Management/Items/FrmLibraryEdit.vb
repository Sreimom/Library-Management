﻿Imports System.IO
Imports System.Text.RegularExpressions

Public Class FrmLibraryEdit
    Sub ItemInfoView()
        Dim i As Integer
        For i = 0 To Me.ListBox1.Items.Count - 1
            If ListBox1.SelectedIndex = i Then
                Dim j As String = ListBox1.Items(i).ToString()
                Dim getlen As String = j.IndexOf("-")
                j = Microsoft.VisualBasic.Left(j, getlen)
                j = (Regex.Replace(j, "[^\d]", ""))

                NoTextBox.Text = j
                LibraryGetData.ToItemEdite(j)
            End If
        Next i
    End Sub
    Private Sub frmedit_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub ListBox1_DoubleClick(sender As Object, e As EventArgs) Handles ListBox1.DoubleClick
        Call ItemInfoView()
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

        Call ItemInfoView()
    End Sub

    Private Sub IsEmpty()
        If TitleTextBox.Text = "" Then
            TitleLabel.ForeColor = Color.Red
            TitleTextBox.Focus()
        ElseIf AuthorTextBox.Text = "" Then
            AuthorLabel.ForeColor = Color.Red
            AuthorTextBox.Focus()
        ElseIf EidterTextBox.Text = "" Then
            EditerLabel.ForeColor = Color.Red
            EidterTextBox.Focus()
        ElseIf HowManyTextBox.Text = "" Then
            HowManyLabel.ForeColor = Color.Red
            HowManyTextBox.Focus()
        ElseIf HowMuchForSellTextBox.Text = "" Then
            HowMuchLabel.ForeColor = Color.Red
            HowMuchForSellTextBox.Focus()
        ElseIf HowMuchForBorrowTextBox.Text = "" Then
            HowMuchForBorrowLabel.ForeColor = Color.Red
            HowMuchForBorrowTextBox.Focus()
        Else
            TitleLabel.ForeColor = Color.Black
            AuthorLabel.ForeColor = Color.Black
            EditerLabel.ForeColor = Color.Black
            HowManyLabel.ForeColor = Color.Black
            HowMuchLabel.ForeColor = Color.Black
            HowMuchForBorrowLabel.ForeColor = Color.Black
        End If

    End Sub
    Private Sub UpdateButton_Click(sender As Object, e As EventArgs) Handles UpdateButton.Click
        Call IsEmpty()
        If TitleTextBox.Text <> "" And AuthorTextBox.Text <> "" And EidterTextBox.Text <> "" And HowManyTextBox.Text <> "" And HowMuchForSellTextBox.Text <> "" And HowMuchForBorrowTextBox.Text <> "" Then
            FrmLibraryProcessing.Timer1.Start()
            FrmLibraryProcessing.Timer1.Enabled = True
            FrmLibraryProcessing.Timer1.Interval = 10

            Dim PicRename As String = TimeOfDay.ToString("hh-mm-ss")
            PicRename = Replace(PicRename, "-", "")
            If IsNothing(ItemsPictureBox.Image) Then
                PicRename = "Items.png"
            Else
                PicRename = "Items.png"
                'PicRename = PicRename & ".jpg"
                'Dim path As String = Replace(Directory.GetCurrentDirectory(), "\Debug", "\Library-Management\Photo\Items\ " & PicRename)
                'ItemsPictureBox.Image.Save(path, Drawing.Imaging.ImageFormat.Jpeg)
            End If

            CMDTextBox.Text = "UPDATE items SET" & _
                " item_title='" & TitleTextBox.Text & _
                "', item_author='" & AuthorTextBox.Text & _
                "', item_editer='" & EidterTextBox.Text & _
                "', item_publiser='" & PubliserDateTimePicker.Text & _
                "',lan_id='" & LanguageComboBox.SelectedValue & _
                "',item_how_many='" & HowManyTextBox.Text & _
                "',item_for_sell='" & HowMuchForSellTextBox.Text & _
                "',item_for_borrow='" & HowMuchForBorrowTextBox.Text & _
                "',item_pic='" & PicRename & _
                "',cat_id='" & CategoryComboBox.SelectedValue & _
                "',cab_id='" & CabComboBox.SelectedValue & _
                "',she_id='" & SheComboBox.SelectedValue & _
                "',note='" & NoteTextBox.Text & _
                "' WHERE item_id=" & NoTextBox.Text & ""
            LibraryCommand.SQL(CMDTextBox.Text)
        End If
    End Sub



    Private Sub EditCancelButton_Click(sender As Object, e As EventArgs) Handles EditCancelButton.Click
        Me.Close()
    End Sub
End Class