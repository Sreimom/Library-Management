﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryAddnew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryAddnew))
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.LeftPanel = New System.Windows.Forms.Panel()
        Me.HowMuchLabel = New System.Windows.Forms.Label()
        Me.HowMuchForBorrowLabel = New System.Windows.Forms.Label()
        Me.CaptureButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.UploadsButton = New System.Windows.Forms.Button()
        Me.ItemsPictureBox = New System.Windows.Forms.PictureBox()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.PubliserDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.SheComboBox = New System.Windows.Forms.ComboBox()
        Me.CabComboBox = New System.Windows.Forms.ComboBox()
        Me.LanguageComboBox = New System.Windows.Forms.ComboBox()
        Me.AddCancelButton = New System.Windows.Forms.Button()
        Me.CategoryComboBox = New System.Windows.Forms.ComboBox()
        Me.CategoryLabel = New System.Windows.Forms.Label()
        Me.RightPanel = New System.Windows.Forms.Panel()
        Me.picLabel = New System.Windows.Forms.Label()
        Me.SheLabel = New System.Windows.Forms.Label()
        Me.NoteLabel = New System.Windows.Forms.Label()
        Me.CabLabel = New System.Windows.Forms.Label()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.HowManyLabel = New System.Windows.Forms.Label()
        Me.TitleTextBox = New System.Windows.Forms.TextBox()
        Me.EidterTextBox = New System.Windows.Forms.TextBox()
        Me.LanguageLabel = New System.Windows.Forms.Label()
        Me.HowManyTextBox = New System.Windows.Forms.TextBox()
        Me.AuthorTextBox = New System.Windows.Forms.TextBox()
        Me.NoteTextBox = New System.Windows.Forms.TextBox()
        Me.HowMuchForBorrowTextBox = New System.Windows.Forms.TextBox()
        Me.HowMuchForSellTextBox = New System.Windows.Forms.TextBox()
        Me.AuthorLabel = New System.Windows.Forms.Label()
        Me.PubliserLabel = New System.Windows.Forms.Label()
        Me.EditerLabel = New System.Windows.Forms.Label()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TopToolStrip = New System.Windows.Forms.ToolStrip()
        Me.cat_idToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        CType(Me.ItemsPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RightPanel.SuspendLayout()
        Me.TopToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'CMDTextBox
        '
        Me.CMDTextBox.Location = New System.Drawing.Point(0, 539)
        Me.CMDTextBox.Multiline = True
        Me.CMDTextBox.Name = "CMDTextBox"
        Me.CMDTextBox.Size = New System.Drawing.Size(731, 122)
        Me.CMDTextBox.TabIndex = 40
        '
        'LeftPanel
        '
        Me.LeftPanel.BackColor = System.Drawing.Color.LightSeaGreen
        Me.LeftPanel.BackgroundImage = CType(resources.GetObject("LeftPanel.BackgroundImage"), System.Drawing.Image)
        Me.LeftPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LeftPanel.Location = New System.Drawing.Point(-8, 32)
        Me.LeftPanel.Name = "LeftPanel"
        Me.LeftPanel.Size = New System.Drawing.Size(186, 507)
        Me.LeftPanel.TabIndex = 37
        '
        'HowMuchLabel
        '
        Me.HowMuchLabel.AutoSize = True
        Me.HowMuchLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.HowMuchLabel.Location = New System.Drawing.Point(279, 249)
        Me.HowMuchLabel.Name = "HowMuchLabel"
        Me.HowMuchLabel.Size = New System.Drawing.Size(96, 27)
        Me.HowMuchLabel.TabIndex = 22
        Me.HowMuchLabel.Text = "តម្លៃលក់/១ (​​៛)"
        '
        'HowMuchForBorrowLabel
        '
        Me.HowMuchForBorrowLabel.AutoSize = True
        Me.HowMuchForBorrowLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.HowMuchForBorrowLabel.Location = New System.Drawing.Point(408, 252)
        Me.HowMuchForBorrowLabel.Name = "HowMuchForBorrowLabel"
        Me.HowMuchForBorrowLabel.Size = New System.Drawing.Size(81, 27)
        Me.HowMuchForBorrowLabel.TabIndex = 22
        Me.HowMuchForBorrowLabel.Text = "តម្លៃខ្ចី/១ (​​៛)"
        '
        'CaptureButton
        '
        Me.CaptureButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.CaptureButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CaptureButton.ImageIndex = 3
        Me.CaptureButton.ImageList = Me.ImageList1
        Me.CaptureButton.Location = New System.Drawing.Point(413, 379)
        Me.CaptureButton.Name = "CaptureButton"
        Me.CaptureButton.Size = New System.Drawing.Size(124, 34)
        Me.CaptureButton.TabIndex = 13
        Me.CaptureButton.Text = "ថតរូប"
        Me.CaptureButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "floppy-icon.png")
        Me.ImageList1.Images.SetKeyName(2, "folder-yellow-explorer-icon.png")
        Me.ImageList1.Images.SetKeyName(3, "loysaevhusmyqimlzgpy.png")
        '
        'UploadsButton
        '
        Me.UploadsButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.UploadsButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.UploadsButton.ImageIndex = 2
        Me.UploadsButton.ImageList = Me.ImageList1
        Me.UploadsButton.Location = New System.Drawing.Point(413, 339)
        Me.UploadsButton.Name = "UploadsButton"
        Me.UploadsButton.Size = New System.Drawing.Size(124, 34)
        Me.UploadsButton.TabIndex = 12
        Me.UploadsButton.Text = "ជ្រើសរើស..."
        Me.UploadsButton.UseVisualStyleBackColor = True
        '
        'ItemsPictureBox
        '
        Me.ItemsPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.ItemsPictureBox.BackgroundImage = CType(resources.GetObject("ItemsPictureBox.BackgroundImage"), System.Drawing.Image)
        Me.ItemsPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ItemsPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ItemsPictureBox.Location = New System.Drawing.Point(282, 341)
        Me.ItemsPictureBox.Name = "ItemsPictureBox"
        Me.ItemsPictureBox.Size = New System.Drawing.Size(124, 110)
        Me.ItemsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ItemsPictureBox.TabIndex = 30
        Me.ItemsPictureBox.TabStop = False
        '
        'SaveButton
        '
        Me.SaveButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SaveButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.SaveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.SaveButton.ImageIndex = 1
        Me.SaveButton.ImageList = Me.ImageList1
        Me.SaveButton.Location = New System.Drawing.Point(439, 463)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(98, 31)
        Me.SaveButton.TabIndex = 16
        Me.SaveButton.Text = "រក្សាទុក"
        Me.SaveButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'PubliserDateTimePicker
        '
        Me.PubliserDateTimePicker.CalendarFont = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PubliserDateTimePicker.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PubliserDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.PubliserDateTimePicker.Location = New System.Drawing.Point(282, 217)
        Me.PubliserDateTimePicker.Name = "PubliserDateTimePicker"
        Me.PubliserDateTimePicker.Size = New System.Drawing.Size(255, 32)
        Me.PubliserDateTimePicker.TabIndex = 6
        '
        'SheComboBox
        '
        Me.SheComboBox.DropDownHeight = 200
        Me.SheComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SheComboBox.FormattingEnabled = True
        Me.SheComboBox.IntegralHeight = False
        Me.SheComboBox.Location = New System.Drawing.Point(146, 341)
        Me.SheComboBox.Name = "SheComboBox"
        Me.SheComboBox.Size = New System.Drawing.Size(127, 32)
        Me.SheComboBox.TabIndex = 11
        '
        'CabComboBox
        '
        Me.CabComboBox.DropDownHeight = 200
        Me.CabComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CabComboBox.FormattingEnabled = True
        Me.CabComboBox.IntegralHeight = False
        Me.CabComboBox.Location = New System.Drawing.Point(15, 341)
        Me.CabComboBox.Name = "CabComboBox"
        Me.CabComboBox.Size = New System.Drawing.Size(125, 32)
        Me.CabComboBox.TabIndex = 10
        '
        'LanguageComboBox
        '
        Me.LanguageComboBox.DropDownHeight = 200
        Me.LanguageComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LanguageComboBox.FormattingEnabled = True
        Me.LanguageComboBox.IntegralHeight = False
        Me.LanguageComboBox.Location = New System.Drawing.Point(16, 217)
        Me.LanguageComboBox.Name = "LanguageComboBox"
        Me.LanguageComboBox.Size = New System.Drawing.Size(256, 32)
        Me.LanguageComboBox.TabIndex = 5
        '
        'AddCancelButton
        '
        Me.AddCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.AddCancelButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.AddCancelButton.ImageIndex = 0
        Me.AddCancelButton.ImageList = Me.ImageList1
        Me.AddCancelButton.Location = New System.Drawing.Point(16, 463)
        Me.AddCancelButton.Name = "AddCancelButton"
        Me.AddCancelButton.Size = New System.Drawing.Size(96, 31)
        Me.AddCancelButton.TabIndex = 15
        Me.AddCancelButton.Text = "បោះបង់"
        Me.AddCancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.AddCancelButton.UseVisualStyleBackColor = True
        '
        'CategoryComboBox
        '
        Me.CategoryComboBox.DropDownHeight = 200
        Me.CategoryComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CategoryComboBox.FormattingEnabled = True
        Me.CategoryComboBox.IntegralHeight = False
        Me.CategoryComboBox.Location = New System.Drawing.Point(16, 31)
        Me.CategoryComboBox.Name = "CategoryComboBox"
        Me.CategoryComboBox.Size = New System.Drawing.Size(255, 32)
        Me.CategoryComboBox.TabIndex = 1
        '
        'CategoryLabel
        '
        Me.CategoryLabel.AutoSize = True
        Me.CategoryLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.CategoryLabel.Location = New System.Drawing.Point(11, 4)
        Me.CategoryLabel.Name = "CategoryLabel"
        Me.CategoryLabel.Size = New System.Drawing.Size(52, 27)
        Me.CategoryLabel.TabIndex = 0
        Me.CategoryLabel.Text = "ប្រភេទ"
        '
        'RightPanel
        '
        Me.RightPanel.BackColor = System.Drawing.Color.White
        Me.RightPanel.Controls.Add(Me.HowMuchLabel)
        Me.RightPanel.Controls.Add(Me.HowMuchForBorrowLabel)
        Me.RightPanel.Controls.Add(Me.CaptureButton)
        Me.RightPanel.Controls.Add(Me.UploadsButton)
        Me.RightPanel.Controls.Add(Me.ItemsPictureBox)
        Me.RightPanel.Controls.Add(Me.SaveButton)
        Me.RightPanel.Controls.Add(Me.PubliserDateTimePicker)
        Me.RightPanel.Controls.Add(Me.SheComboBox)
        Me.RightPanel.Controls.Add(Me.CabComboBox)
        Me.RightPanel.Controls.Add(Me.LanguageComboBox)
        Me.RightPanel.Controls.Add(Me.AddCancelButton)
        Me.RightPanel.Controls.Add(Me.CategoryComboBox)
        Me.RightPanel.Controls.Add(Me.CategoryLabel)
        Me.RightPanel.Controls.Add(Me.picLabel)
        Me.RightPanel.Controls.Add(Me.SheLabel)
        Me.RightPanel.Controls.Add(Me.NoteLabel)
        Me.RightPanel.Controls.Add(Me.CabLabel)
        Me.RightPanel.Controls.Add(Me.TitleLabel)
        Me.RightPanel.Controls.Add(Me.HowManyLabel)
        Me.RightPanel.Controls.Add(Me.TitleTextBox)
        Me.RightPanel.Controls.Add(Me.EidterTextBox)
        Me.RightPanel.Controls.Add(Me.LanguageLabel)
        Me.RightPanel.Controls.Add(Me.HowManyTextBox)
        Me.RightPanel.Controls.Add(Me.AuthorTextBox)
        Me.RightPanel.Controls.Add(Me.NoteTextBox)
        Me.RightPanel.Controls.Add(Me.HowMuchForBorrowTextBox)
        Me.RightPanel.Controls.Add(Me.HowMuchForSellTextBox)
        Me.RightPanel.Controls.Add(Me.AuthorLabel)
        Me.RightPanel.Controls.Add(Me.PubliserLabel)
        Me.RightPanel.Controls.Add(Me.EditerLabel)
        Me.RightPanel.Location = New System.Drawing.Point(173, 32)
        Me.RightPanel.Name = "RightPanel"
        Me.RightPanel.Size = New System.Drawing.Size(558, 507)
        Me.RightPanel.TabIndex = 38
        '
        'picLabel
        '
        Me.picLabel.AutoSize = True
        Me.picLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.picLabel.Location = New System.Drawing.Point(279, 313)
        Me.picLabel.Name = "picLabel"
        Me.picLabel.Size = New System.Drawing.Size(52, 27)
        Me.picLabel.TabIndex = 27
        Me.picLabel.Text = "រូបភាព"
        '
        'SheLabel
        '
        Me.SheLabel.AutoSize = True
        Me.SheLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.SheLabel.Location = New System.Drawing.Point(146, 314)
        Me.SheLabel.Name = "SheLabel"
        Me.SheLabel.Size = New System.Drawing.Size(27, 27)
        Me.SheLabel.TabIndex = 27
        Me.SheLabel.Text = "ធ្នើ"
        '
        'NoteLabel
        '
        Me.NoteLabel.AutoSize = True
        Me.NoteLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.NoteLabel.Location = New System.Drawing.Point(12, 376)
        Me.NoteLabel.Name = "NoteLabel"
        Me.NoteLabel.Size = New System.Drawing.Size(53, 27)
        Me.NoteLabel.TabIndex = 27
        Me.NoteLabel.Text = "ផ្សេងៗ"
        '
        'CabLabel
        '
        Me.CabLabel.AutoSize = True
        Me.CabLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.CabLabel.Location = New System.Drawing.Point(12, 314)
        Me.CabLabel.Name = "CabLabel"
        Me.CabLabel.Size = New System.Drawing.Size(57, 27)
        Me.CabLabel.TabIndex = 27
        Me.CabLabel.Text = "ទូរលេខ"
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.TitleLabel.Location = New System.Drawing.Point(12, 66)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(78, 27)
        Me.TitleLabel.TabIndex = 0
        Me.TitleLabel.Text = "ចំណងជើង"
        '
        'HowManyLabel
        '
        Me.HowManyLabel.AutoSize = True
        Me.HowManyLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.HowManyLabel.Location = New System.Drawing.Point(11, 252)
        Me.HowManyLabel.Name = "HowManyLabel"
        Me.HowManyLabel.Size = New System.Drawing.Size(67, 27)
        Me.HowManyLabel.TabIndex = 4
        Me.HowManyLabel.Text = "មានចំនួន"
        '
        'TitleTextBox
        '
        Me.TitleTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TitleTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList
        Me.TitleTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleTextBox.Location = New System.Drawing.Point(15, 93)
        Me.TitleTextBox.Name = "TitleTextBox"
        Me.TitleTextBox.Size = New System.Drawing.Size(522, 32)
        Me.TitleTextBox.TabIndex = 2
        '
        'EidterTextBox
        '
        Me.EidterTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EidterTextBox.Location = New System.Drawing.Point(281, 155)
        Me.EidterTextBox.Name = "EidterTextBox"
        Me.EidterTextBox.Size = New System.Drawing.Size(256, 32)
        Me.EidterTextBox.TabIndex = 4
        '
        'LanguageLabel
        '
        Me.LanguageLabel.AutoSize = True
        Me.LanguageLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.LanguageLabel.Location = New System.Drawing.Point(12, 190)
        Me.LanguageLabel.Name = "LanguageLabel"
        Me.LanguageLabel.Size = New System.Drawing.Size(48, 27)
        Me.LanguageLabel.TabIndex = 28
        Me.LanguageLabel.Text = "ភាសា"
        '
        'HowManyTextBox
        '
        Me.HowManyTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HowManyTextBox.Location = New System.Drawing.Point(16, 279)
        Me.HowManyTextBox.Name = "HowManyTextBox"
        Me.HowManyTextBox.Size = New System.Drawing.Size(257, 32)
        Me.HowManyTextBox.TabIndex = 7
        '
        'AuthorTextBox
        '
        Me.AuthorTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AuthorTextBox.Location = New System.Drawing.Point(16, 155)
        Me.AuthorTextBox.Name = "AuthorTextBox"
        Me.AuthorTextBox.Size = New System.Drawing.Size(255, 32)
        Me.AuthorTextBox.TabIndex = 3
        '
        'NoteTextBox
        '
        Me.NoteTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoteTextBox.Location = New System.Drawing.Point(16, 403)
        Me.NoteTextBox.Multiline = True
        Me.NoteTextBox.Name = "NoteTextBox"
        Me.NoteTextBox.Size = New System.Drawing.Size(255, 46)
        Me.NoteTextBox.TabIndex = 14
        '
        'HowMuchForBorrowTextBox
        '
        Me.HowMuchForBorrowTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HowMuchForBorrowTextBox.Location = New System.Drawing.Point(413, 279)
        Me.HowMuchForBorrowTextBox.Name = "HowMuchForBorrowTextBox"
        Me.HowMuchForBorrowTextBox.Size = New System.Drawing.Size(124, 32)
        Me.HowMuchForBorrowTextBox.TabIndex = 9
        '
        'HowMuchForSellTextBox
        '
        Me.HowMuchForSellTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HowMuchForSellTextBox.Location = New System.Drawing.Point(283, 279)
        Me.HowMuchForSellTextBox.Name = "HowMuchForSellTextBox"
        Me.HowMuchForSellTextBox.Size = New System.Drawing.Size(122, 32)
        Me.HowMuchForSellTextBox.TabIndex = 8
        '
        'AuthorLabel
        '
        Me.AuthorLabel.AutoSize = True
        Me.AuthorLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.AuthorLabel.Location = New System.Drawing.Point(12, 128)
        Me.AuthorLabel.Name = "AuthorLabel"
        Me.AuthorLabel.Size = New System.Drawing.Size(62, 27)
        Me.AuthorLabel.TabIndex = 2
        Me.AuthorLabel.Text = "អ្នកនិពន្ធ"
        '
        'PubliserLabel
        '
        Me.PubliserLabel.AutoSize = True
        Me.PubliserLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.PubliserLabel.Location = New System.Drawing.Point(278, 190)
        Me.PubliserLabel.Name = "PubliserLabel"
        Me.PubliserLabel.Size = New System.Drawing.Size(59, 27)
        Me.PubliserLabel.TabIndex = 4
        Me.PubliserLabel.Text = "បោះពុម្ភ"
        '
        'EditerLabel
        '
        Me.EditerLabel.AutoSize = True
        Me.EditerLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.EditerLabel.Location = New System.Drawing.Point(278, 128)
        Me.EditerLabel.Name = "EditerLabel"
        Me.EditerLabel.Size = New System.Drawing.Size(107, 27)
        Me.EditerLabel.TabIndex = 22
        Me.EditerLabel.Text = "កែសម្រួលដោយ"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Image = CType(resources.GetObject("SaveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.SaveToolStripMenuItem.Text = "រក្សាទុក"
        '
        'FileToolStripButton
        '
        Me.FileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileToolStripButton.Image = CType(resources.GetObject("FileToolStripButton.Image"), System.Drawing.Image)
        Me.FileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileToolStripButton.Name = "FileToolStripButton"
        Me.FileToolStripButton.Size = New System.Drawing.Size(59, 26)
        Me.FileToolStripButton.Text = "ឯកសារ"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.CloseToolStripMenuItem.Text = "&បិទ"
        '
        'TopToolStrip
        '
        Me.TopToolStrip.AutoSize = False
        Me.TopToolStrip.BackColor = System.Drawing.SystemColors.Control
        Me.TopToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.TopToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripButton, Me.cat_idToolStripLabel})
        Me.TopToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStrip.Name = "TopToolStrip"
        Me.TopToolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.TopToolStrip.Size = New System.Drawing.Size(731, 29)
        Me.TopToolStrip.TabIndex = 39
        Me.TopToolStrip.Text = "ToolStrip1"
        '
        'cat_idToolStripLabel
        '
        Me.cat_idToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.cat_idToolStripLabel.Name = "cat_idToolStripLabel"
        Me.cat_idToolStripLabel.Size = New System.Drawing.Size(38, 26)
        Me.cat_idToolStripLabel.Text = "cat_id"
        Me.cat_idToolStripLabel.Visible = False
        '
        'FrmLibraryAddnew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(731, 532)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.LeftPanel)
        Me.Controls.Add(Me.RightPanel)
        Me.Controls.Add(Me.TopToolStrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryAddnew"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.ItemsPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RightPanel.ResumeLayout(False)
        Me.RightPanel.PerformLayout()
        Me.TopToolStrip.ResumeLayout(False)
        Me.TopToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LeftPanel As System.Windows.Forms.Panel
    Friend WithEvents HowMuchLabel As System.Windows.Forms.Label
    Friend WithEvents HowMuchForBorrowLabel As System.Windows.Forms.Label
    Friend WithEvents CaptureButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents UploadsButton As System.Windows.Forms.Button
    Friend WithEvents ItemsPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents PubliserDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents SheComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CabComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents LanguageComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents AddCancelButton As System.Windows.Forms.Button
    Friend WithEvents CategoryComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CategoryLabel As System.Windows.Forms.Label
    Friend WithEvents RightPanel As System.Windows.Forms.Panel
    Friend WithEvents picLabel As System.Windows.Forms.Label
    Friend WithEvents SheLabel As System.Windows.Forms.Label
    Friend WithEvents NoteLabel As System.Windows.Forms.Label
    Friend WithEvents CabLabel As System.Windows.Forms.Label
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents HowManyLabel As System.Windows.Forms.Label
    Friend WithEvents TitleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EidterTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LanguageLabel As System.Windows.Forms.Label
    Friend WithEvents HowManyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AuthorTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NoteTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HowMuchForBorrowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HowMuchForSellTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AuthorLabel As System.Windows.Forms.Label
    Friend WithEvents PubliserLabel As System.Windows.Forms.Label
    Friend WithEvents EditerLabel As System.Windows.Forms.Label
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TopToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents cat_idToolStripLabel As System.Windows.Forms.ToolStripLabel
End Class
