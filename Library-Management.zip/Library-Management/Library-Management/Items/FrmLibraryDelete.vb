﻿Imports System.Text.RegularExpressions

Public Class FrmLibraryDelete

    Private Sub frmdelete_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer = Regex.Replace(FrmLibraryMain.CountSelectedItemsToolStripLabel.Text, "[^\d]", "") 'Regex សម្រាប់លុបអក្សរទុកតែលេខ

        If i <= 1 Then
            DelInfoLabel.Text = "តើអ្នកពិតជាចង់លុបទិន្នន័យ 1 នេះចោលមែនទេ?"
            Dim item_id As Integer = Regex.Replace(CMDTextBox.Text, "[^\d]", "") 'Regex សម្រាប់លុបអក្សរទុកតែលេខ
            TextBox1.Visible = False
            LibraryGetData.ToItemDelete(item_id)
        Else
            DelInfoLabel.Text = "តើអ្នកពិតជាចង់លុបទិន្នន័យទាំង " & Regex.Replace(FrmLibraryMain.CountSelectedItemsToolStripLabel.Text, "[^\d]", "") & " នេះមែន?"
            TextBox1.Visible = True
        End If

    End Sub

    Private Sub YesButton_Click(sender As Object, e As EventArgs) Handles YesButton.Click

        FrmLibraryProcessing.Timer1.Start()
        FrmLibraryProcessing.Timer1.Enabled = True
        FrmLibraryProcessing.Timer1.Interval = 5

        LibraryCommand.SQL(CMDTextBox.Text)
        LibraryGetData.ToListViewAll()
        Me.Close()
    End Sub

    Private Sub NoButton_Click(sender As Object, e As EventArgs) Handles NoButton.Click
        Me.Close()
    End Sub
End Class