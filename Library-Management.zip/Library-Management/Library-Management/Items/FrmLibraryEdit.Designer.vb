﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryEdit))
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CaptureButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.UploadsButton = New System.Windows.Forms.Button()
        Me.ItemsPictureBox = New System.Windows.Forms.PictureBox()
        Me.SheComboBox = New System.Windows.Forms.ComboBox()
        Me.CabComboBox = New System.Windows.Forms.ComboBox()
        Me.picLabel = New System.Windows.Forms.Label()
        Me.SheLabel = New System.Windows.Forms.Label()
        Me.NoteLabel = New System.Windows.Forms.Label()
        Me.CabLabel = New System.Windows.Forms.Label()
        Me.NoteTextBox = New System.Windows.Forms.TextBox()
        Me.HowMuchLabel = New System.Windows.Forms.Label()
        Me.HowMuchForBorrowTextBox = New System.Windows.Forms.TextBox()
        Me.HowMuchForSellTextBox = New System.Windows.Forms.TextBox()
        Me.HowMuchForBorrowLabel = New System.Windows.Forms.Label()
        Me.UpdateButton = New System.Windows.Forms.Button()
        Me.PubliserDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.LanguageComboBox = New System.Windows.Forms.ComboBox()
        Me.EditCancelButton = New System.Windows.Forms.Button()
        Me.CategoryComboBox = New System.Windows.Forms.ComboBox()
        Me.NoLabel = New System.Windows.Forms.Label()
        Me.CategoryLabel = New System.Windows.Forms.Label()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.HowManyLabel = New System.Windows.Forms.Label()
        Me.TitleTextBox = New System.Windows.Forms.TextBox()
        Me.EidterTextBox = New System.Windows.Forms.TextBox()
        Me.LanguageLabel = New System.Windows.Forms.Label()
        Me.HowManyTextBox = New System.Windows.Forms.TextBox()
        Me.NoTextBox = New System.Windows.Forms.TextBox()
        Me.AuthorTextBox = New System.Windows.Forms.TextBox()
        Me.AuthorLabel = New System.Windows.Forms.Label()
        Me.PubliserLabel = New System.Windows.Forms.Label()
        Me.EditerLabel = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.Panel1.SuspendLayout()
        CType(Me.ItemsPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        resources.ApplyResources(Me.ListBox1, "ListBox1")
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Name = "ListBox1"
        '
        'CMDTextBox
        '
        resources.ApplyResources(Me.CMDTextBox, "CMDTextBox")
        Me.CMDTextBox.Name = "CMDTextBox"
        '
        'Panel1
        '
        resources.ApplyResources(Me.Panel1, "Panel1")
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.CaptureButton)
        Me.Panel1.Controls.Add(Me.UploadsButton)
        Me.Panel1.Controls.Add(Me.ItemsPictureBox)
        Me.Panel1.Controls.Add(Me.SheComboBox)
        Me.Panel1.Controls.Add(Me.CabComboBox)
        Me.Panel1.Controls.Add(Me.picLabel)
        Me.Panel1.Controls.Add(Me.SheLabel)
        Me.Panel1.Controls.Add(Me.NoteLabel)
        Me.Panel1.Controls.Add(Me.CabLabel)
        Me.Panel1.Controls.Add(Me.NoteTextBox)
        Me.Panel1.Controls.Add(Me.HowMuchLabel)
        Me.Panel1.Controls.Add(Me.HowMuchForBorrowTextBox)
        Me.Panel1.Controls.Add(Me.HowMuchForSellTextBox)
        Me.Panel1.Controls.Add(Me.HowMuchForBorrowLabel)
        Me.Panel1.Controls.Add(Me.UpdateButton)
        Me.Panel1.Controls.Add(Me.PubliserDateTimePicker)
        Me.Panel1.Controls.Add(Me.LanguageComboBox)
        Me.Panel1.Controls.Add(Me.EditCancelButton)
        Me.Panel1.Controls.Add(Me.CategoryComboBox)
        Me.Panel1.Controls.Add(Me.NoLabel)
        Me.Panel1.Controls.Add(Me.CategoryLabel)
        Me.Panel1.Controls.Add(Me.TitleLabel)
        Me.Panel1.Controls.Add(Me.HowManyLabel)
        Me.Panel1.Controls.Add(Me.TitleTextBox)
        Me.Panel1.Controls.Add(Me.EidterTextBox)
        Me.Panel1.Controls.Add(Me.LanguageLabel)
        Me.Panel1.Controls.Add(Me.HowManyTextBox)
        Me.Panel1.Controls.Add(Me.NoTextBox)
        Me.Panel1.Controls.Add(Me.AuthorTextBox)
        Me.Panel1.Controls.Add(Me.AuthorLabel)
        Me.Panel1.Controls.Add(Me.PubliserLabel)
        Me.Panel1.Controls.Add(Me.EditerLabel)
        Me.Panel1.Name = "Panel1"
        '
        'CaptureButton
        '
        resources.ApplyResources(Me.CaptureButton, "CaptureButton")
        Me.CaptureButton.ImageList = Me.ImageList1
        Me.CaptureButton.Name = "CaptureButton"
        Me.CaptureButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "floppy-icon.png")
        Me.ImageList1.Images.SetKeyName(2, "folder-yellow-explorer-icon.png")
        Me.ImageList1.Images.SetKeyName(3, "loysaevhusmyqimlzgpy.png")
        '
        'UploadsButton
        '
        resources.ApplyResources(Me.UploadsButton, "UploadsButton")
        Me.UploadsButton.ImageList = Me.ImageList1
        Me.UploadsButton.Name = "UploadsButton"
        Me.UploadsButton.UseVisualStyleBackColor = True
        '
        'ItemsPictureBox
        '
        resources.ApplyResources(Me.ItemsPictureBox, "ItemsPictureBox")
        Me.ItemsPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ItemsPictureBox.Name = "ItemsPictureBox"
        Me.ItemsPictureBox.TabStop = False
        '
        'SheComboBox
        '
        resources.ApplyResources(Me.SheComboBox, "SheComboBox")
        Me.SheComboBox.DropDownHeight = 200
        Me.SheComboBox.FormattingEnabled = True
        Me.SheComboBox.Name = "SheComboBox"
        '
        'CabComboBox
        '
        resources.ApplyResources(Me.CabComboBox, "CabComboBox")
        Me.CabComboBox.DropDownHeight = 200
        Me.CabComboBox.FormattingEnabled = True
        Me.CabComboBox.Name = "CabComboBox"
        '
        'picLabel
        '
        resources.ApplyResources(Me.picLabel, "picLabel")
        Me.picLabel.Name = "picLabel"
        '
        'SheLabel
        '
        resources.ApplyResources(Me.SheLabel, "SheLabel")
        Me.SheLabel.Name = "SheLabel"
        '
        'NoteLabel
        '
        resources.ApplyResources(Me.NoteLabel, "NoteLabel")
        Me.NoteLabel.Name = "NoteLabel"
        '
        'CabLabel
        '
        resources.ApplyResources(Me.CabLabel, "CabLabel")
        Me.CabLabel.Name = "CabLabel"
        '
        'NoteTextBox
        '
        resources.ApplyResources(Me.NoteTextBox, "NoteTextBox")
        Me.NoteTextBox.Name = "NoteTextBox"
        '
        'HowMuchLabel
        '
        resources.ApplyResources(Me.HowMuchLabel, "HowMuchLabel")
        Me.HowMuchLabel.Name = "HowMuchLabel"
        '
        'HowMuchForBorrowTextBox
        '
        resources.ApplyResources(Me.HowMuchForBorrowTextBox, "HowMuchForBorrowTextBox")
        Me.HowMuchForBorrowTextBox.Name = "HowMuchForBorrowTextBox"
        '
        'HowMuchForSellTextBox
        '
        resources.ApplyResources(Me.HowMuchForSellTextBox, "HowMuchForSellTextBox")
        Me.HowMuchForSellTextBox.Name = "HowMuchForSellTextBox"
        '
        'HowMuchForBorrowLabel
        '
        resources.ApplyResources(Me.HowMuchForBorrowLabel, "HowMuchForBorrowLabel")
        Me.HowMuchForBorrowLabel.Name = "HowMuchForBorrowLabel"
        '
        'UpdateButton
        '
        resources.ApplyResources(Me.UpdateButton, "UpdateButton")
        Me.UpdateButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UpdateButton.ImageList = Me.ImageList1
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.UseVisualStyleBackColor = True
        '
        'PubliserDateTimePicker
        '
        resources.ApplyResources(Me.PubliserDateTimePicker, "PubliserDateTimePicker")
        Me.PubliserDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.PubliserDateTimePicker.Name = "PubliserDateTimePicker"
        '
        'LanguageComboBox
        '
        resources.ApplyResources(Me.LanguageComboBox, "LanguageComboBox")
        Me.LanguageComboBox.DropDownHeight = 200
        Me.LanguageComboBox.FormattingEnabled = True
        Me.LanguageComboBox.Name = "LanguageComboBox"
        '
        'EditCancelButton
        '
        resources.ApplyResources(Me.EditCancelButton, "EditCancelButton")
        Me.EditCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.EditCancelButton.ImageList = Me.ImageList1
        Me.EditCancelButton.Name = "EditCancelButton"
        Me.EditCancelButton.UseVisualStyleBackColor = True
        '
        'CategoryComboBox
        '
        resources.ApplyResources(Me.CategoryComboBox, "CategoryComboBox")
        Me.CategoryComboBox.DropDownHeight = 200
        Me.CategoryComboBox.FormattingEnabled = True
        Me.CategoryComboBox.Name = "CategoryComboBox"
        '
        'NoLabel
        '
        resources.ApplyResources(Me.NoLabel, "NoLabel")
        Me.NoLabel.Name = "NoLabel"
        '
        'CategoryLabel
        '
        resources.ApplyResources(Me.CategoryLabel, "CategoryLabel")
        Me.CategoryLabel.Name = "CategoryLabel"
        '
        'TitleLabel
        '
        resources.ApplyResources(Me.TitleLabel, "TitleLabel")
        Me.TitleLabel.Name = "TitleLabel"
        '
        'HowManyLabel
        '
        resources.ApplyResources(Me.HowManyLabel, "HowManyLabel")
        Me.HowManyLabel.Name = "HowManyLabel"
        '
        'TitleTextBox
        '
        resources.ApplyResources(Me.TitleTextBox, "TitleTextBox")
        Me.TitleTextBox.Name = "TitleTextBox"
        '
        'EidterTextBox
        '
        resources.ApplyResources(Me.EidterTextBox, "EidterTextBox")
        Me.EidterTextBox.Name = "EidterTextBox"
        '
        'LanguageLabel
        '
        resources.ApplyResources(Me.LanguageLabel, "LanguageLabel")
        Me.LanguageLabel.Name = "LanguageLabel"
        '
        'HowManyTextBox
        '
        resources.ApplyResources(Me.HowManyTextBox, "HowManyTextBox")
        Me.HowManyTextBox.Name = "HowManyTextBox"
        '
        'NoTextBox
        '
        resources.ApplyResources(Me.NoTextBox, "NoTextBox")
        Me.NoTextBox.BackColor = System.Drawing.Color.White
        Me.NoTextBox.Name = "NoTextBox"
        Me.NoTextBox.ReadOnly = True
        '
        'AuthorTextBox
        '
        resources.ApplyResources(Me.AuthorTextBox, "AuthorTextBox")
        Me.AuthorTextBox.Name = "AuthorTextBox"
        '
        'AuthorLabel
        '
        resources.ApplyResources(Me.AuthorLabel, "AuthorLabel")
        Me.AuthorLabel.Name = "AuthorLabel"
        '
        'PubliserLabel
        '
        resources.ApplyResources(Me.PubliserLabel, "PubliserLabel")
        Me.PubliserLabel.Name = "PubliserLabel"
        '
        'EditerLabel
        '
        resources.ApplyResources(Me.EditerLabel, "EditerLabel")
        Me.EditerLabel.Name = "EditerLabel"
        '
        'Panel2
        '
        resources.ApplyResources(Me.Panel2, "Panel2")
        Me.Panel2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel2.Name = "Panel2"
        '
        'CloseToolStripMenuItem
        '
        resources.ApplyResources(Me.CloseToolStripMenuItem, "CloseToolStripMenuItem")
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        '
        'UpdateToolStripMenuItem
        '
        resources.ApplyResources(Me.UpdateToolStripMenuItem, "UpdateToolStripMenuItem")
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        '
        'FileToolStripButton
        '
        resources.ApplyResources(Me.FileToolStripButton, "FileToolStripButton")
        Me.FileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripButton.Name = "FileToolStripButton"
        '
        'ToolStrip1
        '
        resources.ApplyResources(Me.ToolStrip1, "ToolStrip1")
        Me.ToolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripButton})
        Me.ToolStrip1.Name = "ToolStrip1"
        '
        'FrmLibraryEdit
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryEdit"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.ItemsPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CaptureButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents UploadsButton As System.Windows.Forms.Button
    Friend WithEvents ItemsPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents SheComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CabComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents picLabel As System.Windows.Forms.Label
    Friend WithEvents SheLabel As System.Windows.Forms.Label
    Friend WithEvents NoteLabel As System.Windows.Forms.Label
    Friend WithEvents CabLabel As System.Windows.Forms.Label
    Friend WithEvents NoteTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HowMuchLabel As System.Windows.Forms.Label
    Friend WithEvents HowMuchForBorrowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HowMuchForSellTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HowMuchForBorrowLabel As System.Windows.Forms.Label
    Friend WithEvents UpdateButton As System.Windows.Forms.Button
    Friend WithEvents PubliserDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents LanguageComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents EditCancelButton As System.Windows.Forms.Button
    Friend WithEvents CategoryComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents NoLabel As System.Windows.Forms.Label
    Friend WithEvents CategoryLabel As System.Windows.Forms.Label
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents HowManyLabel As System.Windows.Forms.Label
    Friend WithEvents TitleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EidterTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LanguageLabel As System.Windows.Forms.Label
    Friend WithEvents HowManyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AuthorTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AuthorLabel As System.Windows.Forms.Label
    Friend WithEvents PubliserLabel As System.Windows.Forms.Label
    Friend WithEvents EditerLabel As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
End Class
