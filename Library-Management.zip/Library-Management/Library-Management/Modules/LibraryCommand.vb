﻿Imports MySql.Data.MySqlClient

Module LibraryCommand
    Sub SQL(ByVal Query As String)
        Dim MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim dr As MySqlDataReader
        Try
            MysqlConn.Open()
            Dim Command = New MySqlCommand(Query, MysqlConn)
            dr = Command.ExecuteReader

            FrmLibraryProcessing.ShowDialog()

        Catch ex As MySqlException
            System.Media.SystemSounds.Exclamation.Play()
            MsgBox("Not Successful")
            MsgBox(ex.Message)
            MysqlConn.Close()
        End Try
    End Sub
End Module
