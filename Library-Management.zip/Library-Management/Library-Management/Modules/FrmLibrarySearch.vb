﻿Imports MySql.Data.MySqlClient

Module FrmLibrarySearch
    Dim MysqlConn As New MySqlConnection
    Dim dr As MySqlDataReader
    Dim cmd As MySqlCommand
    Public Sub AllCollection()
        FrmLibraryMain.ItemListView.Items.Clear()
        Try


            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim keyword As String
            Dim cat_id As String

            If FrmLibraryMain.cat_idToolStripLabel.Text = "cat_id" Or FrmLibraryMain.cat_idToolStripLabel.Text = "" Then  'Check ថា cat_id មានតម្លៃ ជាលេខក៏អត់ នៅ frmlibrary.cat_id.Text បើតម្លៃវាជា =cat_id រី ="" វានិងធ្វើការ Search ទៅតាម លក្ខខ័ណខាងក្រោម
                cat_id = "" 'អោយតម្លៃ ទទេ cat_id = ""
                '           រកតាមចំណង់ជើង                                                           រកតាមអ្នកនិពន្ធ                                                                 រកតាមថ្ងៃបោះពុម្ភ                                                                   រកតាមអ្នកកែប្រែ                                                             រកតាមភាសា                                                                  រកតាមប្រភេទ                                                   
                keyword = "item.item_title LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%' OR item.item_author LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%' OR item.item_publiser LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%' OR item.item_editer LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%'  OR lan.lan_name LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%'  OR cat.cat_name LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%'"
            Else
                '           រកតាមចំណង់ជើង  
                keyword = "item.item_title LIKE '%" & FrmLibraryMain.SearchToolStripTextBox.Text & "%'" 'ទទួលបាន cat_id មានតម្លៃ ជាលេខ នៅពេលចុច លើ Menu ខាងឆ្វេង

                cat_id = "AND cat.cat_id='" & FrmLibraryMain.cat_idToolStripLabel.Text & "'" 'រកតាមប្រភេទ cat_id
            End If


            Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on item.cat_id=cat.cat_id WHERE " & keyword & cat_id & "  AND item_delete='N'  GROUP BY item.item_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader

            Dim list As ListViewItem

            Do While dr.Read = True
                list = New ListViewItem(dr("item_id").ToString)
                list.SubItems.Add(dr("item_title"))
                list.SubItems.Add(dr("item_author"))
                list.SubItems.Add(dr("item_publiser"))
                list.SubItems.Add(dr("cat_name"))
                list.SubItems.Add(dr("item_date"))
                list.SubItems.Add(dr("item_how_many"))
                list.SubItems.Add(dr("item_how_many"))

                FrmLibraryMain.ItemListView.Items.Add(list)
            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub

    Public Sub UserBorrow() 'បង្ហាញ់ទិន្នន័យ អ្នកខ្ចីដែលបានបង្កើត ដោយ Search តាមឈ្មោះ
        FrmLibraryBorrow.ViewBorrowUserListBox.Items.Clear()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            '                                           រកតាមឈ្មោះ
            Query = "SELECT * FROM borrows_users WHERE bu_fullname LIKE '%" & FrmLibraryBorrow.SearchBorrowTextBox.Text & "%' or bu_id LIKE '%" & FrmLibraryBorrow.SearchBorrowTextBox.Text & "%'"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            Do While dr.Read = True

                FrmLibraryBorrow.ViewBorrowUserListBox.Items.Add(dr("bu_id") & "-" & dr("bu_fullname"))

            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
End Module
