﻿Imports MySql.Data.MySqlClient
Imports System.IO

Module LibraryGetData
    Dim MysqlConn As New MySqlConnection
    Dim dr As MySqlDataReader
    Dim cmd As MySqlCommand
    Public Sub ToListViewAll() 'បង្ហាញទិន្នន័យ Items ទាំងអស់

        FrmLibraryMain.ItemListView.Items.Clear()
        Try
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String = "cat_id"
            If IsNumeric(FrmLibraryMain.cat_idToolStripLabel.Text) Then
                If FrmLibraryMain.cat_idToolStripLabel.Text = 1 Then
                    Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on item.cat_id=cat.cat_id WHERE cat.cat_id=1 AND item_delete='N' GROUP BY item.item_id"
                ElseIf FrmLibraryMain.cat_idToolStripLabel.Text = 2 Then
                    Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on item.cat_id=cat.cat_id WHERE cat.cat_id=2 AND item_delete='N' GROUP BY item.item_id"
                ElseIf FrmLibraryMain.cat_idToolStripLabel.Text = 3 Then
                    Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on item.cat_id=cat.cat_id WHERE cat.cat_id=3 AND item_delete='N' GROUP BY item.item_id"
                End If
            Else
                Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on item.cat_id=cat.cat_id WHERE item_delete='N' GROUP BY item.item_id;"
            End If

            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader

            Dim list As ListViewItem

            Do While dr.Read = True
                list = New ListViewItem(dr("item_id").ToString)
                list.SubItems.Add(dr("item_title"))
                list.SubItems.Add(dr("item_author"))
                list.SubItems.Add(dr("item_publiser"))
                list.SubItems.Add(dr("cat_name"))
                list.SubItems.Add(dr("item_date"))
                list.SubItems.Add(dr("item_how_many"))
                list.SubItems.Add(dr("item_how_many"))


                FrmLibraryMain.ItemListView.Items.Add(list)
            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub

    Public Sub ToItemEdite(ByVal item_id As String) 'បង្ហាញទិន្នន័យ ដើម្បីកែប្រែ items
        Call LibraryAutoComplete.Categorys()
        Call LibraryAutoComplete.Languages()
        Call LibraryAutoComplete.Cabinets()
        Call LibraryAutoComplete.Shelfs()
        Try
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim join As String
            join = "item.cat_id=cat.cat_id AND item.cab_id=cab.cab_id AND item.she_id=she.she_id AND item.lan_id=lan.lan_id AND item.user_id=user.user_id"
            Dim id As String = item_id
            Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on " & join & " WHERE item.item_id=" & id & " AND item_delete='N' GROUP BY item.item_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                FrmLibraryEdit.NoTextBox.Text = (dr("item_id")).ToString
                FrmLibraryEdit.CategoryComboBox.SelectedIndex = (dr("cat_index")).ToString
                FrmLibraryEdit.TitleTextBox.Text = (dr("item_title")).ToString
                FrmLibraryEdit.AuthorTextBox.Text = (dr("item_author")).ToString
                FrmLibraryEdit.EidterTextBox.Text = (dr("item_editer")).ToString
                FrmLibraryEdit.LanguageComboBox.SelectedIndex = (dr("lan_index")).ToString
                FrmLibraryEdit.PubliserDateTimePicker.Text = (dr("item_publiser")).ToString
                FrmLibraryEdit.HowManyTextBox.Text = (dr("item_how_many")).ToString
                FrmLibraryEdit.HowMuchForSellTextBox.Text = (dr("item_for_sell")).ToString
                FrmLibraryEdit.HowMuchForBorrowTextBox.Text = (dr("item_for_borrow")).ToString
                Dim pic As String = (dr("item_pic")).ToString
                If pic = "" Then
                    FrmLibraryEdit.ItemsPictureBox.Image = Image.FromFile(Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Items\Items.png")) 'ទីតាំងរូបភាព + រូបភាព
                Else
                    FrmLibraryEdit.ItemsPictureBox.Image = Image.FromFile(Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Items\" & pic)) 'ទីតាំងរូបភាព + រូបភាពពីឈ្មោះនៅក្នុង Database
                End If

                FrmLibraryEdit.CabComboBox.SelectedIndex = (dr("cab_index")).ToString
                FrmLibraryEdit.SheComboBox.SelectedIndex = (dr("she_index")).ToString
                FrmLibraryEdit.NoteTextBox.Text = (dr("note")).ToString
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Public Sub ToItemDelete(ByVal item_id As String) 'បង្ហាញទិន្នន័យ ដើម្បីលុប items

        Try
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim join As String
            join = "item.cat_id=cat.cat_id AND item.cab_id=cab.cab_id AND item.she_id=she.she_id AND item.lan_id=lan.lan_id AND item.user_id=user.user_id"
            Dim id As String = item_id
            Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on " & join & " WHERE item.item_id=" & id & " AND item_delete='N' GROUP BY item.item_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                FrmLibraryDelete.IDLabel.Text = "លេខរៀង : " & (dr("item_id")).ToString
                FrmLibraryDelete.TitleNameLabel.Text = "ចំណង់ជើង : " & (dr("item_title")).ToString
                FrmLibraryDelete.AutherLabel.Text = "អ្នកនិពន្ធ : " & (dr("item_author")).ToString
                FrmLibraryDelete.CountLabel.Text = "មានចំនួន : " & (dr("item_how_many")).ToString
                FrmLibraryDelete.OnDateLabel.Text = "កាលបរិច្ឆេទ : " & (dr("item_date"))

                Dim pic As String = (dr("item_pic")).ToString
                If pic = "" Then
                    FrmLibraryDelete.DelPictureBox.Image = Image.FromFile(Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Items\Items.png")) 'ទីតាំងរូបភាព + រូបភាព
                Else
                    FrmLibraryDelete.DelPictureBox.Image = Image.FromFile(Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Items\" & pic)) 'ទីតាំងរូបភាព + រូបភាពពីឈ្មោះនៅក្នុង Database
                End If
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub

    Public Sub ToListViewBorrow() 'បង្ហាញទិន្នន័យ អ្នកខ្ចី
        FrmLibraryMain.ItemListView.Items.Clear()

        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim join As String
            join = "item.cat_id=cat.cat_id AND item.cab_id=cab.cab_id AND item.she_id=she.she_id AND item.lan_id=lan.lan_id AND b.user_id=user.user_id AND b.item_id=item.item_id AND b.bu_id=bu.bu_id"
            Query = "SELECT b.*,bu.*,item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.*,user.*,br.* FROM borrows as b INNER JOIN borrows_users as bu inner join borrows as br inner join items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on " & join & " AND item_delete='N' AND b.br_id=2 GROUP BY b.b_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            Dim list As ListViewItem
            Dim count As Integer
            Dim fromday As DateTime
            Dim endday As DateTime
            Dim today As DateTime


            Do While dr.Read = True
                today = Format(Now, "dd/MMM/yyyy") 'ចាប់ពេលរបស់ ម៉ាស៊ីន
                fromday = dr("b_from") 'ចាប់ពេល b_from របស់ Borrows table
                endday = dr("b_end") 'ចាប់ពេល b_end របស់ Borrows table
                Dim overday As TimeSpan = endday.Subtract(today) 'ដោយយក ថ្ងៃសង - ថ្ងៃនេះ តម្លៃរបស់ចេញ សញ្ញា - ex: 5-1=-4

                Dim daycount As TimeSpan = endday.Subtract(fromday) 'ដោយយក ថ្ងៃសង - ថ្ងៃខ្ចី តម្លៃរបស់ចេញ សញ្ញា - ex: 5-1=4
                count = dr("b_how_many") * dr("item_for_borrow")

                If Convert.ToInt32(overday.Days) >= 0 Then 'បើ 4 >= 0  វានិងបង្ហាញ់ ដែលខ្ចីណាដែលនៅសល់ថ្ងៃទាំងអស់

                    list = New ListViewItem(dr("b_id").ToString)
                    list.SubItems.Add(dr("bu_fullname"))
                    list.SubItems.Add(dr("bu_phone"))
                    list.SubItems.Add(dr("cat_name"))
                    list.SubItems.Add(dr("b_how_many"))
                    list.SubItems.Add(dr("item_for_borrow"))
                    list.SubItems.Add(Format(count, "#,##0 ៛"))
                    list.SubItems.Add(dr("b_from") + " - " + dr("b_end"))
                    list.SubItems.Add(Convert.ToInt32(daycount.Days)) 'ថ្ងៃដែលសល់
                    list.SubItems.Add(dr("user_fullname"))
                    FrmLibraryMain.ItemListView.Items.Add(list)

                End If



            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Public Sub ToListViewBorrowExp() 'បង្ហាញទិន្នន័យ អ្នកខ្ចីផុតកំណត់
        FrmLibraryMain.ItemListView.Items.Clear()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim join As String
            join = "item.cat_id=cat.cat_id AND item.cab_id=cab.cab_id AND item.she_id=she.she_id AND item.lan_id=lan.lan_id AND b.user_id=user.user_id AND b.item_id=item.item_id AND b.bu_id=bu.bu_id"
            Query = "SELECT b.*,bu.*,item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.*,user.*,br.* FROM borrows as b INNER JOIN borrows_users as bu inner join borrows as br inner join items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on " & join & " AND item_delete='N' AND b.br_id=2 GROUP BY b.b_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            Dim list As ListViewItem
            Dim count As Integer
            Dim fromday As DateTime
            Dim endday As DateTime
            Dim today As DateTime

            Do While dr.Read = True
                today = Format(Now, "dd/MMM/yyyy") 'ចាប់ពេលរបស់ ម៉ាស៊ីន
                fromday = dr("b_from") 'ចាប់ពេល b_from របស់ Borrows table
                endday = dr("b_end") 'ចាប់ពេល b_end របស់ Borrows table
                Dim overday As TimeSpan = endday.Subtract(today) 'ដោយយក ថ្ងៃសង - ថ្ងៃនេះ តម្លៃរបស់ចេញ សញ្ញា - ex: 5-1=-4
                count = dr("b_how_many") * dr("item_for_borrow") 'គណនា តម្លៃ
                If Convert.ToInt32(overday.Days) < 0 Then 'បើ -4 > 0  វានិងបង្ហាញ់ ដែលខ្ចីណាដែលលើសថ្ងៃទាំងអស់
                    list = New ListViewItem(dr("b_id").ToString)
                    list.SubItems.Add(dr("bu_fullname"))
                    list.SubItems.Add(dr("bu_phone"))
                    list.SubItems.Add(dr("cat_name"))
                    list.SubItems.Add(dr("b_how_many"))
                    list.SubItems.Add(dr("item_for_borrow"))
                    list.SubItems.Add(Format(count, "#,##0 ៛")) ' ធ្វើការ កំណត់ បង្ហាញ #,##0 ៛
                    list.SubItems.Add(dr("b_from") + " - " + dr("b_end"))
                    list.SubItems.Add(Math.Abs(Convert.ToInt32(overday.Days))) 'ថ្ងៃដែលលើស 'គណនាតម្លៃដាច់ខាត |-100|=100
                    list.SubItems.Add(dr("user_fullname"))
                    FrmLibraryMain.ItemListView.Items.Add(list)
                End If

            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Public Sub ToBorrowItem(ByVal item_id As String) 'បង្ហាញទិន្នន័យ ដើម្បីធ្វើកាខ្ចី

        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim id As String = item_id
            Query = "SELECT item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.* FROM items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user on item.cat_id=cat.cat_id WHERE item.item_id=" & id & "  GROUP BY item.item_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                FrmLibraryBorrow.NoTextBox.Text = (dr("item_id"))
                FrmLibraryBorrow.CategoryComboBox.Text = (dr("cat_name"))
                FrmLibraryBorrow.TitleTextBox.Text = (dr("item_title"))
                FrmLibraryBorrow.BorrowHowMuchTextBox.Text = (dr("item_for_borrow"))

            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Public Sub ToviewBorrows_Users() 'បង្ហាញទិន្នន័យ អ្នកខ្ចីដែលបាន បង្កើតរួច
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT * FROM borrows_users"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            Do While dr.Read = True

                FrmLibraryBorrow.ViewBorrowUserListBox.Items.Add(dr("bu_id") & "-" & dr("bu_fullname"))

            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Public Sub ToUserBorrowInBox(ByVal bu_id As String) 'បង្ហាញទិន្នន័យ អ្នកខ្ចីនៅពេល ចុចលើ ឈ្មោះ

        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT * FROM borrows_users WHERE bu_id=" + bu_id
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            Do While dr.Read = True

                FrmLibraryBorrow.BorrowIDTextBox.Text = (dr("bu_id"))
                FrmLibraryBorrow.BorrowNameTextBox.Text = (dr("bu_fullname"))
                FrmLibraryBorrow.BorrowPhoneTextBox.Text = (dr("bu_phone"))
                FrmLibraryBorrow.BorrowEmailTextBox.Text = (dr("bu_email"))

            Loop

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Public Sub ToReturn(ByVal b_id As String) 'បង្ហាញទិន្នន័យ ដើម្បីធ្វើការសងវិញ

        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String

            Query = "SELECT b.*,bu.*,item.* ,cat.* ,cab.* ,she.* ,lan.* ,gro.* ,user.*,br.* FROM borrows as b INNER JOIN borrows_users as bu inner join items as item INNER JOIN items_categorys as cat INNER JOIN items_cabinets as cab INNER JOIN items_shelfs as she INNER JOIN items_languages as lan INNER JOIN users_groups as gro INNER JOIN users as user INNER JOIN borrows_returns as br on  item.cat_id=cat.cat_id AND item.cab_id=cab.cab_id AND item.she_id=she.she_id AND item.lan_id=lan.lan_id AND item.user_id=user.user_id AND b.item_id=item.item_id AND b.br_id=br.br_id AND b.bu_id=bu.bu_id AND item.item_delete='N' AND br.br_id=2 WHERE b.b_id= " & b_id & " GROUP BY b.b_id"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                FrmLibraryReturn.BorNoTextBox.Text = (dr("b_id"))
                FrmLibraryReturn.NoTextBox.Text = (dr("item_id"))
                FrmLibraryReturn.CategoryComboBox.Text = (dr("cat_name"))
                FrmLibraryReturn.TitleTextBox.Text = (dr("item_title"))
                FrmLibraryReturn.BorrowNameTextBox.Text = (dr("bu_fullname"))
                FrmLibraryReturn.BorrowIDTextBox.Text = (dr("b_id"))
                FrmLibraryReturn.BorrowPhoneTextBox.Text = (dr("bu_phone"))
                FrmLibraryReturn.BorrowEmailTextBox.Text = (dr("bu_email"))
                FrmLibraryReturn.BorrowHowManyTextBox.Text = (dr("b_how_many"))
                FrmLibraryReturn.BorrowHowMuchTextBox.Text = (dr("item_for_borrow"))
                FrmLibraryReturn.BorrowFromDateTimePicker.Text = (dr("b_from"))
                FrmLibraryReturn.BorrowEndDateTimePicker.Text = (dr("b_end"))
                FrmLibraryReturn.BorrowNoteTextBox.Text = (dr("b_note"))


            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub

    Public Sub ToUser() 'បង្ហាញទិន្នន័យ អ្នកប្រើកម្មវិធី

        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Dim user_id As String = FrmLibraryMain.IDToolStripLabel.Text
            Query = "SELECT user.*,gro.* FROM users as user INNER JOIN users_groups as gro on user.group_id=gro.group_id WHERE user_id=" & user_id
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader

            If dr.Read = True Then
                FrmLibraryUser.UserNoTextBox.Text = (dr("user_id")).ToString
                FrmLibraryUser.UserGroupComboBox.Text = (dr("group_name")).ToString
                FrmLibraryUser.UserFullnameTextBox.Text = (dr("user_fullname")).ToString
                Dim sex As String = (dr("user_sex")).ToString
                If sex = "" Then
                    FrmLibraryUser.MaleRadioButton.Checked = False
                    FrmLibraryUser.FemaleRadioButton.Checked = False
                ElseIf sex = "ប្រុស" Then
                    FrmLibraryUser.MaleRadioButton.Checked = True
                Else
                    FrmLibraryUser.FemaleRadioButton.Checked = True
                End If
                FrmLibraryUser.UserLoginTextBox.Text = (dr("user_login")).ToString
                FrmLibraryUser.UserEmailTextBox.Text = (dr("user_email")).ToString
                FrmLibraryUser.UserFacebookTextBox.Text = (dr("user_fb")).ToString
                FrmLibraryUser.UserPasswordTextBox.Text = (dr("user_pass")).ToString
                FrmLibraryUser.UserPhoneTextBox.Text = (dr("user_phone")).ToString
                Dim pic As String = (dr("user_pic")).ToString
                If pic = "" Then
                    FrmLibraryUser.UploadPictureBox.Image = Image.FromFile(Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Users\User.png")) 'ទីតាំងរូបភាព + រូបភាព
                Else
                    FrmLibraryUser.UploadPictureBox.Image = Image.FromFile(Replace(Directory.GetCurrentDirectory(), "\Debug", "\Photo\Users\" & pic)) 'ទីតាំងរូបភាព + រូបភាពពីឈ្មោះនៅក្នុង Database
                End If

            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
End Module
