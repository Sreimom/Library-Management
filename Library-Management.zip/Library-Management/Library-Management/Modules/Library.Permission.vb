﻿Module Permission
    Sub ToAdmin()
        frmlibrarymain.AddNewToolStripDropDownButton.Enabled = True
        FrmLibraryMain.EditToolStripButton.Enabled = True
        FrmLibraryMain.DeleteToolStripMenuItem.Enabled = True
        FrmLibraryMain.CreateBorrowUserToolStripButton.Enabled = True
        FrmLibraryMain.BorrowToolStripButton.Enabled = True
        'FrmLibraryMain.RetureToolStripButton.Enabled = True

        FrmLibraryMain.ContextMenuStrip1.Enabled = True
        FrmLibraryMain.BorrowToolStripMenuItem.Enabled = True
        FrmLibraryMain.EditeToolStripMenuItem.Enabled = True
        'FrmLibraryMain.ReturnToolStripMenuItem.Enabled = True
        FrmLibraryMain.DeleteToolStripButton.Enabled = True

        LibraryCount.items()
        LibraryCount.books()
        LibraryCount.magazine()
        LibraryCount.newspaper()
        LibraryCount.borrow()
    End Sub
    Sub ToEditer()
        frmlibrarymain.AddNewToolStripDropDownButton.Enabled = True
        frmlibrarymain.EditToolStripButton.Enabled = True
        frmlibrarymain.DeleteToolStripMenuItem.Enabled = False
        frmlibrarymain.CreateBorrowUserToolStripButton.Enabled = False
        frmlibrarymain.BorrowToolStripButton.Enabled = False
        frmlibrarymain.RetureToolStripButton.Enabled = False

        frmlibrarymain.ContextMenuStrip1.Enabled = True
        frmlibrarymain.BorrowToolStripMenuItem.Enabled = False
        frmlibrarymain.EditeToolStripMenuItem.Enabled = True
        frmlibrarymain.ReturnToolStripMenuItem.Enabled = False
        frmlibrarymain.DeleteToolStripButton.Enabled = False

        LibraryCount.items()
        LibraryCount.books()
        LibraryCount.magazine()
        LibraryCount.newspaper()
        LibraryCount.borrow()
    End Sub
    Sub ToUser()
        frmlibrarymain.AddNewToolStripDropDownButton.Enabled = False
        frmlibrarymain.EditToolStripButton.Enabled = False
        frmlibrarymain.DeleteToolStripMenuItem.Enabled = False
        frmlibrarymain.CreateBorrowUserToolStripButton.Enabled = False
        frmlibrarymain.BorrowToolStripButton.Enabled = False
        frmlibrarymain.RetureToolStripButton.Enabled = False

        frmlibrarymain.ContextMenuStrip1.Enabled = True
        frmlibrarymain.BorrowToolStripMenuItem.Enabled = False
        frmlibrarymain.EditeToolStripMenuItem.Enabled = False
        frmlibrarymain.ReturnToolStripMenuItem.Enabled = False
        frmlibrarymain.DeleteToolStripButton.Enabled = False

        LibraryCount.items()
        LibraryCount.books()
        LibraryCount.magazine()
        LibraryCount.newspaper()
        LibraryCount.borrow()
    End Sub


End Module
