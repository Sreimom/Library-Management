﻿Imports MySql.Data.MySqlClient

Module LibraryAutoComplete
    Dim MysqlConn = New MySqlConnection

    Sub Categorys()

        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim Query As String = "SELECT * FROM items_categorys"
        Dim cmd As New MySqlCommand(Query, MysqlConn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As New DataTable("items_categorys")
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            FrmLibraryAddnew.CategoryComboBox.DataSource = dt
            FrmLibraryAddnew.CategoryComboBox.ValueMember = "cat_id" 'The ID of the row
            FrmLibraryAddnew.CategoryComboBox.DisplayMember = "cat_name" 'What is displayed

            If IsNumeric(FrmLibraryAddnew.cat_idToolStripLabel.Text) = True Then
                FrmLibraryAddnew.CategoryComboBox.SelectedValue = FrmLibraryAddnew.cat_idToolStripLabel.Text
            End If

            FrmLibraryEdit.CategoryComboBox.DataSource = dt
            FrmLibraryEdit.CategoryComboBox.ValueMember = "cat_id" 'The ID of the row
            FrmLibraryEdit.CategoryComboBox.DisplayMember = "cat_name" 'What is displayed

        End If
    End Sub
    Sub Languages()
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim Query As String = "SELECT * FROM items_languages"
        Dim cmd As New MySqlCommand(Query, MysqlConn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As New DataTable("items_languages")
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            FrmLibraryAddnew.LanguageComboBox.DataSource = dt
            FrmLibraryAddnew.LanguageComboBox.ValueMember = "lan_id" 'The ID of the row
            FrmLibraryAddnew.LanguageComboBox.DisplayMember = "lan_name" 'What is displayed  

            FrmLibraryEdit.LanguageComboBox.DataSource = dt
            FrmLibraryEdit.LanguageComboBox.ValueMember = "lan_id" 'The ID of the row
            FrmLibraryEdit.LanguageComboBox.DisplayMember = "lan_name" 'What is displayed

        End If
    End Sub
    Sub Cabinets()
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim Query As String = "SELECT * FROM items_cabinets"
        Dim cmd As New MySqlCommand(Query, MysqlConn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As New DataTable("items_cabinets")
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            FrmLibraryAddnew.CabComboBox.DataSource = dt
            FrmLibraryAddnew.CabComboBox.ValueMember = "cab_id" 'The ID of the row
            FrmLibraryAddnew.CabComboBox.DisplayMember = "cab_name" 'What is displayed

            FrmLibraryEdit.CabComboBox.DataSource = dt
            FrmLibraryEdit.CabComboBox.ValueMember = "cab_id" 'The ID of the row
            FrmLibraryEdit.CabComboBox.DisplayMember = "cab_name" 'What is displayed

        End If
    End Sub
    Sub Shelfs()
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim Query As String = "SELECT * FROM items_shelfs"
        Dim cmd As New MySqlCommand(Query, MysqlConn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As New DataTable("items_shelfs")
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            FrmLibraryAddnew.SheComboBox.DataSource = dt
            FrmLibraryAddnew.SheComboBox.ValueMember = "she_id" 'The ID of the row
            FrmLibraryAddnew.SheComboBox.DisplayMember = "she_name" 'What is displayed 

            FrmLibraryEdit.SheComboBox.DataSource = dt
            FrmLibraryEdit.SheComboBox.ValueMember = "she_id" 'The ID of the row
            FrmLibraryEdit.SheComboBox.DisplayMember = "she_name" 'What is displayed

        End If
    End Sub


    Sub Positions()
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim Query As String = "SELECT * FROM borrows_positions"
        Dim cmd As New MySqlCommand(Query, MysqlConn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As New DataTable("borrows_positions")
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            FrmLibraryAddBorrowUser.PositionsComboBox.DataSource = dt
            FrmLibraryAddBorrowUser.PositionsComboBox.ValueMember = "bp_id" 'The ID of the row
            FrmLibraryAddBorrowUser.PositionsComboBox.DisplayMember = "bp_name" 'What is displayed

        End If
    End Sub
End Module
