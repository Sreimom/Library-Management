﻿Imports MySql.Data.MySqlClient

Module LibraryCount
    Dim MysqlConn As New MySqlConnection
    Dim dr As MySqlDataReader
    Dim cmd As MySqlCommand
    Sub items()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT Count(*)as c FROM items WHERE item_delete='N'"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then

                frmlibrarymain.AllCollectionToolStripButton.Text = "បញ្ចីសរុប    " & (dr("c"))
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Sub books()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT Count(*)as c FROM items WHERE cat_id=1 AND item_delete='N'"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then

                frmlibrarymain.BookCollectionToolStripButton.Text = "សៀវភៅ    " & (dr("c"))
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Sub magazine()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT Count(*)as c FROM items WHERE cat_id=2 AND item_delete='N'"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then

                frmlibrarymain.MagazineCollectionToolStripButton.Text = "ទស្សនាវដ្តី    " & (dr("c"))
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Sub newspaper()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT Count(*)as c FROM items WHERE cat_id=3 AND item_delete='N'"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then

                frmlibrarymain.NewspaperCollectionToolStripButton.Text = "ការសែត    " & (dr("c"))
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
    Sub borrow()
        Try
            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = My.Settings.ConnLibrary
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT Count(*)as c FROM borrows WHERE br_id=2"
            cmd = New MySqlCommand(Query, MysqlConn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then

                frmlibrarymain.BorrowCollectionToolStripButton.Text = "អ្នកខ្ចី    " & (dr("c"))
            End If

        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            MysqlConn.Close()
        End Try
    End Sub
End Module
