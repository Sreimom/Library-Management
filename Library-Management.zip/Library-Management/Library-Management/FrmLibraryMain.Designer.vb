﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryMain))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ItemListView = New System.Windows.Forms.ListView()
        Me.colid = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.coltitle = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.colauthor = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.colpublisher = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.colcategory = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.coldayadd = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.colcount = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.colinstock = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.colborrow = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.TopPanel = New System.Windows.Forms.Panel()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.GroupToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStrip3 = New System.Windows.Forms.ToolStrip()
        Me.UserToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.UserFullnameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.IDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.CountSelectedItemsToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.ItemIndexToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.AddNewToolStripDropDownButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.AddNewBookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewMagazineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewNewspaperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.DeleteToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.LogoutToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.SettingToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.InfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LanguageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KhmerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnglishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThaiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChineseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FranchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.CreateBorrowUserToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BorrowToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.RetureToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.TopToolStrip = New System.Windows.Forms.ToolStrip()
        Me.LeftToolStrip = New System.Windows.Forms.ToolStrip()
        Me.AllCollectionToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BookCollectionToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.MagazineCollectionToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.NewspaperCollectionToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BorrowCollectionToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ExpiredCollectionToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.BorrowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReturnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemInfoListBox = New System.Windows.Forms.ListBox()
        Me.SearchToolStripButton = New System.Windows.Forms.ToolStripSplitButton()
        Me.SAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STitleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SAuthorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SPubliserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SCategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.cat_idToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.UnderTopToolStrip = New System.Windows.Forms.ToolStrip()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BottomLeftPanel = New System.Windows.Forms.Panel()
        Me.WebBrowser2 = New System.Windows.Forms.WebBrowser()
        Me.IDItemsListBox = New System.Windows.Forms.ListBox()
        Me.MainPanel = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.TopPanel.SuspendLayout()
        Me.ToolStrip3.SuspendLayout()
        Me.TopToolStrip.SuspendLayout()
        Me.LeftToolStrip.SuspendLayout()
        Me.UnderTopToolStrip.SuspendLayout()
        Me.BottomLeftPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.ItemListView)
        Me.Panel1.Location = New System.Drawing.Point(190, 116)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(994, 516)
        Me.Panel1.TabIndex = 34
        '
        'ItemListView
        '
        Me.ItemListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colid, Me.coltitle, Me.colauthor, Me.colpublisher, Me.colcategory, Me.coldayadd, Me.colcount, Me.colinstock, Me.colborrow})
        Me.ItemListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ItemListView.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemListView.FullRowSelect = True
        Me.ItemListView.Location = New System.Drawing.Point(0, 0)
        Me.ItemListView.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ItemListView.Name = "ItemListView"
        Me.ItemListView.Size = New System.Drawing.Size(994, 516)
        Me.ItemListView.TabIndex = 31
        Me.ItemListView.UseCompatibleStateImageBehavior = False
        Me.ItemListView.View = System.Windows.Forms.View.Details
        '
        'colid
        '
        Me.colid.Text = "លេខរៀង"
        Me.colid.Width = 78
        '
        'coltitle
        '
        Me.coltitle.Text = "ចំណង់ជើង"
        Me.coltitle.Width = 233
        '
        'colauthor
        '
        Me.colauthor.Text = "អ្នកនិពន្ធ"
        Me.colauthor.Width = 110
        '
        'colpublisher
        '
        Me.colpublisher.Text = "បោះពុម្ភ"
        Me.colpublisher.Width = 89
        '
        'colcategory
        '
        Me.colcategory.Text = "ប្រភេទ"
        Me.colcategory.Width = 98
        '
        'coldayadd
        '
        Me.coldayadd.Text = "ថ្ងៃបញ្ចូល"
        Me.coldayadd.Width = 85
        '
        'colcount
        '
        Me.colcount.Text = "ចំនួន"
        Me.colcount.Width = 75
        '
        'colinstock
        '
        Me.colinstock.Text = "នៅក្នុងស្តុក"
        Me.colinstock.Width = 80
        '
        'colborrow
        '
        Me.colborrow.Text = "អ្នកខ្ចី"
        Me.colborrow.Width = 52
        '
        'TopPanel
        '
        Me.TopPanel.Controls.Add(Me.WebBrowser1)
        Me.TopPanel.Enabled = False
        Me.TopPanel.Location = New System.Drawing.Point(434, 1)
        Me.TopPanel.Name = "TopPanel"
        Me.TopPanel.Size = New System.Drawing.Size(550, 66)
        Me.TopPanel.TabIndex = 26
        Me.TopPanel.Visible = False
        '
        'WebBrowser1
        '
        Me.WebBrowser1.AllowNavigation = False
        Me.WebBrowser1.AllowWebBrowserDrop = False
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.IsWebBrowserContextMenuEnabled = False
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 0)
        Me.WebBrowser1.Margin = New System.Windows.Forms.Padding(0)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScrollBarsEnabled = False
        Me.WebBrowser1.Size = New System.Drawing.Size(550, 66)
        Me.WebBrowser1.TabIndex = 8
        Me.WebBrowser1.Url = New System.Uri("http://mylibrary.freesite.host/ads/550x66.html", System.UriKind.Absolute)
        Me.WebBrowser1.WebBrowserShortcutsEnabled = False
        '
        'GroupToolStripLabel
        '
        Me.GroupToolStripLabel.Name = "GroupToolStripLabel"
        Me.GroupToolStripLabel.Size = New System.Drawing.Size(52, 27)
        Me.GroupToolStripLabel.Text = "Group"
        Me.GroupToolStripLabel.Visible = False
        '
        'ToolStrip3
        '
        Me.ToolStrip3.AutoSize = False
        Me.ToolStrip3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ToolStrip3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip3.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.ToolStrip3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserToolStripLabel, Me.UserFullnameToolStripLabel, Me.GroupToolStripLabel, Me.IDToolStripLabel, Me.CountSelectedItemsToolStripLabel, Me.ToolStripSeparator13, Me.ItemIndexToolStripLabel})
        Me.ToolStrip3.Location = New System.Drawing.Point(0, 632)
        Me.ToolStrip3.Name = "ToolStrip3"
        Me.ToolStrip3.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip3.Size = New System.Drawing.Size(1184, 30)
        Me.ToolStrip3.TabIndex = 27
        Me.ToolStrip3.Text = "ToolStrip3"
        '
        'UserToolStripLabel
        '
        Me.UserToolStripLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.UserToolStripLabel.Name = "UserToolStripLabel"
        Me.UserToolStripLabel.Size = New System.Drawing.Size(56, 27)
        Me.UserToolStripLabel.Text = "អ្នកប្រើ:"
        '
        'UserFullnameToolStripLabel
        '
        Me.UserFullnameToolStripLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.UserFullnameToolStripLabel.Name = "UserFullnameToolStripLabel"
        Me.UserFullnameToolStripLabel.Size = New System.Drawing.Size(0, 27)
        '
        'IDToolStripLabel
        '
        Me.IDToolStripLabel.Name = "IDToolStripLabel"
        Me.IDToolStripLabel.Size = New System.Drawing.Size(20, 27)
        Me.IDToolStripLabel.Text = "1"
        Me.IDToolStripLabel.Visible = False
        '
        'CountSelectedItemsToolStripLabel
        '
        Me.CountSelectedItemsToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.CountSelectedItemsToolStripLabel.Margin = New System.Windows.Forms.Padding(0, 1, 20, 2)
        Me.CountSelectedItemsToolStripLabel.Name = "CountSelectedItemsToolStripLabel"
        Me.CountSelectedItemsToolStripLabel.Size = New System.Drawing.Size(62, 27)
        Me.CountSelectedItemsToolStripLabel.Text = "ចំនួន : 0"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 30)
        '
        'ItemIndexToolStripLabel
        '
        Me.ItemIndexToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ItemIndexToolStripLabel.Name = "ItemIndexToolStripLabel"
        Me.ItemIndexToolStripLabel.Size = New System.Drawing.Size(90, 27)
        Me.ItemIndexToolStripLabel.Text = "លេខរៀង :  0"
        Me.ItemIndexToolStripLabel.Visible = False
        '
        'AddNewToolStripDropDownButton
        '
        Me.AddNewToolStripDropDownButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewBookToolStripMenuItem, Me.AddNewMagazineToolStripMenuItem, Me.AddNewNewspaperToolStripMenuItem})
        Me.AddNewToolStripDropDownButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddNewToolStripDropDownButton.Image = CType(resources.GetObject("AddNewToolStripDropDownButton.Image"), System.Drawing.Image)
        Me.AddNewToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AddNewToolStripDropDownButton.Name = "AddNewToolStripDropDownButton"
        Me.AddNewToolStripDropDownButton.Size = New System.Drawing.Size(68, 67)
        Me.AddNewToolStripDropDownButton.Text = "បញ្ចូលថ្មី"
        Me.AddNewToolStripDropDownButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.AddNewToolStripDropDownButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'AddNewBookToolStripMenuItem
        '
        Me.AddNewBookToolStripMenuItem.Image = CType(resources.GetObject("AddNewBookToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddNewBookToolStripMenuItem.Name = "AddNewBookToolStripMenuItem"
        Me.AddNewBookToolStripMenuItem.Size = New System.Drawing.Size(133, 28)
        Me.AddNewBookToolStripMenuItem.Text = "សៀវភៅ"
        '
        'AddNewMagazineToolStripMenuItem
        '
        Me.AddNewMagazineToolStripMenuItem.Image = CType(resources.GetObject("AddNewMagazineToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddNewMagazineToolStripMenuItem.Name = "AddNewMagazineToolStripMenuItem"
        Me.AddNewMagazineToolStripMenuItem.Size = New System.Drawing.Size(133, 28)
        Me.AddNewMagazineToolStripMenuItem.Text = "ទស្សនាវដ្ដី"
        '
        'AddNewNewspaperToolStripMenuItem
        '
        Me.AddNewNewspaperToolStripMenuItem.Image = CType(resources.GetObject("AddNewNewspaperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddNewNewspaperToolStripMenuItem.Name = "AddNewNewspaperToolStripMenuItem"
        Me.AddNewNewspaperToolStripMenuItem.Size = New System.Drawing.Size(133, 28)
        Me.AddNewNewspaperToolStripMenuItem.Text = "កាសែត"
        '
        'EditToolStripButton
        '
        Me.EditToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditToolStripButton.Image = CType(resources.GetObject("EditToolStripButton.Image"), System.Drawing.Image)
        Me.EditToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.EditToolStripButton.Name = "EditToolStripButton"
        Me.EditToolStripButton.Padding = New System.Windows.Forms.Padding(5)
        Me.EditToolStripButton.Size = New System.Drawing.Size(54, 67)
        Me.EditToolStripButton.Text = "កែប្រែ"
        Me.EditToolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.EditToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DeleteToolStripButton
        '
        Me.DeleteToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteToolStripButton.Image = CType(resources.GetObject("DeleteToolStripButton.Image"), System.Drawing.Image)
        Me.DeleteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteToolStripButton.Name = "DeleteToolStripButton"
        Me.DeleteToolStripButton.Padding = New System.Windows.Forms.Padding(5)
        Me.DeleteToolStripButton.Size = New System.Drawing.Size(47, 67)
        Me.DeleteToolStripButton.Text = "លុប"
        Me.DeleteToolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.DeleteToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LogoutToolStripButton
        '
        Me.LogoutToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.LogoutToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.LogoutToolStripButton.Image = CType(resources.GetObject("LogoutToolStripButton.Image"), System.Drawing.Image)
        Me.LogoutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.LogoutToolStripButton.Name = "LogoutToolStripButton"
        Me.LogoutToolStripButton.Size = New System.Drawing.Size(63, 67)
        Me.LogoutToolStripButton.Text = "ចេកចេញ"
        Me.LogoutToolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.LogoutToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 70)
        '
        'SettingToolStripButton
        '
        Me.SettingToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.SettingToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InfoToolStripMenuItem, Me.LanguageToolStripMenuItem, Me.UserToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.SettingToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.SettingToolStripButton.Image = CType(resources.GetObject("SettingToolStripButton.Image"), System.Drawing.Image)
        Me.SettingToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SettingToolStripButton.Name = "SettingToolStripButton"
        Me.SettingToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.SettingToolStripButton.Size = New System.Drawing.Size(96, 67)
        Me.SettingToolStripButton.Text = "ការកំណត់"
        Me.SettingToolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.SettingToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.SettingToolStripButton.ToolTipText = "ការកំណត់"
        '
        'InfoToolStripMenuItem
        '
        Me.InfoToolStripMenuItem.Image = CType(resources.GetObject("InfoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem"
        Me.InfoToolStripMenuItem.Size = New System.Drawing.Size(145, 28)
        Me.InfoToolStripMenuItem.Text = "ការណែនាំ"
        '
        'LanguageToolStripMenuItem
        '
        Me.LanguageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KhmerToolStripMenuItem, Me.EnglishToolStripMenuItem, Me.ThaiToolStripMenuItem, Me.ChineseToolStripMenuItem, Me.FranchToolStripMenuItem})
        Me.LanguageToolStripMenuItem.Image = CType(resources.GetObject("LanguageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LanguageToolStripMenuItem.Name = "LanguageToolStripMenuItem"
        Me.LanguageToolStripMenuItem.Size = New System.Drawing.Size(145, 28)
        Me.LanguageToolStripMenuItem.Text = "ភាសា"
        '
        'KhmerToolStripMenuItem
        '
        Me.KhmerToolStripMenuItem.Image = CType(resources.GetObject("KhmerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.KhmerToolStripMenuItem.Name = "KhmerToolStripMenuItem"
        Me.KhmerToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.KhmerToolStripMenuItem.Text = "ភាសាខ្មែរ"
        '
        'EnglishToolStripMenuItem
        '
        Me.EnglishToolStripMenuItem.Image = CType(resources.GetObject("EnglishToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EnglishToolStripMenuItem.Name = "EnglishToolStripMenuItem"
        Me.EnglishToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.EnglishToolStripMenuItem.Text = "ភាសាអង់គ្លេស"
        '
        'ThaiToolStripMenuItem
        '
        Me.ThaiToolStripMenuItem.Image = CType(resources.GetObject("ThaiToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ThaiToolStripMenuItem.Name = "ThaiToolStripMenuItem"
        Me.ThaiToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.ThaiToolStripMenuItem.Text = "ភាសាថៃ"
        '
        'ChineseToolStripMenuItem
        '
        Me.ChineseToolStripMenuItem.Image = CType(resources.GetObject("ChineseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChineseToolStripMenuItem.Name = "ChineseToolStripMenuItem"
        Me.ChineseToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.ChineseToolStripMenuItem.Text = "ភាសាចិន"
        '
        'FranchToolStripMenuItem
        '
        Me.FranchToolStripMenuItem.Image = CType(resources.GetObject("FranchToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FranchToolStripMenuItem.Name = "FranchToolStripMenuItem"
        Me.FranchToolStripMenuItem.Size = New System.Drawing.Size(155, 28)
        Me.FranchToolStripMenuItem.Text = "ភាសាបារាំង"
        '
        'UserToolStripMenuItem
        '
        Me.UserToolStripMenuItem.Image = CType(resources.GetObject("UserToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UserToolStripMenuItem.Name = "UserToolStripMenuItem"
        Me.UserToolStripMenuItem.Size = New System.Drawing.Size(145, 28)
        Me.UserToolStripMenuItem.Text = "អ្នកប្រើប្រាស់"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = CType(resources.GetObject("AboutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 28)
        Me.AboutToolStripMenuItem.Text = "អំពី"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 70)
        '
        'CreateBorrowUserToolStripButton
        '
        Me.CreateBorrowUserToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CreateBorrowUserToolStripButton.Image = CType(resources.GetObject("CreateBorrowUserToolStripButton.Image"), System.Drawing.Image)
        Me.CreateBorrowUserToolStripButton.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CreateBorrowUserToolStripButton.ImageTransparentColor = System.Drawing.Color.Maroon
        Me.CreateBorrowUserToolStripButton.Name = "CreateBorrowUserToolStripButton"
        Me.CreateBorrowUserToolStripButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CreateBorrowUserToolStripButton.Size = New System.Drawing.Size(72, 67)
        Me.CreateBorrowUserToolStripButton.Text = "បង្កើតអ្នកខ្ចី"
        Me.CreateBorrowUserToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CreateBorrowUserToolStripButton.ToolTipText = "បង្កើតអ្នកខ្ចី"
        '
        'BorrowToolStripButton
        '
        Me.BorrowToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowToolStripButton.Image = CType(resources.GetObject("BorrowToolStripButton.Image"), System.Drawing.Image)
        Me.BorrowToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BorrowToolStripButton.Name = "BorrowToolStripButton"
        Me.BorrowToolStripButton.Padding = New System.Windows.Forms.Padding(5)
        Me.BorrowToolStripButton.Size = New System.Drawing.Size(63, 67)
        Me.BorrowToolStripButton.Text = "ធ្វើការខ្ចី"
        Me.BorrowToolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BorrowToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'RetureToolStripButton
        '
        Me.RetureToolStripButton.Enabled = False
        Me.RetureToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RetureToolStripButton.Image = CType(resources.GetObject("RetureToolStripButton.Image"), System.Drawing.Image)
        Me.RetureToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RetureToolStripButton.Name = "RetureToolStripButton"
        Me.RetureToolStripButton.Padding = New System.Windows.Forms.Padding(5)
        Me.RetureToolStripButton.Size = New System.Drawing.Size(88, 67)
        Me.RetureToolStripButton.Text = "សងសៀវភៅ"
        Me.RetureToolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.RetureToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 70)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 70)
        '
        'TopToolStrip
        '
        Me.TopToolStrip.AutoSize = False
        Me.TopToolStrip.BackColor = System.Drawing.Color.LightSeaGreen
        Me.TopToolStrip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TopToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.TopToolStrip.ImageScalingSize = New System.Drawing.Size(30, 30)
        Me.TopToolStrip.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.TopToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewToolStripDropDownButton, Me.EditToolStripButton, Me.DeleteToolStripButton, Me.LogoutToolStripButton, Me.ToolStripSeparator3, Me.SettingToolStripButton, Me.ToolStripSeparator1, Me.CreateBorrowUserToolStripButton, Me.BorrowToolStripButton, Me.RetureToolStripButton, Me.ToolStripSeparator2, Me.ToolStripSeparator4})
        Me.TopToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStrip.Name = "TopToolStrip"
        Me.TopToolStrip.Size = New System.Drawing.Size(1184, 70)
        Me.TopToolStrip.TabIndex = 25
        Me.TopToolStrip.Text = "ToolStrip4"
        '
        'LeftToolStrip
        '
        Me.LeftToolStrip.AutoSize = False
        Me.LeftToolStrip.BackColor = System.Drawing.Color.LightGray
        Me.LeftToolStrip.BackgroundImage = CType(resources.GetObject("LeftToolStrip.BackgroundImage"), System.Drawing.Image)
        Me.LeftToolStrip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LeftToolStrip.Dock = System.Windows.Forms.DockStyle.Left
        Me.LeftToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.LeftToolStrip.ImageScalingSize = New System.Drawing.Size(40, 40)
        Me.LeftToolStrip.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.LeftToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllCollectionToolStripButton, Me.BookCollectionToolStripButton, Me.MagazineCollectionToolStripButton, Me.NewspaperCollectionToolStripButton, Me.BorrowCollectionToolStripButton, Me.ExpiredCollectionToolStripButton})
        Me.LeftToolStrip.Location = New System.Drawing.Point(0, 70)
        Me.LeftToolStrip.Name = "LeftToolStrip"
        Me.LeftToolStrip.Size = New System.Drawing.Size(190, 562)
        Me.LeftToolStrip.TabIndex = 28
        Me.LeftToolStrip.Text = "ToolStrip1"
        '
        'AllCollectionToolStripButton
        '
        Me.AllCollectionToolStripButton.BackColor = System.Drawing.Color.Transparent
        Me.AllCollectionToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.AllCollectionToolStripButton.Image = CType(resources.GetObject("AllCollectionToolStripButton.Image"), System.Drawing.Image)
        Me.AllCollectionToolStripButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.AllCollectionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AllCollectionToolStripButton.Name = "AllCollectionToolStripButton"
        Me.AllCollectionToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.AllCollectionToolStripButton.Size = New System.Drawing.Size(188, 64)
        Me.AllCollectionToolStripButton.Text = "បញ្ចីសរុប"
        '
        'BookCollectionToolStripButton
        '
        Me.BookCollectionToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BookCollectionToolStripButton.Image = CType(resources.GetObject("BookCollectionToolStripButton.Image"), System.Drawing.Image)
        Me.BookCollectionToolStripButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BookCollectionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BookCollectionToolStripButton.Name = "BookCollectionToolStripButton"
        Me.BookCollectionToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.BookCollectionToolStripButton.Size = New System.Drawing.Size(188, 64)
        Me.BookCollectionToolStripButton.Text = "សៀវភៅ"
        '
        'MagazineCollectionToolStripButton
        '
        Me.MagazineCollectionToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.MagazineCollectionToolStripButton.Image = CType(resources.GetObject("MagazineCollectionToolStripButton.Image"), System.Drawing.Image)
        Me.MagazineCollectionToolStripButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MagazineCollectionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MagazineCollectionToolStripButton.Name = "MagazineCollectionToolStripButton"
        Me.MagazineCollectionToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.MagazineCollectionToolStripButton.Size = New System.Drawing.Size(188, 64)
        Me.MagazineCollectionToolStripButton.Text = "ទស្សនាវដ្តី"
        '
        'NewspaperCollectionToolStripButton
        '
        Me.NewspaperCollectionToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.NewspaperCollectionToolStripButton.Image = CType(resources.GetObject("NewspaperCollectionToolStripButton.Image"), System.Drawing.Image)
        Me.NewspaperCollectionToolStripButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NewspaperCollectionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewspaperCollectionToolStripButton.Name = "NewspaperCollectionToolStripButton"
        Me.NewspaperCollectionToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.NewspaperCollectionToolStripButton.Size = New System.Drawing.Size(188, 64)
        Me.NewspaperCollectionToolStripButton.Text = "ការសែត"
        '
        'BorrowCollectionToolStripButton
        '
        Me.BorrowCollectionToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowCollectionToolStripButton.Image = CType(resources.GetObject("BorrowCollectionToolStripButton.Image"), System.Drawing.Image)
        Me.BorrowCollectionToolStripButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BorrowCollectionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BorrowCollectionToolStripButton.Name = "BorrowCollectionToolStripButton"
        Me.BorrowCollectionToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.BorrowCollectionToolStripButton.Size = New System.Drawing.Size(188, 64)
        Me.BorrowCollectionToolStripButton.Text = "អ្នកខ្ចី"
        '
        'ExpiredCollectionToolStripButton
        '
        Me.ExpiredCollectionToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ExpiredCollectionToolStripButton.Image = CType(resources.GetObject("ExpiredCollectionToolStripButton.Image"), System.Drawing.Image)
        Me.ExpiredCollectionToolStripButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ExpiredCollectionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ExpiredCollectionToolStripButton.Name = "ExpiredCollectionToolStripButton"
        Me.ExpiredCollectionToolStripButton.Padding = New System.Windows.Forms.Padding(10)
        Me.ExpiredCollectionToolStripButton.Size = New System.Drawing.Size(188, 64)
        Me.ExpiredCollectionToolStripButton.Text = "ហួសកំណត់"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Margin = New System.Windows.Forms.Padding(10)
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'BorrowToolStripMenuItem
        '
        Me.BorrowToolStripMenuItem.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowToolStripMenuItem.Image = CType(resources.GetObject("BorrowToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BorrowToolStripMenuItem.Name = "BorrowToolStripMenuItem"
        Me.BorrowToolStripMenuItem.Size = New System.Drawing.Size(86, 28)
        Me.BorrowToolStripMenuItem.Text = "ខ្ចី"
        '
        'ReturnToolStripMenuItem
        '
        Me.ReturnToolStripMenuItem.Enabled = False
        Me.ReturnToolStripMenuItem.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.ReturnToolStripMenuItem.Image = CType(resources.GetObject("ReturnToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ReturnToolStripMenuItem.Name = "ReturnToolStripMenuItem"
        Me.ReturnToolStripMenuItem.Size = New System.Drawing.Size(117, 28)
        Me.ReturnToolStripMenuItem.Text = "សងវិញ"
        '
        'EditeToolStripMenuItem
        '
        Me.EditeToolStripMenuItem.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.EditeToolStripMenuItem.Image = CType(resources.GetObject("EditeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditeToolStripMenuItem.Name = "EditeToolStripMenuItem"
        Me.EditeToolStripMenuItem.Size = New System.Drawing.Size(117, 28)
        Me.EditeToolStripMenuItem.Text = "កែប្រែ"
        '
        'ItemInfoListBox
        '
        Me.ItemInfoListBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ItemInfoListBox.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.ItemInfoListBox.FormattingEnabled = True
        Me.ItemInfoListBox.ItemHeight = 24
        Me.ItemInfoListBox.Location = New System.Drawing.Point(0, 0)
        Me.ItemInfoListBox.Name = "ItemInfoListBox"
        Me.ItemInfoListBox.Size = New System.Drawing.Size(188, 145)
        Me.ItemInfoListBox.TabIndex = 32
        Me.ItemInfoListBox.Visible = False
        '
        'SearchToolStripButton
        '
        Me.SearchToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SAllToolStripMenuItem, Me.STitleToolStripMenuItem, Me.SAuthorToolStripMenuItem, Me.SPubliserToolStripMenuItem, Me.SCategoryToolStripMenuItem})
        Me.SearchToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchToolStripButton.Image = CType(resources.GetObject("SearchToolStripButton.Image"), System.Drawing.Image)
        Me.SearchToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SearchToolStripButton.Name = "SearchToolStripButton"
        Me.SearchToolStripButton.Size = New System.Drawing.Size(81, 40)
        Me.SearchToolStripButton.Text = "ស្វែងរក"
        Me.SearchToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'SAllToolStripMenuItem
        '
        Me.SAllToolStripMenuItem.Checked = True
        Me.SAllToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.SAllToolStripMenuItem.Name = "SAllToolStripMenuItem"
        Me.SAllToolStripMenuItem.Size = New System.Drawing.Size(138, 28)
        Me.SAllToolStripMenuItem.Text = "ទាំងអស់"
        '
        'STitleToolStripMenuItem
        '
        Me.STitleToolStripMenuItem.Name = "STitleToolStripMenuItem"
        Me.STitleToolStripMenuItem.Size = New System.Drawing.Size(138, 28)
        Me.STitleToolStripMenuItem.Text = "ចំណងជើង"
        '
        'SAuthorToolStripMenuItem
        '
        Me.SAuthorToolStripMenuItem.Name = "SAuthorToolStripMenuItem"
        Me.SAuthorToolStripMenuItem.Size = New System.Drawing.Size(138, 28)
        Me.SAuthorToolStripMenuItem.Text = "អ្នកនិពន្ធ"
        '
        'SPubliserToolStripMenuItem
        '
        Me.SPubliserToolStripMenuItem.Name = "SPubliserToolStripMenuItem"
        Me.SPubliserToolStripMenuItem.Size = New System.Drawing.Size(138, 28)
        Me.SPubliserToolStripMenuItem.Text = "បោះពុម្ព"
        '
        'SCategoryToolStripMenuItem
        '
        Me.SCategoryToolStripMenuItem.Name = "SCategoryToolStripMenuItem"
        Me.SCategoryToolStripMenuItem.Size = New System.Drawing.Size(138, 28)
        Me.SCategoryToolStripMenuItem.Text = "ប្រភេទ"
        '
        'SearchToolStripTextBox
        '
        Me.SearchToolStripTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchToolStripTextBox.Name = "SearchToolStripTextBox"
        Me.SearchToolStripTextBox.Size = New System.Drawing.Size(300, 43)
        '
        'cat_idToolStripLabel
        '
        Me.cat_idToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.cat_idToolStripLabel.Name = "cat_idToolStripLabel"
        Me.cat_idToolStripLabel.Size = New System.Drawing.Size(38, 40)
        Me.cat_idToolStripLabel.Text = "cat_id"
        Me.cat_idToolStripLabel.Visible = False
        '
        'UnderTopToolStrip
        '
        Me.UnderTopToolStrip.AutoSize = False
        Me.UnderTopToolStrip.BackColor = System.Drawing.SystemColors.ControlLight
        Me.UnderTopToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.UnderTopToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SearchToolStripButton, Me.SearchToolStripTextBox, Me.cat_idToolStripLabel})
        Me.UnderTopToolStrip.Location = New System.Drawing.Point(190, 70)
        Me.UnderTopToolStrip.Name = "UnderTopToolStrip"
        Me.UnderTopToolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.UnderTopToolStrip.Size = New System.Drawing.Size(994, 43)
        Me.UnderTopToolStrip.TabIndex = 29
        Me.UnderTopToolStrip.Text = "ToolStrip2"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.DeleteToolStripMenuItem.Image = CType(resources.GetObject("DeleteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(117, 28)
        Me.DeleteToolStripMenuItem.Text = "លុប"
        '
        'BottomLeftPanel
        '
        Me.BottomLeftPanel.Controls.Add(Me.WebBrowser2)
        Me.BottomLeftPanel.Controls.Add(Me.IDItemsListBox)
        Me.BottomLeftPanel.Controls.Add(Me.ItemInfoListBox)
        Me.BottomLeftPanel.Location = New System.Drawing.Point(2, 487)
        Me.BottomLeftPanel.Name = "BottomLeftPanel"
        Me.BottomLeftPanel.Size = New System.Drawing.Size(188, 145)
        Me.BottomLeftPanel.TabIndex = 32
        '
        'WebBrowser2
        '
        Me.WebBrowser2.AllowNavigation = False
        Me.WebBrowser2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser2.IsWebBrowserContextMenuEnabled = False
        Me.WebBrowser2.Location = New System.Drawing.Point(0, 0)
        Me.WebBrowser2.Margin = New System.Windows.Forms.Padding(0)
        Me.WebBrowser2.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser2.Name = "WebBrowser2"
        Me.WebBrowser2.ScrollBarsEnabled = False
        Me.WebBrowser2.Size = New System.Drawing.Size(188, 145)
        Me.WebBrowser2.TabIndex = 9
        Me.WebBrowser2.Url = New System.Uri("http://mylibrary.freesite.host/ads/185x135.html", System.UriKind.Absolute)
        '
        'IDItemsListBox
        '
        Me.IDItemsListBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.IDItemsListBox.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.IDItemsListBox.FormattingEnabled = True
        Me.IDItemsListBox.ItemHeight = 24
        Me.IDItemsListBox.Location = New System.Drawing.Point(0, 0)
        Me.IDItemsListBox.Name = "IDItemsListBox"
        Me.IDItemsListBox.Size = New System.Drawing.Size(188, 145)
        Me.IDItemsListBox.TabIndex = 33
        Me.IDItemsListBox.Visible = False
        '
        'MainPanel
        '
        Me.MainPanel.Location = New System.Drawing.Point(0, 0)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Size = New System.Drawing.Size(1192, 670)
        Me.MainPanel.TabIndex = 36
        '
        'FrmLibraryMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1184, 662)
        Me.Controls.Add(Me.MainPanel)
        Me.Controls.Add(Me.BottomLeftPanel)
        Me.Controls.Add(Me.TopPanel)
        Me.Controls.Add(Me.UnderTopToolStrip)
        Me.Controls.Add(Me.LeftToolStrip)
        Me.Controls.Add(Me.TopToolStrip)
        Me.Controls.Add(Me.ToolStrip3)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FrmLibraryMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmLibraryMain"
        Me.Panel1.ResumeLayout(False)
        Me.TopPanel.ResumeLayout(False)
        Me.ToolStrip3.ResumeLayout(False)
        Me.ToolStrip3.PerformLayout()
        Me.TopToolStrip.ResumeLayout(False)
        Me.TopToolStrip.PerformLayout()
        Me.LeftToolStrip.ResumeLayout(False)
        Me.LeftToolStrip.PerformLayout()
        Me.UnderTopToolStrip.ResumeLayout(False)
        Me.UnderTopToolStrip.PerformLayout()
        Me.BottomLeftPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ItemListView As System.Windows.Forms.ListView
    Friend WithEvents colid As System.Windows.Forms.ColumnHeader
    Friend WithEvents coltitle As System.Windows.Forms.ColumnHeader
    Friend WithEvents colauthor As System.Windows.Forms.ColumnHeader
    Friend WithEvents colpublisher As System.Windows.Forms.ColumnHeader
    Friend WithEvents colcategory As System.Windows.Forms.ColumnHeader
    Friend WithEvents coldayadd As System.Windows.Forms.ColumnHeader
    Friend WithEvents colcount As System.Windows.Forms.ColumnHeader
    Friend WithEvents colinstock As System.Windows.Forms.ColumnHeader
    Friend WithEvents colborrow As System.Windows.Forms.ColumnHeader
    Friend WithEvents ItemInfoListBox As System.Windows.Forms.ListBox
    Friend WithEvents TopPanel As System.Windows.Forms.Panel
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents GroupToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStrip3 As System.Windows.Forms.ToolStrip
    Friend WithEvents UserToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents UserFullnameToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents IDToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents CountSelectedItemsToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ItemIndexToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents AddNewToolStripDropDownButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents AddNewBookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewMagazineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewNewspaperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents LogoutToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SettingToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents InfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LanguageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KhmerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnglishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThaiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChineseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FranchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CreateBorrowUserToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents BorrowToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents RetureToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TopToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents LeftToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents AllCollectionToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents BookCollectionToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents MagazineCollectionToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents NewspaperCollectionToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents BorrowCollectionToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ExpiredCollectionToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents BorrowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReturnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchToolStripButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents SAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STitleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SAuthorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SPubliserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SCategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents cat_idToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents UnderTopToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BottomLeftPanel As System.Windows.Forms.Panel
    Friend WithEvents WebBrowser2 As System.Windows.Forms.WebBrowser
    Friend WithEvents MainPanel As System.Windows.Forms.Panel
    Friend WithEvents IDItemsListBox As System.Windows.Forms.ListBox

End Class
