﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryStart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryStart))
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TryButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ConnectLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(15, 49)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(417, 25)
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.ProgressBar1.TabIndex = 2
        '
        'Timer1
        '
        '
        'TryButton
        '
        Me.TryButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.TryButton.ImageIndex = 1
        Me.TryButton.ImageList = Me.ImageList1
        Me.TryButton.Location = New System.Drawing.Point(359, 102)
        Me.TryButton.Name = "TryButton"
        Me.TryButton.Size = New System.Drawing.Size(120, 35)
        Me.TryButton.TabIndex = 5
        Me.TryButton.Text = "ភ្ចាប់ម្តងទៀត"
        Me.TryButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.TryButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "2.png")
        '
        'ConnectLabel
        '
        Me.ConnectLabel.AutoSize = True
        Me.ConnectLabel.BackColor = System.Drawing.Color.Transparent
        Me.ConnectLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ConnectLabel.ForeColor = System.Drawing.Color.White
        Me.ConnectLabel.Location = New System.Drawing.Point(10, 19)
        Me.ConnectLabel.Name = "ConnectLabel"
        Me.ConnectLabel.Size = New System.Drawing.Size(189, 27)
        Me.ConnectLabel.TabIndex = 3
        Me.ConnectLabel.Text = "កំពុងតភ្ចាប់ទៅកាន់បណ្តាញ ..."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.25!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(434, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 25)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "0"
        '
        'CloseButton
        '
        Me.CloseButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.CloseButton.ImageIndex = 0
        Me.CloseButton.ImageList = Me.ImageList1
        Me.CloseButton.Location = New System.Drawing.Point(15, 102)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(103, 35)
        Me.CloseButton.TabIndex = 6
        Me.CloseButton.Text = "បោះបង់"
        Me.CloseButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'FrmLibraryStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(488, 102)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.TryButton)
        Me.Controls.Add(Me.ConnectLabel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CloseButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FrmLibraryStart"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmLibraryStart"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TryButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ConnectLabel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CloseButton As System.Windows.Forms.Button
End Class
