﻿Imports System.Text.RegularExpressions
Imports System.Text
Public Class FrmLibraryMain
    Dim CW As Integer = Me.Width ' Current Width
    Dim CH As Integer = Me.Height ' Current Height
    Dim IW As Integer = Me.Width ' Initial Width
    Dim IH As Integer = Me.Height ' Initial Height

    Sub ResizeForm() 'ធ្វើអោយ Form Resize
        Dim RW As Double = (Me.Width - CW) / CW ' Ratio change of width
        Dim RH As Double = (Me.Height - CH) / CH ' Ratio change of height
        For Each Ctrl As Control In Controls
            Ctrl.Width += CInt(Ctrl.Width * RW)
            Ctrl.Height += CInt(Ctrl.Height * RH)
            Ctrl.Left += CInt(Ctrl.Left * RW)
            Ctrl.Top += CInt(Ctrl.Top * RH)
        Next
        CW = Me.Width
        CH = Me.Height
    End Sub
    Private Sub FrmMain_SizeChanged(sender As Object, e As EventArgs) Handles Me.SizeChanged
        If Me.WindowState = FormWindowState.Maximized Then
            Me.ResizeForm() 'Call from sub
        ElseIf Me.WindowState = FormWindowState.Normal Then
            Me.ResizeForm() 'Call from sub
        End If
    End Sub


    Private Sub AddNewToolStripDropDownButton_Click(sender As Object, e As EventArgs) Handles AddNewToolStripDropDownButton.Click
        FrmLibraryAddnew.ShowDialog()
    End Sub

    Private Sub EditToolStripButton_Click(sender As Object, e As EventArgs) Handles EditToolStripButton.Click

        FrmLibraryEdit.ListBox1.SelectedIndex = 0
        Dim i As Integer = Regex.Replace(CountSelectedItemsToolStripLabel.Text, "[^\d]", "") 'Regex សម្រាប់លុបអក្សរទុកតែលេខ

        If i <= 1 Then
            FrmLibraryEdit.Width = 750
            FrmLibraryEdit.ShowDialog()
        Else
            FrmLibraryEdit.Width = 970
            FrmLibraryEdit.ShowDialog()
        End If

    End Sub

    Private Sub DeleteToolStripButton_Click(sender As Object, e As EventArgs) Handles DeleteToolStripButton.Click

        FrmLibraryDelete.ShowDialog()
    End Sub

    Private Sub CreateBorrowUserToolStripButton_Click(sender As Object, e As EventArgs) Handles CreateBorrowUserToolStripButton.Click
        FrmLibraryAddBorrowUser.ShowDialog()
    End Sub

    Private Sub BorrowToolStripButton_Click(sender As Object, e As EventArgs) Handles BorrowToolStripButton.Click
        FrmLibraryBorrow.ListBox1.SelectedIndex = 0
        Dim i As Integer = Regex.Replace(CountSelectedItemsToolStripLabel.Text, "[^\d]", "") 'Regex សម្រាប់លុបអក្សរទុកតែលេខ

        If i <= 1 Then
            FrmLibraryBorrow.Width = 750
            FrmLibraryBorrow.ShowDialog()
        Else
            FrmLibraryBorrow.Width = 970
            FrmLibraryBorrow.ShowDialog()
        End If

    End Sub

    Private Sub RetureToolStripButton_Click(sender As Object, e As EventArgs) Handles RetureToolStripButton.Click
        FrmLibraryReturn.ListBox1.SelectedIndex = 0
        Dim i As Integer = Regex.Replace(CountSelectedItemsToolStripLabel.Text, "[^\d]", "") 'Regex សម្រាប់លុបអក្សរទុកតែលេខ

        If i <= 1 Then
            FrmLibraryReturn.Width = 750
            FrmLibraryReturn.ShowDialog()
        Else
            FrmLibraryReturn.Width = 970
            FrmLibraryReturn.ShowDialog()
        End If


    End Sub

    Private Sub UserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UserToolStripMenuItem.Click
        FrmLibraryUser.ShowDialog()
    End Sub

    Private Sub AddNewBookToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewBookToolStripMenuItem.Click
        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.White
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        FrmLibraryAddnew.cat_idToolStripLabel.Text = "1"
        FrmLibraryAddnew.ShowDialog()
    End Sub

    Private Sub AddNewMagazineToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewMagazineToolStripMenuItem.Click
        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.White
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        FrmLibraryAddnew.cat_idToolStripLabel.Text = "2"
        FrmLibraryAddnew.ShowDialog()
    End Sub

    Private Sub AddNewNewspaperToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewNewspaperToolStripMenuItem.Click
        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.White
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        FrmLibraryAddnew.cat_idToolStripLabel.Text = "3"
        FrmLibraryAddnew.ShowDialog()
    End Sub
    Private Sub BorrowCollectionToolStripButton_Click(sender As Object, e As EventArgs) Handles BorrowCollectionToolStripButton.Click

        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.White
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        Call BorrowView()
        Call LibraryGetData.ToListViewBorrow()
    End Sub

    Private Sub ExpiredCollectionToolStripButton_Click(sender As Object, e As EventArgs) Handles ExpiredCollectionToolStripButton.Click
        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.White
        Call BorrowExp()
        Call LibraryGetData.ToListViewBorrowExp()
    End Sub
    Sub AllViewColumns()
        ItemListView.Columns.Clear()
        ItemListView.Columns.Add("លេខរៀង", 70)
        ItemListView.Columns.Add("ចំណងជើង", 240)
        ItemListView.Columns.Add("អ្នកនិពន្ធ", 110)
        ItemListView.Columns.Add("បោះពុម្ភ", 90)
        ItemListView.Columns.Add("ប្រភេទ", 100)
        ItemListView.Columns.Add("ថ្ងៃបញ្ចូល", 90)
        ItemListView.Columns.Add("ចំនួន", 50)
        ItemListView.Columns.Add("នៅក្នុងស្តុក", 90)
        ItemListView.Columns.Add("អ្នកខ្ចី(ន)", 70)

        Me.RetureToolStripButton.Enabled = False
        Me.BorrowToolStripButton.Enabled = True
        Me.BorrowToolStripMenuItem.Enabled = True
        Me.ReturnToolStripMenuItem.Enabled = False
        'Me.PermissionIS()
    End Sub
    Sub BorrowView()
        ItemListView.Columns.Clear()
        ItemListView.Columns.Add("ល.រ", 50)
        ItemListView.Columns.Add("ឈ្មោះ", 130)
        ItemListView.Columns.Add("ទូរស័ព្ទ", 90)
        ItemListView.Columns.Add("បានខ្ចី", 100)
        ItemListView.Columns.Add("ចំនួនខ្ចី", 50)
        ItemListView.Columns.Add("តម្លៃ/១ក្បាល(៛)", 100)
        ItemListView.Columns.Add("តម្លៃសរុប (៛)", 80)
        ItemListView.Columns.Add("ចាប់ពីថ្ងៃ-ដល់ថ្ងៃ", 160)
        ItemListView.Columns.Add("សល់", 50)
        ItemListView.Columns.Add("អ្នកអោយខ្ចី", 100)

        Me.RetureToolStripButton.Enabled = True
        Me.BorrowToolStripButton.Enabled = False
        Me.BorrowToolStripMenuItem.Enabled = False
        Me.ReturnToolStripMenuItem.Enabled = True

        'Me.PermissionIS()
    End Sub
    Sub BorrowExp()
        ItemListView.Columns.Clear()
        ItemListView.Columns.Add("ល.រ", 50)
        ItemListView.Columns.Add("ឈ្មោះ", 130)
        ItemListView.Columns.Add("ទូរស័ព្ទ", 90)
        ItemListView.Columns.Add("បានខ្ចី", 100)
        ItemListView.Columns.Add("ចំនួនខ្ចី", 50)
        ItemListView.Columns.Add("តម្លៃ/១ក្បាល(៛)", 100)
        ItemListView.Columns.Add("តម្លៃសរុប (៛)", 80)
        ItemListView.Columns.Add("ចាប់ពីថ្ងៃ-ដល់ថ្ងៃ", 160)
        ItemListView.Columns.Add("លើស", 50)
        ItemListView.Columns.Add("អ្នកអោយខ្ចី", 100)

        Me.RetureToolStripButton.Enabled = True
        Me.BorrowToolStripButton.Enabled = False
        Me.BorrowToolStripMenuItem.Enabled = False
        Me.ReturnToolStripMenuItem.Enabled = True

        'Me.PermissionIS()
    End Sub
    Sub PermissionIS()
        If GroupToolStripLabel.Text = 1 Then ' Admin
            Permission.ToAdmin()
        ElseIf GroupToolStripLabel.Text = 2 Then 'Editer
            Permission.ToEditer()
        ElseIf GroupToolStripLabel.Text = 3 Then 'user
            Permission.ToUser()
        End If
    End Sub
  
    Private Sub FrmLibraryMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        'FrmLibraryLogin.ShowDialog()
        FrmLibraryStart.ShowDialog()
        AllCollectionToolStripButton.BackColor = Color.White
        Call AllViewColumns()
        Call LibraryGetData.ToListViewAll()
        Me.Refresh()
    End Sub

    Private Sub AllCollectionToolStripButton_Click(sender As Object, e As EventArgs) Handles AllCollectionToolStripButton.Click
        Me.PermissionIS()

        AllCollectionToolStripButton.BackColor = Color.White
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent
        cat_idToolStripLabel.Text = "cat_id"
        Call AllViewColumns()
        Call LibraryGetData.ToListViewAll()
    End Sub

    Private Sub BookCollectionToolStripButton_Click(sender As Object, e As EventArgs) Handles BookCollectionToolStripButton.Click
        Me.PermissionIS()

        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.White
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        cat_idToolStripLabel.Text = 1
        Call AllViewColumns()
        Call LibraryGetData.ToListViewAll()
    End Sub

    Private Sub MagazineCollectionToolStripButton_Click(sender As Object, e As EventArgs) Handles MagazineCollectionToolStripButton.Click
        Me.PermissionIS()

        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.White
        NewspaperCollectionToolStripButton.BackColor = Color.Transparent
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        cat_idToolStripLabel.Text = 2
        Call AllViewColumns()
        Call LibraryGetData.ToListViewAll()
    End Sub

    Private Sub NewspaperCollectionToolStripButton_Click(sender As Object, e As EventArgs) Handles NewspaperCollectionToolStripButton.Click
        Me.PermissionIS()

        AllCollectionToolStripButton.BackColor = Color.Transparent
        BookCollectionToolStripButton.BackColor = Color.Transparent
        MagazineCollectionToolStripButton.BackColor = Color.Transparent
        NewspaperCollectionToolStripButton.BackColor = Color.White
        BorrowCollectionToolStripButton.BackColor = Color.Transparent
        ExpiredCollectionToolStripButton.BackColor = Color.Transparent

        cat_idToolStripLabel.Text = 3
        Call AllViewColumns()
        Call LibraryGetData.ToListViewAll()
    End Sub
    Sub SelectedAllInListBox() 'Select ទិន្នន័យទាំងអស់អី Listbox អោទៅ Textbox
        Dim ToTextBox1InFrmDelete As New StringBuilder()
        For Each i As Object In ItemInfoListBox.Items
            ToTextBox1InFrmDelete.AppendLine(i.ToString())
        Next
        FrmLibraryDelete.TextBox1.Text = ToTextBox1InFrmDelete.ToString()



    End Sub
    Sub SelectedAllInCMDTextBox() 'Select ទិន្នន័យទាំងអស់អី Listbox អោទៅ Textbox
        Dim ToTextBoxCMDInFrmDelete As New StringBuilder()
        For Each i As Object In IDItemsListBox.Items
            ToTextBoxCMDInFrmDelete.AppendLine("UPDATE items SET item_delete='Y' WHERE item_id=" & Regex.Replace(i, "[^\d]", "") & ";")
        Next
        FrmLibraryDelete.CMDTextBox.Text = ToTextBoxCMDInFrmDelete.ToString()
    End Sub
    Sub CheckDuplicate()
        On Error Resume Next
        Dim i As Integer = (Regex.Replace(ItemIndexToolStripLabel.Text, "[^\d]", ""))
        'Dim ItemViewIndex As Integer = ItemListView.SelectedIndices(i).ToString
        Dim Item As String = ItemListView.Items(i).SubItems(0).Text & " - " & ItemListView.Items(i).SubItems(1).Text
        Dim ItemDel As String = ItemListView.Items(i).SubItems(0).Text
        For j = 0 To ItemInfoListBox.Items.Count - 1

            ItemInfoListBox.SelectedIndex = j
            If LCase(ItemInfoListBox.SelectedItem) = LCase(ItemIndexToolStripLabel.Text) Then
                If ItemInfoListBox.SelectedIndex <> ItemInfoListBox.Items.Count - 1 Then
                    ItemInfoListBox.SelectedIndex += 1
                    ItemInfoListBox.SelectedIndex += j
                    Exit For

                End If
            ElseIf LCase(ItemInfoListBox.SelectedItem) <> LCase(ItemIndexToolStripLabel.Text) Then
                If ItemInfoListBox.SelectedIndex = ItemInfoListBox.Items.Count - 1 Then
                    ItemInfoListBox.Items.Add(Item)
                    IDItemsListBox.Items.Add(ItemDel)
                    FrmLibraryEdit.ListBox1.Items.Add(Item)
                    FrmLibraryBorrow.ListBox1.Items.Add(Item)
                    FrmLibraryReturn.ListBox1.Items.Add(Item)
                    Call SelectedAllInListBox()
                    Call SelectedAllInCMDTextBox()
                    ItemInfoListBox.SelectedIndex = ItemInfoListBox.Items.Count - 1
                    Exit Sub
                End If
            End If

        Next
        If ItemInfoListBox.Items.Count <= 0 Then
            ItemInfoListBox.Items.Add(Item)
            IDItemsListBox.Items.Add(ItemDel)
            FrmLibraryEdit.ListBox1.Items.Add(Item)
            FrmLibraryBorrow.ListBox1.Items.Add(Item)
            FrmLibraryReturn.ListBox1.Items.Add(Item)
            Call SelectedAllInListBox()
            Call SelectedAllInCMDTextBox()

        End If
    End Sub
    Sub CountSelectedItems() 'រាប់ចំនួន Select
        Dim i As Integer
        Dim NoSelectedItems As Integer = 0
        For i = 0 To ItemListView.Items.Count - 1
            If ItemListView.Items(i).Selected = True Then
                NoSelectedItems = NoSelectedItems + 1
                CountSelectedItemsToolStripLabel.Text = "ចំនួន : " & NoSelectedItems
                ItemIndexToolStripLabel.Text = "លេខរៀង : " & i
                Call CheckDuplicate()
            End If

        Next i
    End Sub

    Private Sub ItemListView_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ItemListView.SelectedIndexChanged

        'AddNewToolStripDropDownButton.Enabled = False
        EditToolStripButton.Enabled = False
        DeleteToolStripButton.Enabled = False
        CreateBorrowUserToolStripButton.Enabled = False
        BorrowToolStripButton.Enabled = False
        RetureToolStripButton.Enabled = False

        ItemInfoListBox.Items.Clear()
        IDItemsListBox.Items.Clear()
        FrmLibraryBorrow.ListBox1.Items.Clear()
        FrmLibraryReturn.ListBox1.Items.Clear()
        FrmLibraryEdit.ListBox1.Items.Clear()
        Call CountSelectedItems()
    End Sub


    Private Sub SearchToolStripTextBox_TextChanged(sender As Object, e As EventArgs) Handles SearchToolStripTextBox.TextChanged
        FrmLibrarySearch.AllCollection()
    End Sub

    Private Sub LogoutToolStripButton_Click(sender As Object, e As EventArgs) Handles LogoutToolStripButton.Click
        MainPanel.Show()
        FrmLibraryLogin.ShowDialog()

    End Sub

End Class