﻿Imports System.IO

Public Class FrmLibraryAddBorrowUser
    Private Sub IsEmpty()
        If BorrowFullnameTextBox.Text = "" Then
            BorrowFullnameLabel.ForeColor = Color.Red
            BorrowFullnameTextBox.Focus()
        ElseIf ChooseSexLabel.Text = "choose" Then
            SexGroupBox.ForeColor = Color.Red
        ElseIf BorrowPhoneTextBox.Text = "" Then
            BorrowPhoneLabel.ForeColor = Color.Red
            BorrowFullnameTextBox.Focus()
        ElseIf BorrowEmailTextBox.Text = "" Then
            BorrowEmailLabel.ForeColor = Color.Red
            BorrowEmailTextBox.Focus()
        Else
            BorrowFullnameLabel.ForeColor = Color.Black
            SexGroupBox.ForeColor = Color.Black
            BorrowPhoneTextBox.ForeColor = Color.Black
            BorrowEmailLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub MaleRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles MaleRadioButton.CheckedChanged
        ChooseSexLabel.Text = "Male"
    End Sub

    Private Sub FeMaleRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles FeMaleRadioButton.CheckedChanged
        ChooseSexLabel.Text = "Female"
    End Sub
    Private Sub BorrowCreateButton_Click(sender As Object, e As EventArgs) Handles BorrowCreateButton.Click
        Call IsEmpty()
        If BorrowFullnameTextBox.Text <> "" And ChooseSexLabel.Text <> "choose" And BorrowPhoneTextBox.Text <> "" And BorrowEmailTextBox.Text <> "" Then
            FrmLibraryProcessing.Timer1.Start()
            FrmLibraryProcessing.Timer1.Enabled = True
            FrmLibraryProcessing.Timer1.Interval = 10

            Dim Sex As String
            If MaleRadioButton.Checked = True Then
                Sex = "ប្រុស"
            Else
                Sex = "ស្រី"
            End If
            Dim PicRename As String = TimeOfDay.ToString("hh-mm-ss")
            PicRename = Replace(PicRename, "-", "")
            If IsNothing(UploadPictureBox.Image) Then
                PicRename = "user.png"
            Else
                PicRename = PicRename & ".jpg"
                Dim path As String = Replace(Directory.GetCurrentDirectory(), "\Debug", "\Library-Management\Photo\Borrows\Photo\ " & PicRename)
                UploadPictureBox.Image.Save(path, Drawing.Imaging.ImageFormat.Jpeg)
            End If

            CMDTextBox.Text = "INSERT INTO borrows_users " & _
                "(bp_id, bu_fullname,bu_sex, bu_phone, bu_email, bu_photo) VALUE " & _
                "('" & PositionsComboBox.SelectedValue & _
                "','" & BorrowFullnameTextBox.Text & _
                "','" & Sex & _
                "','" & BorrowPhoneTextBox.Text & _
                "','" & BorrowEmailTextBox.Text & _
                "','" & PicRename & "')"
            LibraryCommand.SQL(CMDTextBox.Text)
            Me.Close()
        End If
    End Sub

    Private Sub frmaddborrowuser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LibraryAutoComplete.Positions()
    End Sub
End Class