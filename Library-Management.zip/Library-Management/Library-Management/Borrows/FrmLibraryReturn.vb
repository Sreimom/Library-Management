﻿Imports System.Text.RegularExpressions

Public Class FrmLibraryReturn

    Private Sub ReturnButton_Click(sender As Object, e As EventArgs) Handles ReturnButton.Click
        CMDTextBox.Text = "UPDATE borrows SET br_id=1 WHERE b_id=" & BorNoTextBox.Text & "" 'ធ្វើការសង ដោយ ប្តូរ ពី br_id=2 មក 1"

        FrmLibraryProcessing.Timer1.Start()
        FrmLibraryProcessing.Timer1.Enabled = True
        FrmLibraryProcessing.Timer1.Interval = 5

        LibraryCommand.SQL(CMDTextBox.Text)

        Dim j As Integer = ListBox1.SelectedIndex
        ListBox1.Items.RemoveAt(j)
        If ListBox1.Items.Count > 0 Then
            ListBox1.SelectedIndex = 0
        Else
            Me.Close()
        End If
    End Sub

    Sub ItemInfoView()
        Dim i As Integer
        For i = 0 To Me.ListBox1.Items.Count - 1
            If ListBox1.SelectedIndex = i Then
                Dim j As String = ListBox1.Items(i).ToString()
                Dim getlen As String = j.IndexOf("-")
                j = Microsoft.VisualBasic.Left(j, getlen)
                j = (Regex.Replace(j, "[^\d]", ""))
                NoTextBox.Text = j
                LibraryGetData.ToReturn(j)
            End If
        Next i
    End Sub
    Private Sub ListBox1_DoubleClick(sender As Object, e As EventArgs) Handles ListBox1.DoubleClick
        Call ItemInfoView()
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

        Call ItemInfoView()
    End Sub

    Private Sub FrmLibraryReturn_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class