﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryAddBorrowUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryAddBorrowUser))
        Me.SexGroupBox = New System.Windows.Forms.GroupBox()
        Me.ChooseSexLabel = New System.Windows.Forms.Label()
        Me.FeMaleRadioButton = New System.Windows.Forms.RadioButton()
        Me.MaleRadioButton = New System.Windows.Forms.RadioButton()
        Me.UserCancelButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.PositionsComboBox = New System.Windows.Forms.ComboBox()
        Me.PositionsLabel = New System.Windows.Forms.Label()
        Me.BorrowFullnameLabel = New System.Windows.Forms.Label()
        Me.BorrowPhoneTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowEmailTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowEmailLabel = New System.Windows.Forms.Label()
        Me.BorrowPhoneLabel = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.FileToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.CreateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VillToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ComToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.DisToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ProToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.UploadsBorrowPicButton = New System.Windows.Forms.Button()
        Me.UploadPictureBox = New System.Windows.Forms.PictureBox()
        Me.BorrowCreateButton = New System.Windows.Forms.Button()
        Me.VillComboBox = New System.Windows.Forms.ComboBox()
        Me.DisComboBox = New System.Windows.Forms.ComboBox()
        Me.ComComboBox = New System.Windows.Forms.ComboBox()
        Me.ProComboBox = New System.Windows.Forms.ComboBox()
        Me.BorrowPicLabel = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.CaptureBorrowUserButton = New System.Windows.Forms.Button()
        Me.BorrowFullnameTextBox = New System.Windows.Forms.TextBox()
        Me.VillLabel = New System.Windows.Forms.Label()
        Me.ComLabel = New System.Windows.Forms.Label()
        Me.DisLabel = New System.Windows.Forms.Label()
        Me.ProLabel = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.SexGroupBox.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.UploadPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SexGroupBox
        '
        Me.SexGroupBox.Controls.Add(Me.ChooseSexLabel)
        Me.SexGroupBox.Controls.Add(Me.FeMaleRadioButton)
        Me.SexGroupBox.Controls.Add(Me.MaleRadioButton)
        Me.SexGroupBox.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.SexGroupBox.Location = New System.Drawing.Point(11, 129)
        Me.SexGroupBox.Name = "SexGroupBox"
        Me.SexGroupBox.Size = New System.Drawing.Size(253, 71)
        Me.SexGroupBox.TabIndex = 30
        Me.SexGroupBox.TabStop = False
        Me.SexGroupBox.Text = "ភេទ"
        '
        'ChooseSexLabel
        '
        Me.ChooseSexLabel.AutoSize = True
        Me.ChooseSexLabel.Location = New System.Drawing.Point(96, 22)
        Me.ChooseSexLabel.Name = "ChooseSexLabel"
        Me.ChooseSexLabel.Size = New System.Drawing.Size(60, 27)
        Me.ChooseSexLabel.TabIndex = 2
        Me.ChooseSexLabel.Text = "choose"
        Me.ChooseSexLabel.Visible = False
        '
        'FeMaleRadioButton
        '
        Me.FeMaleRadioButton.AutoSize = True
        Me.FeMaleRadioButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.FeMaleRadioButton.Location = New System.Drawing.Point(163, 33)
        Me.FeMaleRadioButton.Name = "FeMaleRadioButton"
        Me.FeMaleRadioButton.Size = New System.Drawing.Size(45, 28)
        Me.FeMaleRadioButton.TabIndex = 0
        Me.FeMaleRadioButton.TabStop = True
        Me.FeMaleRadioButton.Text = "ស្រី"
        Me.FeMaleRadioButton.UseVisualStyleBackColor = True
        '
        'MaleRadioButton
        '
        Me.MaleRadioButton.AutoSize = True
        Me.MaleRadioButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.MaleRadioButton.Location = New System.Drawing.Point(36, 33)
        Me.MaleRadioButton.Name = "MaleRadioButton"
        Me.MaleRadioButton.Size = New System.Drawing.Size(54, 28)
        Me.MaleRadioButton.TabIndex = 0
        Me.MaleRadioButton.TabStop = True
        Me.MaleRadioButton.Text = "ប្រុស"
        Me.MaleRadioButton.UseVisualStyleBackColor = True
        '
        'UserCancelButton
        '
        Me.UserCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UserCancelButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserCancelButton.ImageIndex = 0
        Me.UserCancelButton.ImageList = Me.ImageList1
        Me.UserCancelButton.Location = New System.Drawing.Point(9, 463)
        Me.UserCancelButton.Name = "UserCancelButton"
        Me.UserCancelButton.Size = New System.Drawing.Size(92, 34)
        Me.UserCancelButton.TabIndex = 12
        Me.UserCancelButton.Text = "បោះបង់"
        Me.UserCancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.UserCancelButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "floppy-icon.png")
        Me.ImageList1.Images.SetKeyName(2, "folder-yellow-explorer-icon.png")
        Me.ImageList1.Images.SetKeyName(3, "loysaevhusmyqimlzgpy.png")
        '
        'PositionsComboBox
        '
        Me.PositionsComboBox.DropDownHeight = 200
        Me.PositionsComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PositionsComboBox.FormattingEnabled = True
        Me.PositionsComboBox.IntegralHeight = False
        Me.PositionsComboBox.Location = New System.Drawing.Point(8, 31)
        Me.PositionsComboBox.Name = "PositionsComboBox"
        Me.PositionsComboBox.Size = New System.Drawing.Size(256, 32)
        Me.PositionsComboBox.TabIndex = 1
        '
        'PositionsLabel
        '
        Me.PositionsLabel.AutoSize = True
        Me.PositionsLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.PositionsLabel.Location = New System.Drawing.Point(4, 4)
        Me.PositionsLabel.Name = "PositionsLabel"
        Me.PositionsLabel.Size = New System.Drawing.Size(57, 27)
        Me.PositionsLabel.TabIndex = 0
        Me.PositionsLabel.Text = "អ្នកខ្ចីជា"
        '
        'BorrowFullnameLabel
        '
        Me.BorrowFullnameLabel.AutoSize = True
        Me.BorrowFullnameLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowFullnameLabel.Location = New System.Drawing.Point(6, 66)
        Me.BorrowFullnameLabel.Name = "BorrowFullnameLabel"
        Me.BorrowFullnameLabel.Size = New System.Drawing.Size(50, 27)
        Me.BorrowFullnameLabel.TabIndex = 0
        Me.BorrowFullnameLabel.Text = "ឈ្មោះ"
        '
        'BorrowPhoneTextBox
        '
        Me.BorrowPhoneTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowPhoneTextBox.Location = New System.Drawing.Point(11, 230)
        Me.BorrowPhoneTextBox.Name = "BorrowPhoneTextBox"
        Me.BorrowPhoneTextBox.Size = New System.Drawing.Size(256, 32)
        Me.BorrowPhoneTextBox.TabIndex = 3
        '
        'BorrowEmailTextBox
        '
        Me.BorrowEmailTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEmailTextBox.Location = New System.Drawing.Point(13, 291)
        Me.BorrowEmailTextBox.Name = "BorrowEmailTextBox"
        Me.BorrowEmailTextBox.Size = New System.Drawing.Size(254, 32)
        Me.BorrowEmailTextBox.TabIndex = 4
        '
        'BorrowEmailLabel
        '
        Me.BorrowEmailLabel.AutoSize = True
        Me.BorrowEmailLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowEmailLabel.Location = New System.Drawing.Point(6, 265)
        Me.BorrowEmailLabel.Name = "BorrowEmailLabel"
        Me.BorrowEmailLabel.Size = New System.Drawing.Size(52, 27)
        Me.BorrowEmailLabel.TabIndex = 2
        Me.BorrowEmailLabel.Text = "អ៊ីម៉ែល"
        '
        'BorrowPhoneLabel
        '
        Me.BorrowPhoneLabel.AutoSize = True
        Me.BorrowPhoneLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowPhoneLabel.Location = New System.Drawing.Point(6, 200)
        Me.BorrowPhoneLabel.Name = "BorrowPhoneLabel"
        Me.BorrowPhoneLabel.Size = New System.Drawing.Size(52, 27)
        Me.BorrowPhoneLabel.TabIndex = 4
        Me.BorrowPhoneLabel.Text = "ទូរស័ព្ទ"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripButton, Me.VillToolStripLabel, Me.ComToolStripLabel, Me.DisToolStripLabel, Me.ProToolStripLabel})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(734, 29)
        Me.ToolStrip1.TabIndex = 36
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'FileToolStripButton
        '
        Me.FileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileToolStripButton.Image = CType(resources.GetObject("FileToolStripButton.Image"), System.Drawing.Image)
        Me.FileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileToolStripButton.Name = "FileToolStripButton"
        Me.FileToolStripButton.Size = New System.Drawing.Size(59, 26)
        Me.FileToolStripButton.Text = "ឯកសារ"
        '
        'CreateToolStripMenuItem
        '
        Me.CreateToolStripMenuItem.Image = CType(resources.GetObject("CreateToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CreateToolStripMenuItem.Name = "CreateToolStripMenuItem"
        Me.CreateToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.CreateToolStripMenuItem.Text = "រក្សាទុក"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.CloseToolStripMenuItem.Text = "&បិទ"
        '
        'VillToolStripLabel
        '
        Me.VillToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.VillToolStripLabel.Name = "VillToolStripLabel"
        Me.VillToolStripLabel.Size = New System.Drawing.Size(23, 26)
        Me.VillToolStripLabel.Text = "Vill"
        Me.VillToolStripLabel.Visible = False
        '
        'ComToolStripLabel
        '
        Me.ComToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ComToolStripLabel.Name = "ComToolStripLabel"
        Me.ComToolStripLabel.Size = New System.Drawing.Size(33, 26)
        Me.ComToolStripLabel.Text = "Com"
        Me.ComToolStripLabel.Visible = False
        '
        'DisToolStripLabel
        '
        Me.DisToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.DisToolStripLabel.Name = "DisToolStripLabel"
        Me.DisToolStripLabel.Size = New System.Drawing.Size(23, 26)
        Me.DisToolStripLabel.Text = "Dis"
        Me.DisToolStripLabel.Visible = False
        '
        'ProToolStripLabel
        '
        Me.ProToolStripLabel.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ProToolStripLabel.Name = "ProToolStripLabel"
        Me.ProToolStripLabel.Size = New System.Drawing.Size(25, 26)
        Me.ProToolStripLabel.Text = "Pro"
        Me.ProToolStripLabel.Visible = False
        '
        'CMDTextBox
        '
        Me.CMDTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CMDTextBox.Location = New System.Drawing.Point(3, 546)
        Me.CMDTextBox.Multiline = True
        Me.CMDTextBox.Name = "CMDTextBox"
        Me.CMDTextBox.Size = New System.Drawing.Size(731, 121)
        Me.CMDTextBox.TabIndex = 35
        '
        'UploadsBorrowPicButton
        '
        Me.UploadsBorrowPicButton.Enabled = False
        Me.UploadsBorrowPicButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.UploadsBorrowPicButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.UploadsBorrowPicButton.ImageIndex = 2
        Me.UploadsBorrowPicButton.ImageList = Me.ImageList1
        Me.UploadsBorrowPicButton.Location = New System.Drawing.Point(300, 264)
        Me.UploadsBorrowPicButton.Name = "UploadsBorrowPicButton"
        Me.UploadsBorrowPicButton.Size = New System.Drawing.Size(99, 34)
        Me.UploadsBorrowPicButton.TabIndex = 10
        Me.UploadsBorrowPicButton.Text = "ជ្រើសរើស..."
        Me.UploadsBorrowPicButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.UploadsBorrowPicButton.UseVisualStyleBackColor = True
        '
        'UploadPictureBox
        '
        Me.UploadPictureBox.BackgroundImage = CType(resources.GetObject("UploadPictureBox.BackgroundImage"), System.Drawing.Image)
        Me.UploadPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.UploadPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.UploadPictureBox.Location = New System.Drawing.Point(300, 31)
        Me.UploadPictureBox.Name = "UploadPictureBox"
        Me.UploadPictureBox.Size = New System.Drawing.Size(229, 221)
        Me.UploadPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.UploadPictureBox.TabIndex = 29
        Me.UploadPictureBox.TabStop = False
        '
        'BorrowCreateButton
        '
        Me.BorrowCreateButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BorrowCreateButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowCreateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BorrowCreateButton.ImageIndex = 1
        Me.BorrowCreateButton.ImageList = Me.ImageList1
        Me.BorrowCreateButton.Location = New System.Drawing.Point(438, 463)
        Me.BorrowCreateButton.Name = "BorrowCreateButton"
        Me.BorrowCreateButton.Size = New System.Drawing.Size(92, 34)
        Me.BorrowCreateButton.TabIndex = 13
        Me.BorrowCreateButton.Text = "បង្កើត"
        Me.BorrowCreateButton.UseVisualStyleBackColor = True
        '
        'VillComboBox
        '
        Me.VillComboBox.DropDownHeight = 200
        Me.VillComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.VillComboBox.Enabled = False
        Me.VillComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VillComboBox.FormattingEnabled = True
        Me.VillComboBox.IntegralHeight = False
        Me.VillComboBox.Location = New System.Drawing.Point(275, 415)
        Me.VillComboBox.Name = "VillComboBox"
        Me.VillComboBox.Size = New System.Drawing.Size(254, 32)
        Me.VillComboBox.TabIndex = 9
        '
        'DisComboBox
        '
        Me.DisComboBox.DropDownHeight = 200
        Me.DisComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DisComboBox.Enabled = False
        Me.DisComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisComboBox.FormattingEnabled = True
        Me.DisComboBox.IntegralHeight = False
        Me.DisComboBox.Location = New System.Drawing.Point(275, 353)
        Me.DisComboBox.Name = "DisComboBox"
        Me.DisComboBox.Size = New System.Drawing.Size(254, 32)
        Me.DisComboBox.TabIndex = 7
        '
        'ComComboBox
        '
        Me.ComComboBox.DropDownHeight = 200
        Me.ComComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComComboBox.Enabled = False
        Me.ComComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComComboBox.FormattingEnabled = True
        Me.ComComboBox.IntegralHeight = False
        Me.ComComboBox.Location = New System.Drawing.Point(10, 415)
        Me.ComComboBox.Name = "ComComboBox"
        Me.ComComboBox.Size = New System.Drawing.Size(254, 32)
        Me.ComComboBox.TabIndex = 8
        '
        'ProComboBox
        '
        Me.ProComboBox.DropDownHeight = 200
        Me.ProComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ProComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProComboBox.FormattingEnabled = True
        Me.ProComboBox.IntegralHeight = False
        Me.ProComboBox.Location = New System.Drawing.Point(10, 353)
        Me.ProComboBox.Name = "ProComboBox"
        Me.ProComboBox.Size = New System.Drawing.Size(254, 32)
        Me.ProComboBox.TabIndex = 6
        '
        'BorrowPicLabel
        '
        Me.BorrowPicLabel.AutoSize = True
        Me.BorrowPicLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowPicLabel.Location = New System.Drawing.Point(368, 4)
        Me.BorrowPicLabel.Name = "BorrowPicLabel"
        Me.BorrowPicLabel.Size = New System.Drawing.Size(52, 27)
        Me.BorrowPicLabel.TabIndex = 0
        Me.BorrowPicLabel.Text = "រូបភាព"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Control
        Me.Panel3.Location = New System.Drawing.Point(559, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(175, 22)
        Me.Panel3.TabIndex = 39
        '
        'CaptureBorrowUserButton
        '
        Me.CaptureBorrowUserButton.Enabled = False
        Me.CaptureBorrowUserButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.CaptureBorrowUserButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CaptureBorrowUserButton.ImageIndex = 3
        Me.CaptureBorrowUserButton.ImageList = Me.ImageList1
        Me.CaptureBorrowUserButton.Location = New System.Drawing.Point(430, 264)
        Me.CaptureBorrowUserButton.Name = "CaptureBorrowUserButton"
        Me.CaptureBorrowUserButton.Size = New System.Drawing.Size(99, 34)
        Me.CaptureBorrowUserButton.TabIndex = 11
        Me.CaptureBorrowUserButton.Text = "ថតរូប"
        Me.CaptureBorrowUserButton.UseVisualStyleBackColor = True
        '
        'BorrowFullnameTextBox
        '
        Me.BorrowFullnameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.BorrowFullnameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.BorrowFullnameTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowFullnameTextBox.Location = New System.Drawing.Point(9, 93)
        Me.BorrowFullnameTextBox.Name = "BorrowFullnameTextBox"
        Me.BorrowFullnameTextBox.Size = New System.Drawing.Size(255, 32)
        Me.BorrowFullnameTextBox.TabIndex = 2
        '
        'VillLabel
        '
        Me.VillLabel.AutoSize = True
        Me.VillLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.VillLabel.Location = New System.Drawing.Point(271, 388)
        Me.VillLabel.Name = "VillLabel"
        Me.VillLabel.Size = New System.Drawing.Size(32, 27)
        Me.VillLabel.TabIndex = 2
        Me.VillLabel.Text = "ភូមិ"
        '
        'ComLabel
        '
        Me.ComLabel.AutoSize = True
        Me.ComLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ComLabel.Location = New System.Drawing.Point(6, 388)
        Me.ComLabel.Name = "ComLabel"
        Me.ComLabel.Size = New System.Drawing.Size(79, 27)
        Me.ComLabel.TabIndex = 2
        Me.ComLabel.Text = "ឃុំ / សង្តាត់"
        '
        'DisLabel
        '
        Me.DisLabel.AutoSize = True
        Me.DisLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.DisLabel.Location = New System.Drawing.Point(271, 326)
        Me.DisLabel.Name = "DisLabel"
        Me.DisLabel.Size = New System.Drawing.Size(85, 27)
        Me.DisLabel.TabIndex = 2
        Me.DisLabel.Text = "ស្រុក / ខ័ណ្អ"
        '
        'ProLabel
        '
        Me.ProLabel.AutoSize = True
        Me.ProLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ProLabel.Location = New System.Drawing.Point(6, 326)
        Me.ProLabel.Name = "ProLabel"
        Me.ProLabel.Size = New System.Drawing.Size(74, 27)
        Me.ProLabel.TabIndex = 2
        Me.ProLabel.Text = "ខេត្ត / ក្រុង"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.SexGroupBox)
        Me.Panel1.Controls.Add(Me.CaptureBorrowUserButton)
        Me.Panel1.Controls.Add(Me.UploadsBorrowPicButton)
        Me.Panel1.Controls.Add(Me.UploadPictureBox)
        Me.Panel1.Controls.Add(Me.BorrowCreateButton)
        Me.Panel1.Controls.Add(Me.UserCancelButton)
        Me.Panel1.Controls.Add(Me.VillComboBox)
        Me.Panel1.Controls.Add(Me.DisComboBox)
        Me.Panel1.Controls.Add(Me.ComComboBox)
        Me.Panel1.Controls.Add(Me.ProComboBox)
        Me.Panel1.Controls.Add(Me.PositionsComboBox)
        Me.Panel1.Controls.Add(Me.BorrowPicLabel)
        Me.Panel1.Controls.Add(Me.PositionsLabel)
        Me.Panel1.Controls.Add(Me.BorrowFullnameLabel)
        Me.Panel1.Controls.Add(Me.BorrowFullnameTextBox)
        Me.Panel1.Controls.Add(Me.BorrowPhoneTextBox)
        Me.Panel1.Controls.Add(Me.BorrowEmailTextBox)
        Me.Panel1.Controls.Add(Me.VillLabel)
        Me.Panel1.Controls.Add(Me.ComLabel)
        Me.Panel1.Controls.Add(Me.DisLabel)
        Me.Panel1.Controls.Add(Me.ProLabel)
        Me.Panel1.Controls.Add(Me.BorrowEmailLabel)
        Me.Panel1.Controls.Add(Me.BorrowPhoneLabel)
        Me.Panel1.Location = New System.Drawing.Point(193, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(541, 510)
        Me.Panel1.TabIndex = 38
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Location = New System.Drawing.Point(3, 26)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(190, 516)
        Me.Panel2.TabIndex = 37
        '
        'FrmLibraryAddBorrowUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(734, 543)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryAddBorrowUser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.SexGroupBox.ResumeLayout(False)
        Me.SexGroupBox.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.UploadPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SexGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ChooseSexLabel As System.Windows.Forms.Label
    Friend WithEvents FeMaleRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents MaleRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents UserCancelButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents PositionsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents PositionsLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowFullnameLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowPhoneTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowEmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowEmailLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowPhoneLabel As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents FileToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents CreateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VillToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ComToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents DisToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ProToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UploadsBorrowPicButton As System.Windows.Forms.Button
    Friend WithEvents UploadPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents BorrowCreateButton As System.Windows.Forms.Button
    Friend WithEvents VillComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DisComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ComComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ProComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents BorrowPicLabel As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents CaptureBorrowUserButton As System.Windows.Forms.Button
    Friend WithEvents BorrowFullnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents VillLabel As System.Windows.Forms.Label
    Friend WithEvents ComLabel As System.Windows.Forms.Label
    Friend WithEvents DisLabel As System.Windows.Forms.Label
    Friend WithEvents ProLabel As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
