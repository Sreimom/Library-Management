﻿Imports System.Text.RegularExpressions

Public Class FrmLibraryBorrow
    Private Sub IsEmpty()
        If BorrowIDTextBox.Text = "" Then
            BorrowIDLabel.ForeColor = Color.Red
            MsgBox("Please Search User ! ")
            SearchBorrowTextBox.Focus()
        Else
            BorrowIDLabel.ForeColor = Color.Black
        End If

    End Sub
    Private Sub BorrowButton_Click(sender As Object, e As EventArgs) Handles BorrowButton.Click
        Call IsEmpty()
        If BorrowHowManyTextBox.Text = "" Then
            BorrowHowManyLabel.ForeColor = Color.Red
            BorrowHowManyTextBox.Focus()
        Else
            FrmLibraryProcessing.Timer1.Start()
            FrmLibraryProcessing.Timer1.Enabled = True
            FrmLibraryProcessing.Timer1.Interval = 10

            CMDTextBox.Text = "INSERT INTO borrows" & _
                "(item_id,bu_id,b_how_many,b_from,b_end,b_note,user_id) value " & _
                "('" & NoTextBox.Text & _
                "','" & BorrowIDTextBox.Text & _
                "','" & BorrowHowManyTextBox.Text & _
                "','" & BorrowFromDateTimePicker.Text & _
                "','" & BorrowEndDateTimePicker.Text & _
                "','" & BorrowNoteTextBox.Text & _
                "'," & FrmLibraryMain.IDToolStripLabel.Text & ")"
            LibraryCommand.SQL(CMDTextBox.Text)
        End If
    End Sub
    Sub BorrowUsers()
        Dim i As Integer
        For i = 0 To Me.ViewBorrowUserListBox.Items.Count - 1
            If ViewBorrowUserListBox.SelectedIndex = i Then
                LibraryGetData.ToUserBorrowInBox(Regex.Replace(ViewBorrowUserListBox.Items(i), "[^\d]", ""))
            End If
        Next i
    End Sub
    Sub ItemInfo()
        Dim i As Integer
        For i = 0 To Me.ListBox1.Items.Count - 1
            If ListBox1.SelectedIndex = i Then
                Dim j As String = ListBox1.Items(i).ToString()
                Dim getlen As String = j.IndexOf("-")
                j = Microsoft.VisualBasic.Left(j, getlen)
                j = (Regex.Replace(j, "[^\d]", ""))
                LibraryGetData.ToBorrowItem(j)
            End If
        Next i
    End Sub
    Private Sub ViewBorrowUserListBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ViewBorrowUserListBox.SelectedIndexChanged
        BorrowUsers()
    End Sub

    Private Sub frmborrow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ViewBorrowUserListBox.Items.Clear()
        LibraryGetData.ToviewBorrows_Users()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        ItemInfo()
    End Sub

    Private Sub SearchBorrowTextBox_TextChanged(sender As Object, e As EventArgs) Handles SearchBorrowTextBox.TextChanged
        FrmLibrarySearch.UserBorrow()
    End Sub
End Class