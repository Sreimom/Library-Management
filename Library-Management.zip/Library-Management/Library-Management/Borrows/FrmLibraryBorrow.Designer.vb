﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryBorrow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryBorrow))
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.SearchBorrowTextBox = New System.Windows.Forms.TextBox()
        Me.ViewBorrowUserListBox = New System.Windows.Forms.ListBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.BorrowEndDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.BorrowFromDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.BorrowCancelButton = New System.Windows.Forms.Button()
        Me.CategoryComboBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NoLabel = New System.Windows.Forms.Label()
        Me.BorrowNoteLabel = New System.Windows.Forms.Label()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.BorrowHowManyLabel = New System.Windows.Forms.Label()
        Me.TitleTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowPhoneTextBox = New System.Windows.Forms.TextBox()
        Me.CreateBorrowUserToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BorrowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrowEmailLabel = New System.Windows.Forms.Label()
        Me.BorrowEmailTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowHowManyTextBox = New System.Windows.Forms.TextBox()
        Me.NoTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowIDTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowNameTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowNoteTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowHowMuchTextBox = New System.Windows.Forms.TextBox()
        Me.FileToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrowIDLabel = New System.Windows.Forms.Label()
        Me.BorrowNameLabel = New System.Windows.Forms.Label()
        Me.BorrowFromLabel = New System.Windows.Forms.Label()
        Me.BorrowHowMuchLabel = New System.Windows.Forms.Label()
        Me.BorrowPhoneLabel = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BorrowEndLabel = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 24
        Me.ListBox1.Location = New System.Drawing.Point(759, 33)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(178, 484)
        Me.ListBox1.TabIndex = 44
        '
        'SearchBorrowTextBox
        '
        Me.SearchBorrowTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchBorrowTextBox.Location = New System.Drawing.Point(2, 1)
        Me.SearchBorrowTextBox.Name = "SearchBorrowTextBox"
        Me.SearchBorrowTextBox.Size = New System.Drawing.Size(176, 36)
        Me.SearchBorrowTextBox.TabIndex = 11
        '
        'ViewBorrowUserListBox
        '
        Me.ViewBorrowUserListBox.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ViewBorrowUserListBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ViewBorrowUserListBox.Font = New System.Drawing.Font("Khmer OS Battambang", 12.75!)
        Me.ViewBorrowUserListBox.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.ViewBorrowUserListBox.FormattingEnabled = True
        Me.ViewBorrowUserListBox.ItemHeight = 31
        Me.ViewBorrowUserListBox.Location = New System.Drawing.Point(4, 36)
        Me.ViewBorrowUserListBox.Name = "ViewBorrowUserListBox"
        Me.ViewBorrowUserListBox.Size = New System.Drawing.Size(175, 465)
        Me.ViewBorrowUserListBox.TabIndex = 12
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.SearchBorrowTextBox)
        Me.Panel2.Controls.Add(Me.ViewBorrowUserListBox)
        Me.Panel2.Location = New System.Drawing.Point(-1, 33)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(182, 511)
        Me.Panel2.TabIndex = 41
        '
        'CMDTextBox
        '
        Me.CMDTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CMDTextBox.Location = New System.Drawing.Point(3, 545)
        Me.CMDTextBox.Multiline = True
        Me.CMDTextBox.Name = "CMDTextBox"
        Me.CMDTextBox.Size = New System.Drawing.Size(731, 121)
        Me.CMDTextBox.TabIndex = 40
        '
        'BorrowButton
        '
        Me.BorrowButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BorrowButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BorrowButton.ImageIndex = 1
        Me.BorrowButton.ImageList = Me.ImageList1
        Me.BorrowButton.Location = New System.Drawing.Point(445, 464)
        Me.BorrowButton.Name = "BorrowButton"
        Me.BorrowButton.Size = New System.Drawing.Size(92, 33)
        Me.BorrowButton.TabIndex = 10
        Me.BorrowButton.Text = "ធ្វើការខ្ចី"
        Me.BorrowButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BorrowButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "borrow_item.png")
        '
        'BorrowEndDateTimePicker
        '
        Me.BorrowEndDateTimePicker.CalendarFont = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEndDateTimePicker.CustomFormat = "dd/MMM/yyyy"
        Me.BorrowEndDateTimePicker.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEndDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.BorrowEndDateTimePicker.Location = New System.Drawing.Point(282, 341)
        Me.BorrowEndDateTimePicker.Name = "BorrowEndDateTimePicker"
        Me.BorrowEndDateTimePicker.Size = New System.Drawing.Size(255, 32)
        Me.BorrowEndDateTimePicker.TabIndex = 7
        '
        'BorrowFromDateTimePicker
        '
        Me.BorrowFromDateTimePicker.CalendarFont = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowFromDateTimePicker.CustomFormat = "dd/MMM/yyyy"
        Me.BorrowFromDateTimePicker.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowFromDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.BorrowFromDateTimePicker.Location = New System.Drawing.Point(16, 341)
        Me.BorrowFromDateTimePicker.Name = "BorrowFromDateTimePicker"
        Me.BorrowFromDateTimePicker.Size = New System.Drawing.Size(255, 32)
        Me.BorrowFromDateTimePicker.TabIndex = 6
        '
        'BorrowCancelButton
        '
        Me.BorrowCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BorrowCancelButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BorrowCancelButton.ImageIndex = 0
        Me.BorrowCancelButton.ImageList = Me.ImageList1
        Me.BorrowCancelButton.Location = New System.Drawing.Point(16, 464)
        Me.BorrowCancelButton.Name = "BorrowCancelButton"
        Me.BorrowCancelButton.Size = New System.Drawing.Size(92, 33)
        Me.BorrowCancelButton.TabIndex = 9
        Me.BorrowCancelButton.Text = "បោះបង់"
        Me.BorrowCancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BorrowCancelButton.UseVisualStyleBackColor = True
        '
        'CategoryComboBox
        '
        Me.CategoryComboBox.DropDownHeight = 200
        Me.CategoryComboBox.Enabled = False
        Me.CategoryComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CategoryComboBox.FormattingEnabled = True
        Me.CategoryComboBox.IntegralHeight = False
        Me.CategoryComboBox.Location = New System.Drawing.Point(282, 31)
        Me.CategoryComboBox.Name = "CategoryComboBox"
        Me.CategoryComboBox.Size = New System.Drawing.Size(255, 32)
        Me.CategoryComboBox.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.Label1.Location = New System.Drawing.Point(277, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ប្រភេទ"
        '
        'NoLabel
        '
        Me.NoLabel.AutoSize = True
        Me.NoLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.NoLabel.Location = New System.Drawing.Point(11, 4)
        Me.NoLabel.Name = "NoLabel"
        Me.NoLabel.Size = New System.Drawing.Size(67, 27)
        Me.NoLabel.TabIndex = 0
        Me.NoLabel.Text = "លេខរៀង"
        '
        'BorrowNoteLabel
        '
        Me.BorrowNoteLabel.AutoSize = True
        Me.BorrowNoteLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowNoteLabel.Location = New System.Drawing.Point(12, 376)
        Me.BorrowNoteLabel.Name = "BorrowNoteLabel"
        Me.BorrowNoteLabel.Size = New System.Drawing.Size(53, 27)
        Me.BorrowNoteLabel.TabIndex = 27
        Me.BorrowNoteLabel.Text = "ផ្សេងៗ"
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.TitleLabel.Location = New System.Drawing.Point(12, 66)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(78, 27)
        Me.TitleLabel.TabIndex = 0
        Me.TitleLabel.Text = "ចំណងជើង"
        '
        'BorrowHowManyLabel
        '
        Me.BorrowHowManyLabel.AutoSize = True
        Me.BorrowHowManyLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowHowManyLabel.Location = New System.Drawing.Point(11, 252)
        Me.BorrowHowManyLabel.Name = "BorrowHowManyLabel"
        Me.BorrowHowManyLabel.Size = New System.Drawing.Size(52, 27)
        Me.BorrowHowManyLabel.TabIndex = 4
        Me.BorrowHowManyLabel.Text = "ចំនួនខ្ចី"
        '
        'TitleTextBox
        '
        Me.TitleTextBox.Enabled = False
        Me.TitleTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleTextBox.Location = New System.Drawing.Point(15, 93)
        Me.TitleTextBox.Name = "TitleTextBox"
        Me.TitleTextBox.Size = New System.Drawing.Size(522, 32)
        Me.TitleTextBox.TabIndex = 2
        '
        'BorrowPhoneTextBox
        '
        Me.BorrowPhoneTextBox.Enabled = False
        Me.BorrowPhoneTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowPhoneTextBox.Location = New System.Drawing.Point(16, 217)
        Me.BorrowPhoneTextBox.Name = "BorrowPhoneTextBox"
        Me.BorrowPhoneTextBox.Size = New System.Drawing.Size(254, 32)
        Me.BorrowPhoneTextBox.TabIndex = 2
        '
        'CreateBorrowUserToolStripButton
        '
        Me.CreateBorrowUserToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!)
        Me.CreateBorrowUserToolStripButton.Image = CType(resources.GetObject("CreateBorrowUserToolStripButton.Image"), System.Drawing.Image)
        Me.CreateBorrowUserToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CreateBorrowUserToolStripButton.Name = "CreateBorrowUserToolStripButton"
        Me.CreateBorrowUserToolStripButton.Size = New System.Drawing.Size(82, 26)
        Me.CreateBorrowUserToolStripButton.Text = "បង្កើតអ្នកខ្ចី"
        '
        'BorrowToolStripMenuItem
        '
        Me.BorrowToolStripMenuItem.Image = CType(resources.GetObject("BorrowToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BorrowToolStripMenuItem.Name = "BorrowToolStripMenuItem"
        Me.BorrowToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.BorrowToolStripMenuItem.Text = "ធ្វើការខ្ចី"
        '
        'BorrowEmailLabel
        '
        Me.BorrowEmailLabel.AutoSize = True
        Me.BorrowEmailLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowEmailLabel.Location = New System.Drawing.Point(281, 190)
        Me.BorrowEmailLabel.Name = "BorrowEmailLabel"
        Me.BorrowEmailLabel.Size = New System.Drawing.Size(47, 27)
        Me.BorrowEmailLabel.TabIndex = 28
        Me.BorrowEmailLabel.Text = "អ៊ីម៉ែន"
        '
        'BorrowEmailTextBox
        '
        Me.BorrowEmailTextBox.Enabled = False
        Me.BorrowEmailTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEmailTextBox.Location = New System.Drawing.Point(281, 217)
        Me.BorrowEmailTextBox.Name = "BorrowEmailTextBox"
        Me.BorrowEmailTextBox.Size = New System.Drawing.Size(256, 32)
        Me.BorrowEmailTextBox.TabIndex = 3
        '
        'BorrowHowManyTextBox
        '
        Me.BorrowHowManyTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowHowManyTextBox.Location = New System.Drawing.Point(16, 279)
        Me.BorrowHowManyTextBox.Name = "BorrowHowManyTextBox"
        Me.BorrowHowManyTextBox.Size = New System.Drawing.Size(257, 32)
        Me.BorrowHowManyTextBox.TabIndex = 4
        '
        'NoTextBox
        '
        Me.NoTextBox.Enabled = False
        Me.NoTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoTextBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.NoTextBox.Location = New System.Drawing.Point(15, 31)
        Me.NoTextBox.Name = "NoTextBox"
        Me.NoTextBox.Size = New System.Drawing.Size(258, 32)
        Me.NoTextBox.TabIndex = 3
        '
        'BorrowIDTextBox
        '
        Me.BorrowIDTextBox.Enabled = False
        Me.BorrowIDTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowIDTextBox.Location = New System.Drawing.Point(281, 154)
        Me.BorrowIDTextBox.Name = "BorrowIDTextBox"
        Me.BorrowIDTextBox.Size = New System.Drawing.Size(255, 32)
        Me.BorrowIDTextBox.TabIndex = 1
        '
        'BorrowNameTextBox
        '
        Me.BorrowNameTextBox.Enabled = False
        Me.BorrowNameTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowNameTextBox.Location = New System.Drawing.Point(16, 155)
        Me.BorrowNameTextBox.Name = "BorrowNameTextBox"
        Me.BorrowNameTextBox.Size = New System.Drawing.Size(255, 32)
        Me.BorrowNameTextBox.TabIndex = 1
        '
        'BorrowNoteTextBox
        '
        Me.BorrowNoteTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowNoteTextBox.Location = New System.Drawing.Point(16, 403)
        Me.BorrowNoteTextBox.Multiline = True
        Me.BorrowNoteTextBox.Name = "BorrowNoteTextBox"
        Me.BorrowNoteTextBox.Size = New System.Drawing.Size(522, 46)
        Me.BorrowNoteTextBox.TabIndex = 8
        '
        'BorrowHowMuchTextBox
        '
        Me.BorrowHowMuchTextBox.Enabled = False
        Me.BorrowHowMuchTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowHowMuchTextBox.Location = New System.Drawing.Point(281, 279)
        Me.BorrowHowMuchTextBox.Name = "BorrowHowMuchTextBox"
        Me.BorrowHowMuchTextBox.Size = New System.Drawing.Size(256, 32)
        Me.BorrowHowMuchTextBox.TabIndex = 5
        '
        'FileToolStripButton
        '
        Me.FileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BorrowToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileToolStripButton.Image = CType(resources.GetObject("FileToolStripButton.Image"), System.Drawing.Image)
        Me.FileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileToolStripButton.Name = "FileToolStripButton"
        Me.FileToolStripButton.Size = New System.Drawing.Size(59, 26)
        Me.FileToolStripButton.Text = "ឯកសារ"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.CloseToolStripMenuItem.Text = "&បិទ"
        '
        'BorrowIDLabel
        '
        Me.BorrowIDLabel.AutoSize = True
        Me.BorrowIDLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowIDLabel.Location = New System.Drawing.Point(277, 127)
        Me.BorrowIDLabel.Name = "BorrowIDLabel"
        Me.BorrowIDLabel.Size = New System.Drawing.Size(97, 27)
        Me.BorrowIDLabel.TabIndex = 2
        Me.BorrowIDLabel.Text = "លេខរៀងអ្នកខ្ចី"
        '
        'BorrowNameLabel
        '
        Me.BorrowNameLabel.AutoSize = True
        Me.BorrowNameLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowNameLabel.Location = New System.Drawing.Point(12, 128)
        Me.BorrowNameLabel.Name = "BorrowNameLabel"
        Me.BorrowNameLabel.Size = New System.Drawing.Size(80, 27)
        Me.BorrowNameLabel.TabIndex = 2
        Me.BorrowNameLabel.Text = "អ្នកខ្ចីឈ្មោះ"
        '
        'BorrowFromLabel
        '
        Me.BorrowFromLabel.AutoSize = True
        Me.BorrowFromLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowFromLabel.Location = New System.Drawing.Point(10, 314)
        Me.BorrowFromLabel.Name = "BorrowFromLabel"
        Me.BorrowFromLabel.Size = New System.Drawing.Size(47, 27)
        Me.BorrowFromLabel.TabIndex = 4
        Me.BorrowFromLabel.Text = "ចាប់ពី"
        '
        'BorrowHowMuchLabel
        '
        Me.BorrowHowMuchLabel.AutoSize = True
        Me.BorrowHowMuchLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowHowMuchLabel.Location = New System.Drawing.Point(278, 252)
        Me.BorrowHowMuchLabel.Name = "BorrowHowMuchLabel"
        Me.BorrowHowMuchLabel.Size = New System.Drawing.Size(106, 27)
        Me.BorrowHowMuchLabel.TabIndex = 22
        Me.BorrowHowMuchLabel.Text = "តម្លៃ/១ក្បាល (៛)"
        '
        'BorrowPhoneLabel
        '
        Me.BorrowPhoneLabel.AutoSize = True
        Me.BorrowPhoneLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowPhoneLabel.Location = New System.Drawing.Point(16, 190)
        Me.BorrowPhoneLabel.Name = "BorrowPhoneLabel"
        Me.BorrowPhoneLabel.Size = New System.Drawing.Size(82, 27)
        Me.BorrowPhoneLabel.TabIndex = 22
        Me.BorrowPhoneLabel.Text = "លេខទូរស័ព្ទ"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripButton, Me.CreateBorrowUserToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(738, 29)
        Me.ToolStrip1.TabIndex = 43
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BorrowEndLabel
        '
        Me.BorrowEndLabel.AutoSize = True
        Me.BorrowEndLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowEndLabel.Location = New System.Drawing.Point(278, 314)
        Me.BorrowEndLabel.Name = "BorrowEndLabel"
        Me.BorrowEndLabel.Size = New System.Drawing.Size(37, 27)
        Me.BorrowEndLabel.TabIndex = 4
        Me.BorrowEndLabel.Text = "ដល់"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.BorrowButton)
        Me.Panel1.Controls.Add(Me.BorrowEndDateTimePicker)
        Me.Panel1.Controls.Add(Me.BorrowFromDateTimePicker)
        Me.Panel1.Controls.Add(Me.BorrowCancelButton)
        Me.Panel1.Controls.Add(Me.CategoryComboBox)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.NoLabel)
        Me.Panel1.Controls.Add(Me.BorrowNoteLabel)
        Me.Panel1.Controls.Add(Me.TitleLabel)
        Me.Panel1.Controls.Add(Me.BorrowHowManyLabel)
        Me.Panel1.Controls.Add(Me.TitleTextBox)
        Me.Panel1.Controls.Add(Me.BorrowPhoneTextBox)
        Me.Panel1.Controls.Add(Me.BorrowEmailLabel)
        Me.Panel1.Controls.Add(Me.BorrowEmailTextBox)
        Me.Panel1.Controls.Add(Me.BorrowHowManyTextBox)
        Me.Panel1.Controls.Add(Me.NoTextBox)
        Me.Panel1.Controls.Add(Me.BorrowIDTextBox)
        Me.Panel1.Controls.Add(Me.BorrowNameTextBox)
        Me.Panel1.Controls.Add(Me.BorrowNoteTextBox)
        Me.Panel1.Controls.Add(Me.BorrowHowMuchTextBox)
        Me.Panel1.Controls.Add(Me.BorrowIDLabel)
        Me.Panel1.Controls.Add(Me.BorrowNameLabel)
        Me.Panel1.Controls.Add(Me.BorrowEndLabel)
        Me.Panel1.Controls.Add(Me.BorrowFromLabel)
        Me.Panel1.Controls.Add(Me.BorrowHowMuchLabel)
        Me.Panel1.Controls.Add(Me.BorrowPhoneLabel)
        Me.Panel1.Location = New System.Drawing.Point(178, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(560, 512)
        Me.Panel1.TabIndex = 42
        '
        'FrmLibraryBorrow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(738, 542)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryBorrow"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents SearchBorrowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ViewBorrowUserListBox As System.Windows.Forms.ListBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents BorrowEndDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents BorrowFromDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents BorrowCancelButton As System.Windows.Forms.Button
    Friend WithEvents CategoryComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NoLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowNoteLabel As System.Windows.Forms.Label
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowHowManyLabel As System.Windows.Forms.Label
    Friend WithEvents TitleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowPhoneTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreateBorrowUserToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents BorrowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrowEmailLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowEmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowHowManyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowNoteTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowHowMuchTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FileToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrowIDLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowNameLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowFromLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowHowMuchLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowPhoneLabel As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents BorrowEndLabel As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
