﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryReturn
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryReturn))
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowEndDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.BorrowFromDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ReturnCancelButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.CategoryComboBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NoLabel = New System.Windows.Forms.Label()
        Me.BorrowNoteLabel = New System.Windows.Forms.Label()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.BorNoTextBox = New System.Windows.Forms.TextBox()
        Me.NoTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowNoteTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowEndLabel = New System.Windows.Forms.Label()
        Me.BorrowFromLabel = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TitleTextBox = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ReturnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BorrowHowManyLabel = New System.Windows.Forms.Label()
        Me.BorrowPhoneTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowEmailLabel = New System.Windows.Forms.Label()
        Me.BorrowEmailTextBox = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BorrowHowManyTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowIDTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowNameTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowHowMuchTextBox = New System.Windows.Forms.TextBox()
        Me.BorrowIDLabel = New System.Windows.Forms.Label()
        Me.BorrowNameLabel = New System.Windows.Forms.Label()
        Me.BorrowHowMuchLabel = New System.Windows.Forms.Label()
        Me.BorrowPhoneLabel = New System.Windows.Forms.Label()
        Me.ReturnButton = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CMDTextBox
        '
        Me.CMDTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CMDTextBox.Location = New System.Drawing.Point(-1, 544)
        Me.CMDTextBox.Multiline = True
        Me.CMDTextBox.Name = "CMDTextBox"
        Me.CMDTextBox.Size = New System.Drawing.Size(731, 119)
        Me.CMDTextBox.TabIndex = 40
        '
        'BorrowEndDateTimePicker
        '
        Me.BorrowEndDateTimePicker.CalendarFont = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEndDateTimePicker.Enabled = False
        Me.BorrowEndDateTimePicker.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEndDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.BorrowEndDateTimePicker.Location = New System.Drawing.Point(281, 341)
        Me.BorrowEndDateTimePicker.Name = "BorrowEndDateTimePicker"
        Me.BorrowEndDateTimePicker.Size = New System.Drawing.Size(255, 32)
        Me.BorrowEndDateTimePicker.TabIndex = 7
        '
        'BorrowFromDateTimePicker
        '
        Me.BorrowFromDateTimePicker.CalendarFont = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowFromDateTimePicker.Enabled = False
        Me.BorrowFromDateTimePicker.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowFromDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.BorrowFromDateTimePicker.Location = New System.Drawing.Point(15, 341)
        Me.BorrowFromDateTimePicker.Name = "BorrowFromDateTimePicker"
        Me.BorrowFromDateTimePicker.Size = New System.Drawing.Size(255, 32)
        Me.BorrowFromDateTimePicker.TabIndex = 6
        '
        'ReturnCancelButton
        '
        Me.ReturnCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReturnCancelButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ReturnCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ReturnCancelButton.ImageIndex = 0
        Me.ReturnCancelButton.ImageList = Me.ImageList1
        Me.ReturnCancelButton.Location = New System.Drawing.Point(15, 464)
        Me.ReturnCancelButton.Name = "ReturnCancelButton"
        Me.ReturnCancelButton.Size = New System.Drawing.Size(100, 33)
        Me.ReturnCancelButton.TabIndex = 9
        Me.ReturnCancelButton.Text = "បោះបង់"
        Me.ReturnCancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ReturnCancelButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "return_item.png")
        '
        'CategoryComboBox
        '
        Me.CategoryComboBox.DropDownHeight = 200
        Me.CategoryComboBox.Enabled = False
        Me.CategoryComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CategoryComboBox.FormattingEnabled = True
        Me.CategoryComboBox.IntegralHeight = False
        Me.CategoryComboBox.Location = New System.Drawing.Point(281, 31)
        Me.CategoryComboBox.Name = "CategoryComboBox"
        Me.CategoryComboBox.Size = New System.Drawing.Size(255, 32)
        Me.CategoryComboBox.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.Label1.Location = New System.Drawing.Point(276, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ប្រភេទ"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.Label2.Location = New System.Drawing.Point(150, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 27)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "លេខរៀង"
        '
        'NoLabel
        '
        Me.NoLabel.AutoSize = True
        Me.NoLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.NoLabel.Location = New System.Drawing.Point(10, 4)
        Me.NoLabel.Name = "NoLabel"
        Me.NoLabel.Size = New System.Drawing.Size(97, 27)
        Me.NoLabel.TabIndex = 0
        Me.NoLabel.Text = "លេខរៀងអ្នកខ្ចី"
        '
        'BorrowNoteLabel
        '
        Me.BorrowNoteLabel.AutoSize = True
        Me.BorrowNoteLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowNoteLabel.Location = New System.Drawing.Point(11, 376)
        Me.BorrowNoteLabel.Name = "BorrowNoteLabel"
        Me.BorrowNoteLabel.Size = New System.Drawing.Size(53, 27)
        Me.BorrowNoteLabel.TabIndex = 27
        Me.BorrowNoteLabel.Text = "ផ្សេងៗ"
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.TitleLabel.Location = New System.Drawing.Point(11, 66)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(78, 27)
        Me.TitleLabel.TabIndex = 0
        Me.TitleLabel.Text = "ចំណងជើង"
        '
        'BorNoTextBox
        '
        Me.BorNoTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorNoTextBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.BorNoTextBox.Location = New System.Drawing.Point(15, 31)
        Me.BorNoTextBox.Name = "BorNoTextBox"
        Me.BorNoTextBox.ReadOnly = True
        Me.BorNoTextBox.Size = New System.Drawing.Size(119, 32)
        Me.BorNoTextBox.TabIndex = 3
        '
        'NoTextBox
        '
        Me.NoTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoTextBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.NoTextBox.Location = New System.Drawing.Point(154, 31)
        Me.NoTextBox.Name = "NoTextBox"
        Me.NoTextBox.ReadOnly = True
        Me.NoTextBox.Size = New System.Drawing.Size(118, 32)
        Me.NoTextBox.TabIndex = 3
        '
        'BorrowNoteTextBox
        '
        Me.BorrowNoteTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowNoteTextBox.Location = New System.Drawing.Point(15, 403)
        Me.BorrowNoteTextBox.Multiline = True
        Me.BorrowNoteTextBox.Name = "BorrowNoteTextBox"
        Me.BorrowNoteTextBox.ReadOnly = True
        Me.BorrowNoteTextBox.Size = New System.Drawing.Size(522, 46)
        Me.BorrowNoteTextBox.TabIndex = 8
        '
        'BorrowEndLabel
        '
        Me.BorrowEndLabel.AutoSize = True
        Me.BorrowEndLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowEndLabel.Location = New System.Drawing.Point(277, 314)
        Me.BorrowEndLabel.Name = "BorrowEndLabel"
        Me.BorrowEndLabel.Size = New System.Drawing.Size(37, 27)
        Me.BorrowEndLabel.TabIndex = 4
        Me.BorrowEndLabel.Text = "ដល់"
        '
        'BorrowFromLabel
        '
        Me.BorrowFromLabel.AutoSize = True
        Me.BorrowFromLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowFromLabel.Location = New System.Drawing.Point(9, 314)
        Me.BorrowFromLabel.Name = "BorrowFromLabel"
        Me.BorrowFromLabel.Size = New System.Drawing.Size(47, 27)
        Me.BorrowFromLabel.TabIndex = 4
        Me.BorrowFromLabel.Text = "ចាប់ពី"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Location = New System.Drawing.Point(0, 31)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(182, 507)
        Me.Panel2.TabIndex = 41
        '
        'TitleTextBox
        '
        Me.TitleTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleTextBox.Location = New System.Drawing.Point(14, 93)
        Me.TitleTextBox.Name = "TitleTextBox"
        Me.TitleTextBox.ReadOnly = True
        Me.TitleTextBox.Size = New System.Drawing.Size(522, 32)
        Me.TitleTextBox.TabIndex = 2
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Khmer OS Battambang", 10.0!)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 24
        Me.ListBox1.Location = New System.Drawing.Point(752, 31)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(178, 484)
        Me.ListBox1.TabIndex = 44
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(128, 26)
        Me.CloseToolStripMenuItem.Text = "&បិទ"
        '
        'FileToolStripButton
        '
        Me.FileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReturnToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileToolStripButton.Image = CType(resources.GetObject("FileToolStripButton.Image"), System.Drawing.Image)
        Me.FileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileToolStripButton.Name = "FileToolStripButton"
        Me.FileToolStripButton.Size = New System.Drawing.Size(59, 26)
        Me.FileToolStripButton.Text = "ឯកសារ"
        '
        'ReturnToolStripMenuItem
        '
        Me.ReturnToolStripMenuItem.Image = CType(resources.GetObject("ReturnToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ReturnToolStripMenuItem.Name = "ReturnToolStripMenuItem"
        Me.ReturnToolStripMenuItem.Size = New System.Drawing.Size(128, 26)
        Me.ReturnToolStripMenuItem.Text = "ធ្វើការសង"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(730, 29)
        Me.ToolStrip1.TabIndex = 43
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BorrowHowManyLabel
        '
        Me.BorrowHowManyLabel.AutoSize = True
        Me.BorrowHowManyLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowHowManyLabel.Location = New System.Drawing.Point(10, 253)
        Me.BorrowHowManyLabel.Name = "BorrowHowManyLabel"
        Me.BorrowHowManyLabel.Size = New System.Drawing.Size(52, 27)
        Me.BorrowHowManyLabel.TabIndex = 35
        Me.BorrowHowManyLabel.Text = "ចំនួនខ្ចី"
        '
        'BorrowPhoneTextBox
        '
        Me.BorrowPhoneTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowPhoneTextBox.Location = New System.Drawing.Point(15, 218)
        Me.BorrowPhoneTextBox.Name = "BorrowPhoneTextBox"
        Me.BorrowPhoneTextBox.ReadOnly = True
        Me.BorrowPhoneTextBox.Size = New System.Drawing.Size(254, 32)
        Me.BorrowPhoneTextBox.TabIndex = 31
        '
        'BorrowEmailLabel
        '
        Me.BorrowEmailLabel.AutoSize = True
        Me.BorrowEmailLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowEmailLabel.Location = New System.Drawing.Point(280, 191)
        Me.BorrowEmailLabel.Name = "BorrowEmailLabel"
        Me.BorrowEmailLabel.Size = New System.Drawing.Size(47, 27)
        Me.BorrowEmailLabel.TabIndex = 40
        Me.BorrowEmailLabel.Text = "អ៊ីម៉ែន"
        '
        'BorrowEmailTextBox
        '
        Me.BorrowEmailTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowEmailTextBox.Location = New System.Drawing.Point(280, 218)
        Me.BorrowEmailTextBox.Name = "BorrowEmailTextBox"
        Me.BorrowEmailTextBox.ReadOnly = True
        Me.BorrowEmailTextBox.Size = New System.Drawing.Size(256, 32)
        Me.BorrowEmailTextBox.TabIndex = 34
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.BorrowHowManyLabel)
        Me.Panel1.Controls.Add(Me.BorrowPhoneTextBox)
        Me.Panel1.Controls.Add(Me.BorrowEmailLabel)
        Me.Panel1.Controls.Add(Me.BorrowEmailTextBox)
        Me.Panel1.Controls.Add(Me.BorrowHowManyTextBox)
        Me.Panel1.Controls.Add(Me.BorrowIDTextBox)
        Me.Panel1.Controls.Add(Me.BorrowNameTextBox)
        Me.Panel1.Controls.Add(Me.BorrowHowMuchTextBox)
        Me.Panel1.Controls.Add(Me.BorrowIDLabel)
        Me.Panel1.Controls.Add(Me.BorrowNameLabel)
        Me.Panel1.Controls.Add(Me.BorrowHowMuchLabel)
        Me.Panel1.Controls.Add(Me.BorrowPhoneLabel)
        Me.Panel1.Controls.Add(Me.ReturnButton)
        Me.Panel1.Controls.Add(Me.BorrowEndDateTimePicker)
        Me.Panel1.Controls.Add(Me.BorrowFromDateTimePicker)
        Me.Panel1.Controls.Add(Me.ReturnCancelButton)
        Me.Panel1.Controls.Add(Me.CategoryComboBox)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.NoLabel)
        Me.Panel1.Controls.Add(Me.BorrowNoteLabel)
        Me.Panel1.Controls.Add(Me.TitleLabel)
        Me.Panel1.Controls.Add(Me.TitleTextBox)
        Me.Panel1.Controls.Add(Me.BorNoTextBox)
        Me.Panel1.Controls.Add(Me.NoTextBox)
        Me.Panel1.Controls.Add(Me.BorrowNoteTextBox)
        Me.Panel1.Controls.Add(Me.BorrowEndLabel)
        Me.Panel1.Controls.Add(Me.BorrowFromLabel)
        Me.Panel1.Location = New System.Drawing.Point(179, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(551, 506)
        Me.Panel1.TabIndex = 42
        '
        'BorrowHowManyTextBox
        '
        Me.BorrowHowManyTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowHowManyTextBox.Location = New System.Drawing.Point(15, 280)
        Me.BorrowHowManyTextBox.Name = "BorrowHowManyTextBox"
        Me.BorrowHowManyTextBox.ReadOnly = True
        Me.BorrowHowManyTextBox.Size = New System.Drawing.Size(257, 32)
        Me.BorrowHowManyTextBox.TabIndex = 36
        '
        'BorrowIDTextBox
        '
        Me.BorrowIDTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowIDTextBox.Location = New System.Drawing.Point(280, 155)
        Me.BorrowIDTextBox.Name = "BorrowIDTextBox"
        Me.BorrowIDTextBox.ReadOnly = True
        Me.BorrowIDTextBox.Size = New System.Drawing.Size(255, 32)
        Me.BorrowIDTextBox.TabIndex = 29
        '
        'BorrowNameTextBox
        '
        Me.BorrowNameTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowNameTextBox.Location = New System.Drawing.Point(15, 156)
        Me.BorrowNameTextBox.Name = "BorrowNameTextBox"
        Me.BorrowNameTextBox.ReadOnly = True
        Me.BorrowNameTextBox.Size = New System.Drawing.Size(255, 32)
        Me.BorrowNameTextBox.TabIndex = 30
        '
        'BorrowHowMuchTextBox
        '
        Me.BorrowHowMuchTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BorrowHowMuchTextBox.Location = New System.Drawing.Point(280, 280)
        Me.BorrowHowMuchTextBox.Name = "BorrowHowMuchTextBox"
        Me.BorrowHowMuchTextBox.ReadOnly = True
        Me.BorrowHowMuchTextBox.Size = New System.Drawing.Size(256, 32)
        Me.BorrowHowMuchTextBox.TabIndex = 37
        '
        'BorrowIDLabel
        '
        Me.BorrowIDLabel.AutoSize = True
        Me.BorrowIDLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowIDLabel.Location = New System.Drawing.Point(276, 128)
        Me.BorrowIDLabel.Name = "BorrowIDLabel"
        Me.BorrowIDLabel.Size = New System.Drawing.Size(67, 27)
        Me.BorrowIDLabel.TabIndex = 32
        Me.BorrowIDLabel.Text = "លេខរៀង"
        '
        'BorrowNameLabel
        '
        Me.BorrowNameLabel.AutoSize = True
        Me.BorrowNameLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowNameLabel.Location = New System.Drawing.Point(11, 129)
        Me.BorrowNameLabel.Name = "BorrowNameLabel"
        Me.BorrowNameLabel.Size = New System.Drawing.Size(80, 27)
        Me.BorrowNameLabel.TabIndex = 33
        Me.BorrowNameLabel.Text = "អ្នកខ្ចីឈ្មោះ"
        '
        'BorrowHowMuchLabel
        '
        Me.BorrowHowMuchLabel.AutoSize = True
        Me.BorrowHowMuchLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowHowMuchLabel.Location = New System.Drawing.Point(277, 253)
        Me.BorrowHowMuchLabel.Name = "BorrowHowMuchLabel"
        Me.BorrowHowMuchLabel.Size = New System.Drawing.Size(106, 27)
        Me.BorrowHowMuchLabel.TabIndex = 38
        Me.BorrowHowMuchLabel.Text = "តម្លៃ/១ក្បាល (៛)"
        '
        'BorrowPhoneLabel
        '
        Me.BorrowPhoneLabel.AutoSize = True
        Me.BorrowPhoneLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.BorrowPhoneLabel.Location = New System.Drawing.Point(15, 191)
        Me.BorrowPhoneLabel.Name = "BorrowPhoneLabel"
        Me.BorrowPhoneLabel.Size = New System.Drawing.Size(82, 27)
        Me.BorrowPhoneLabel.TabIndex = 39
        Me.BorrowPhoneLabel.Text = "លេខទូរស័ព្ទ"
        '
        'ReturnButton
        '
        Me.ReturnButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReturnButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ReturnButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ReturnButton.ImageIndex = 1
        Me.ReturnButton.ImageList = Me.ImageList1
        Me.ReturnButton.Location = New System.Drawing.Point(434, 464)
        Me.ReturnButton.Name = "ReturnButton"
        Me.ReturnButton.Size = New System.Drawing.Size(102, 33)
        Me.ReturnButton.TabIndex = 10
        Me.ReturnButton.Text = "ធ្វើការសង"
        Me.ReturnButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ReturnButton.UseVisualStyleBackColor = True
        '
        'FrmLibraryReturn
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(730, 532)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryReturn"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowEndDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents BorrowFromDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents ReturnCancelButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents CategoryComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NoLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowNoteLabel As System.Windows.Forms.Label
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents BorNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowNoteTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowEndLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowFromLabel As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TitleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents ReturnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents BorrowHowManyLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowPhoneTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowEmailLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowEmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BorrowHowManyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowHowMuchTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BorrowIDLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowNameLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowHowMuchLabel As System.Windows.Forms.Label
    Friend WithEvents BorrowPhoneLabel As System.Windows.Forms.Label
    Friend WithEvents ReturnButton As System.Windows.Forms.Button
End Class
