﻿Imports System.IO

Public Class FrmLibraryStart
    Public Function IsConnectionAvailable() As Boolean
        Dim objUrl As New System.Uri("http://mylibrary.freesite.host/")
        Dim objWebReq As System.Net.WebRequest
        objWebReq = System.Net.WebRequest.Create(objUrl)
        Dim objresp As System.Net.WebResponse

        Try
            objresp = objWebReq.GetResponse
            objresp.Close()
            objresp = Nothing
            Return True

        Catch ex As Exception
            objresp = Nothing
            objWebReq = Nothing
            Return False
        End Try
    End Function


    Private Sub frmstart_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Interval = 5
        Timer1.Enabled = True
        Me.Height = 80

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value <= 99 Then
            ProgressBar1.Value += 1
            Label1.Text = ProgressBar1.Value - 1 & "%"
        Else
            Timer1.Stop()
            If IsConnectionAvailable() = True Then 'Check pc បាន Connect to internet អត់
                'MsgBox("Computer is connected.")
                Me.Hide()
                FrmLibraryLogin.ShowDialog()
                FrmLibraryMain.TopPanel.Visible = True
                FrmLibraryMain.BottomLeftPanel.Visible = True
               
            Else
                ConnectLabel.Text = "ការតភ្ចាប់ទៅកាន់បណ្ដាញមិនជោគជ័យ !"
                ConnectLabel.ForeColor = Color.Red
                Me.Height = 152
                ProgressBar1.Value = 0
                System.Media.SystemSounds.Exclamation.Play()
                MessageBox.Show("Computer is not connected!", "No Internet")
                'Me.Close()
            End If

        End If
    End Sub

    Private Sub TryButton_Click(sender As Object, e As EventArgs) Handles TryButton.Click
        Timer1.Start()
        ConnectLabel.Text = "កំពុងតភ្ចាប់ទៅកាន់បណ្តាញ ..."
        ConnectLabel.ForeColor = Color.White
    End Sub

    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        Me.Close()
        FrmLibraryMain.Close()
    End Sub
End Class

