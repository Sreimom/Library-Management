﻿Public Class FrmLibraryChangePass

    Private Sub EditCancelButton_Click(sender As Object, e As EventArgs) Handles EditCancelButton.Click
        Dim del As String = MsgBox("Do you want to close?(Y/N)", vbYesNo)
        If del = vbYes Then
            Me.Close()
            OldpassTextBox.Text = ""
            NewpassTextBox.Text = ""
            NewpassagainTextBox.Text = ""
        End If
    End Sub
    Private Sub UpdateButton_Click(sender As Object, e As EventArgs) Handles UpdateButton.Click
        If OldpassTextBox.Text = FrmLibraryUser.UserPasswordTextBox.Text Then
            If NewpassagainTextBox.Text = NewpassagainTextBox.Text Then
                If PrepareLabel.Text = "Good" And checkLabel.Text = "Match" Then
                    Dim Query As String = "UPDATE users SET user_pass='" & NewpassTextBox.Text & "'WHERE user_id=" & FrmLibraryMain.IDToolStripLabel.Text
                    FrmLibraryProcessing.Timer1.Start()
                    FrmLibraryProcessing.Timer1.Enabled = True
                    FrmLibraryProcessing.Timer1.Interval = 5
                    LibraryCommand.SQL(Query)
                    FrmLibraryUser.ChangepassButton.Enabled = False
                    Me.Close()
                End If
            Else
                MsgBox("not match!")
            End If
        Else
            MsgBox("Incorrect password!")
            OldpassTextBox.Text = ""
            OldpassTextBox.Focus()
        End If

    End Sub








    Private Sub NewpassTextBox_TextChanged(sender As Object, e As EventArgs) Handles NewpassTextBox.TextChanged
        If NewpassTextBox.Text = "" Then
            PrepareLabel.Text = ""
            checkLabel.Text = ""
        Else
            If NewpassTextBox.TextLength < 7 Then
                checkLabel.Text = ""
                PrepareLabel.Text = "low"
                PrepareLabel.ForeColor = Color.Red
            Else
                checkLabel.Text = ""
                PrepareLabel.Text = "Good"
                PrepareLabel.ForeColor = Color.Green
            End If
        End If

    End Sub

    Private Sub NewpassagainTextBox_TextChanged(sender As Object, e As EventArgs) Handles NewpassagainTextBox.TextChanged
        If NewpassagainTextBox.Text = "" Then
            checkLabel.Text = ""
        Else
            If NewpassagainTextBox.Text <> NewpassTextBox.Text Then
                checkLabel.Text = "Not match"
                checkLabel.ForeColor = Color.Red
            Else
                checkLabel.Text = "Match"
                checkLabel.ForeColor = Color.Green
            End If
        End If
    End Sub

    Private Sub frmchangepassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OldpassTextBox.Focus()
        OldpassTextBox.UseSystemPasswordChar = True
        NewpassTextBox.UseSystemPasswordChar = True
        NewpassagainTextBox.UseSystemPasswordChar = True

    End Sub
End Class