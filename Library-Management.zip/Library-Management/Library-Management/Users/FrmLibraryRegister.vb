﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class FrmLibraryRegister

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles closeButton.Click
        clear()
        Me.Close()

    End Sub
    Sub clear()
        NewpassagainTextBox.Text = ""
        NewpassagainLabel.ForeColor = Color.Black
        NewpassTextBox.Text = ""
        NewpassLabel.ForeColor = Color.Black
        loginTextBox.Text = ""
        LoginLabel.ForeColor = Color.Black
    End Sub

    Sub isEmpty()
        If NewpassagainTextBox.Text = "" Then
            NewpassagainLabel.ForeColor = Color.Red
            NewpassagainTextBox.Focus()
        Else
            NewpassagainLabel.ForeColor = Color.Black
        End If
        If NewpassTextBox.Text = "" Then
            NewpassLabel.ForeColor = Color.Red
            NewpassTextBox.Focus()
        Else
            NewpassLabel.ForeColor = Color.Black
        End If
        If loginTextBox.Text = "" Then
            LoginLabel.ForeColor = Color.Red
            loginTextBox.Focus()
        Else
            LoginLabel.ForeColor = Color.Black
        End If
    End Sub
    Private Sub UpdateButton_Click(sender As Object, e As EventArgs) Handles UpdateButton.Click
        isEmpty()
        If loginTextBox.Text = "" And NewpassTextBox.Text = "" And NewpassagainTextBox.Text = "" Then

            System.Media.SystemSounds.Exclamation.Play()
        Else

            If checkloginLabel.Text = "better" Then
                Register()

            End If
        End If
    End Sub
    Private Sub IsCheck()
        Dim MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim READER As MySqlDataReader
        Dim userlogin As String

        Try
            MysqlConn.Open()
            Dim Query As String
            Query = " SELECT  * From users  WHERE   (user_login = '" & loginTextBox.Text & "')"
            Dim Command = New MySqlCommand(Query, MysqlConn)
            READER = Command.ExecuteReader


            If READER.HasRows Then
                While READER.Read()
                    userlogin = READER("user_login").ToString()
                    If userlogin = loginTextBox.Text Then
                        checkloginLabel.ForeColor = Color.Red
                        checkloginLabel.Text = "Already taken"
                        'MsgBox("Login user Already have")
                        'loginTextBox.Text = ""
                        'loginTextBox.Focus()


                    End If

                End While
            End If

            MysqlConn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try

    End Sub

    Sub Register()

        Dim Query As String = "INSERT INTO users  (user_login,user_pass) VALUE ('" & loginTextBox.Text & "','" & NewpassagainTextBox.Text & "')"
        LibraryCommand.SQL(Query)
        FrmLibraryLogin.txtuser.Text = loginTextBox.Text
        FrmLibraryLogin.txtpass.Text = NewpassagainTextBox.Text
        clear()
        Me.Close()


    End Sub


    Private Sub NewpassTextBox_TextChanged(sender As Object, e As EventArgs) Handles NewpassTextBox.TextChanged
        If NewpassTextBox.Text = "" Then
            PrepareLabel.Text = ""
        Else
            If NewpassTextBox.TextLength < 7 Then
                PrepareLabel.Text = "low"
                PrepareLabel.ForeColor = Color.Red
            Else
                PrepareLabel.Text = "Good"
                PrepareLabel.ForeColor = Color.Green
            End If
        End If

    End Sub

    Private Sub NewpassagainTextBox_TextChanged(sender As Object, e As EventArgs) Handles NewpassagainTextBox.TextChanged

        If String.IsNullOrWhiteSpace(NewpassagainTextBox.Text) Then

            checkLabel.Text = ""
        End If

        If NewpassagainTextBox.Text = "" Then
            checkLabel.Text = ""
        Else
            If NewpassagainTextBox.Text <> NewpassTextBox.Text Then
                checkLabel.Text = "Not match"
                checkLabel.ForeColor = Color.Red
            Else
                checkLabel.Text = "Match"
                checkLabel.ForeColor = Color.Green
            End If
        End If
    End Sub

    Private Sub frmregister_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MaximumSize = New Size(341, 292)
        Me.MinimumSize = Me.MaximumSize
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        loginTextBox.Focus()
        NewpassTextBox.UseSystemPasswordChar = True
        NewpassagainTextBox.UseSystemPasswordChar = True
    End Sub

    Private Sub loginTextBox_KeyDown(sender As Object, e As KeyEventArgs) Handles loginTextBox.KeyDown
        If e.KeyCode = Keys.Space Then 'Enter key
            MsgBox("Can't input Space")
            loginTextBox.Text = Replace(loginTextBox.Text, Space(1), Space(0))
        End If
    End Sub




    Private Sub loginTextBox_TextChanged(sender As Object, e As EventArgs) Handles loginTextBox.TextChanged

        If loginTextBox.Text = "" Then
            checkloginLabel.Text = ""

        Else

            If loginTextBox.TextLength < 7 Then
                checkloginLabel.Text = "too short"
                checkloginLabel.ForeColor = Color.Red
            Else
                checkloginLabel.Text = "better"
                checkloginLabel.ForeColor = Color.Green
            End If
            IsCheck()
        End If
    End Sub
End Class