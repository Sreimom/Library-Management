﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryLogin))
        Me.CountLabel = New System.Windows.Forms.Label()
        Me.WLinkLabel = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.RemmberCheckBox = New System.Windows.Forms.CheckBox()
        Me.LoginLable = New System.Windows.Forms.Label()
        Me.CloseLable = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.txtpass = New System.Windows.Forms.TextBox()
        Me.txtuser = New System.Windows.Forms.TextBox()
        Me.UserLabel = New System.Windows.Forms.Label()
        Me.PassLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CountLabel
        '
        Me.CountLabel.AutoSize = True
        Me.CountLabel.BackColor = System.Drawing.Color.White
        Me.CountLabel.Location = New System.Drawing.Point(672, 322)
        Me.CountLabel.Name = "CountLabel"
        Me.CountLabel.Size = New System.Drawing.Size(13, 13)
        Me.CountLabel.TabIndex = 28
        Me.CountLabel.Text = "0"
        '
        'WLinkLabel
        '
        Me.WLinkLabel.ActiveLinkColor = System.Drawing.Color.Maroon
        Me.WLinkLabel.AutoSize = True
        Me.WLinkLabel.BackColor = System.Drawing.Color.Transparent
        Me.WLinkLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
        Me.WLinkLabel.LinkColor = System.Drawing.Color.BlanchedAlmond
        Me.WLinkLabel.LinkVisited = True
        Me.WLinkLabel.Location = New System.Drawing.Point(488, 445)
        Me.WLinkLabel.Name = "WLinkLabel"
        Me.WLinkLabel.Size = New System.Drawing.Size(174, 20)
        Me.WLinkLabel.TabIndex = 23
        Me.WLinkLabel.TabStop = True
        Me.WLinkLabel.Text = "www.mylibrary.com.kh"
        Me.WLinkLabel.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LinkLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
        Me.LinkLabel3.Location = New System.Drawing.Point(362, 445)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(72, 20)
        Me.LinkLabel3.TabIndex = 20
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Register"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
        Me.LinkLabel1.Location = New System.Drawing.Point(532, 317)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(134, 20)
        Me.LinkLabel1.TabIndex = 21
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Forget password"
        '
        'RemmberCheckBox
        '
        Me.RemmberCheckBox.AutoSize = True
        Me.RemmberCheckBox.BackColor = System.Drawing.Color.Transparent
        Me.RemmberCheckBox.Checked = True
        Me.RemmberCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RemmberCheckBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RemmberCheckBox.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.RemmberCheckBox.FlatAppearance.BorderSize = 0
        Me.RemmberCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RemmberCheckBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
        Me.RemmberCheckBox.Location = New System.Drawing.Point(360, 317)
        Me.RemmberCheckBox.Margin = New System.Windows.Forms.Padding(3, 3, 30, 3)
        Me.RemmberCheckBox.Name = "RemmberCheckBox"
        Me.RemmberCheckBox.Size = New System.Drawing.Size(107, 25)
        Me.RemmberCheckBox.TabIndex = 19
        Me.RemmberCheckBox.Text = "Remmber"
        Me.RemmberCheckBox.UseVisualStyleBackColor = False
        '
        'LoginLable
        '
        Me.LoginLable.BackColor = System.Drawing.Color.Transparent
        Me.LoginLable.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoginLable.Font = New System.Drawing.Font("Khmer Muol", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginLable.ForeColor = System.Drawing.Color.White
        Me.LoginLable.Location = New System.Drawing.Point(365, 380)
        Me.LoginLable.Name = "LoginLable"
        Me.LoginLable.Size = New System.Drawing.Size(298, 35)
        Me.LoginLable.TabIndex = 22
        Me.LoginLable.Text = "ចូលប្រើ"
        Me.LoginLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CloseLable
        '
        Me.CloseLable.AllowDrop = True
        Me.CloseLable.BackColor = System.Drawing.Color.Transparent
        Me.CloseLable.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CloseLable.ForeColor = System.Drawing.Color.Silver
        Me.CloseLable.Location = New System.Drawing.Point(660, 20)
        Me.CloseLable.Name = "CloseLable"
        Me.CloseLable.Size = New System.Drawing.Size(26, 18)
        Me.CloseLable.TabIndex = 24
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(459, 75)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(155, 46)
        Me.PictureBox3.TabIndex = 25
        Me.PictureBox3.TabStop = False
        '
        'txtpass
        '
        Me.txtpass.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtpass.Font = New System.Drawing.Font("Khmer OS Battambang", 12.75!)
        Me.txtpass.Location = New System.Drawing.Point(404, 219)
        Me.txtpass.Name = "txtpass"
        Me.txtpass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtpass.Size = New System.Drawing.Size(277, 32)
        Me.txtpass.TabIndex = 18
        '
        'txtuser
        '
        Me.txtuser.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtuser.Font = New System.Drawing.Font("Khmer OS Battambang", 12.75!)
        Me.txtuser.Location = New System.Drawing.Point(404, 144)
        Me.txtuser.Name = "txtuser"
        Me.txtuser.Size = New System.Drawing.Size(277, 32)
        Me.txtuser.TabIndex = 17
        '
        'UserLabel
        '
        Me.UserLabel.BackColor = System.Drawing.Color.Crimson
        Me.UserLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 12.75!)
        Me.UserLabel.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.UserLabel.Location = New System.Drawing.Point(402, 142)
        Me.UserLabel.Name = "UserLabel"
        Me.UserLabel.Size = New System.Drawing.Size(281, 36)
        Me.UserLabel.TabIndex = 26
        '
        'PassLabel
        '
        Me.PassLabel.BackColor = System.Drawing.Color.Crimson
        Me.PassLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 12.75!)
        Me.PassLabel.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.PassLabel.Location = New System.Drawing.Point(402, 217)
        Me.PassLabel.Name = "PassLabel"
        Me.PassLabel.Size = New System.Drawing.Size(281, 36)
        Me.PassLabel.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Khmer OS Muol Pali", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.Brown
        Me.Label1.Location = New System.Drawing.Point(336, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(369, 47)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "កម្មវិធីគ្រប់គ្រង់បណ្ណាល័យ"
        '
        'FrmLibraryLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(710, 488)
        Me.Controls.Add(Me.CountLabel)
        Me.Controls.Add(Me.WLinkLabel)
        Me.Controls.Add(Me.LinkLabel3)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.RemmberCheckBox)
        Me.Controls.Add(Me.LoginLable)
        Me.Controls.Add(Me.CloseLable)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.txtpass)
        Me.Controls.Add(Me.txtuser)
        Me.Controls.Add(Me.UserLabel)
        Me.Controls.Add(Me.PassLabel)
        Me.Controls.Add(Me.Label1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FrmLibraryLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmlogin"
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CountLabel As System.Windows.Forms.Label
    Friend WithEvents WLinkLabel As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents RemmberCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents LoginLable As System.Windows.Forms.Label
    Friend WithEvents CloseLable As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents txtpass As System.Windows.Forms.TextBox
    Friend WithEvents txtuser As System.Windows.Forms.TextBox
    Friend WithEvents UserLabel As System.Windows.Forms.Label
    Friend WithEvents PassLabel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
