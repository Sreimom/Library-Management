﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryChangePass
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryChangePass))
        Me.EditCancelButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.NewpassagainLabel = New System.Windows.Forms.Label()
        Me.NewpassLabel = New System.Windows.Forms.Label()
        Me.OldpassLabel = New System.Windows.Forms.Label()
        Me.NewpassagainTextBox = New System.Windows.Forms.TextBox()
        Me.NewpassTextBox = New System.Windows.Forms.TextBox()
        Me.OldpassTextBox = New System.Windows.Forms.TextBox()
        Me.UpdateButton = New System.Windows.Forms.Button()
        Me.checkLabel = New System.Windows.Forms.Label()
        Me.PrepareLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'EditCancelButton
        '
        Me.EditCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.EditCancelButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EditCancelButton.ImageIndex = 0
        Me.EditCancelButton.ImageList = Me.ImageList1
        Me.EditCancelButton.Location = New System.Drawing.Point(23, 214)
        Me.EditCancelButton.Name = "EditCancelButton"
        Me.EditCancelButton.Size = New System.Drawing.Size(92, 30)
        Me.EditCancelButton.TabIndex = 42
        Me.EditCancelButton.Text = "បោះបង់"
        Me.EditCancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.EditCancelButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "floppy-icon.png")
        '
        'NewpassagainLabel
        '
        Me.NewpassagainLabel.AutoSize = True
        Me.NewpassagainLabel.BackColor = System.Drawing.Color.Transparent
        Me.NewpassagainLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewpassagainLabel.Location = New System.Drawing.Point(19, 133)
        Me.NewpassagainLabel.Name = "NewpassagainLabel"
        Me.NewpassagainLabel.Size = New System.Drawing.Size(81, 24)
        Me.NewpassagainLabel.TabIndex = 44
        Me.NewpassagainLabel.Text = "លេខសម្ងាត់ថ្មី"
        '
        'NewpassLabel
        '
        Me.NewpassLabel.AutoSize = True
        Me.NewpassLabel.BackColor = System.Drawing.Color.Transparent
        Me.NewpassLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewpassLabel.Location = New System.Drawing.Point(19, 72)
        Me.NewpassLabel.Name = "NewpassLabel"
        Me.NewpassLabel.Size = New System.Drawing.Size(81, 24)
        Me.NewpassLabel.TabIndex = 45
        Me.NewpassLabel.Text = "លេខសម្ងាត់ថ្មី"
        '
        'OldpassLabel
        '
        Me.OldpassLabel.AutoSize = True
        Me.OldpassLabel.BackColor = System.Drawing.Color.Transparent
        Me.OldpassLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldpassLabel.Location = New System.Drawing.Point(19, 11)
        Me.OldpassLabel.Name = "OldpassLabel"
        Me.OldpassLabel.Size = New System.Drawing.Size(98, 24)
        Me.OldpassLabel.TabIndex = 46
        Me.OldpassLabel.Text = "លេខសម្ងាត់ចាស់"
        '
        'NewpassagainTextBox
        '
        Me.NewpassagainTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewpassagainTextBox.Location = New System.Drawing.Point(23, 160)
        Me.NewpassagainTextBox.Name = "NewpassagainTextBox"
        Me.NewpassagainTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.NewpassagainTextBox.Size = New System.Drawing.Size(288, 32)
        Me.NewpassagainTextBox.TabIndex = 41
        '
        'NewpassTextBox
        '
        Me.NewpassTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewpassTextBox.Location = New System.Drawing.Point(23, 98)
        Me.NewpassTextBox.Name = "NewpassTextBox"
        Me.NewpassTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.NewpassTextBox.Size = New System.Drawing.Size(288, 32)
        Me.NewpassTextBox.TabIndex = 40
        '
        'OldpassTextBox
        '
        Me.OldpassTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OldpassTextBox.Location = New System.Drawing.Point(23, 38)
        Me.OldpassTextBox.Name = "OldpassTextBox"
        Me.OldpassTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.OldpassTextBox.Size = New System.Drawing.Size(288, 32)
        Me.OldpassTextBox.TabIndex = 39
        '
        'UpdateButton
        '
        Me.UpdateButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UpdateButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.UpdateButton.ImageIndex = 1
        Me.UpdateButton.ImageList = Me.ImageList1
        Me.UpdateButton.Location = New System.Drawing.Point(219, 214)
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.Size = New System.Drawing.Size(92, 30)
        Me.UpdateButton.TabIndex = 43
        Me.UpdateButton.Text = "កែប្រែ"
        Me.UpdateButton.UseVisualStyleBackColor = True
        '
        'checkLabel
        '
        Me.checkLabel.AutoSize = True
        Me.checkLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkLabel.Location = New System.Drawing.Point(230, 133)
        Me.checkLabel.Name = "checkLabel"
        Me.checkLabel.Size = New System.Drawing.Size(0, 24)
        Me.checkLabel.TabIndex = 47
        '
        'PrepareLabel
        '
        Me.PrepareLabel.AutoSize = True
        Me.PrepareLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrepareLabel.Location = New System.Drawing.Point(228, 73)
        Me.PrepareLabel.Name = "PrepareLabel"
        Me.PrepareLabel.Size = New System.Drawing.Size(0, 24)
        Me.PrepareLabel.TabIndex = 48
        '
        'FrmLibraryChangePass
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(330, 254)
        Me.Controls.Add(Me.EditCancelButton)
        Me.Controls.Add(Me.NewpassagainLabel)
        Me.Controls.Add(Me.NewpassLabel)
        Me.Controls.Add(Me.OldpassLabel)
        Me.Controls.Add(Me.NewpassagainTextBox)
        Me.Controls.Add(Me.NewpassTextBox)
        Me.Controls.Add(Me.OldpassTextBox)
        Me.Controls.Add(Me.UpdateButton)
        Me.Controls.Add(Me.checkLabel)
        Me.Controls.Add(Me.PrepareLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryChangePass"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents EditCancelButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents NewpassagainLabel As System.Windows.Forms.Label
    Friend WithEvents NewpassLabel As System.Windows.Forms.Label
    Friend WithEvents OldpassLabel As System.Windows.Forms.Label
    Friend WithEvents NewpassagainTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NewpassTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OldpassTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UpdateButton As System.Windows.Forms.Button
    Friend WithEvents checkLabel As System.Windows.Forms.Label
    Friend WithEvents PrepareLabel As System.Windows.Forms.Label
End Class
