﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryUser))
        Me.CMDTextBox = New System.Windows.Forms.TextBox()
        Me.UploadPictureBox = New System.Windows.Forms.PictureBox()
        Me.ChangepassButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.UploadsButton = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripButton = New System.Windows.Forms.ToolStripDropDownButton()
        Me.SexGroupBox = New System.Windows.Forms.GroupBox()
        Me.ChooseSexLabel = New System.Windows.Forms.Label()
        Me.FemaleRadioButton = New System.Windows.Forms.RadioButton()
        Me.MaleRadioButton = New System.Windows.Forms.RadioButton()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.UserEditButton = New System.Windows.Forms.Button()
        Me.UserCancelButton = New System.Windows.Forms.Button()
        Me.UserGroupComboBox = New System.Windows.Forms.ComboBox()
        Me.UserGroupLabel = New System.Windows.Forms.Label()
        Me.UserNoLabel = New System.Windows.Forms.Label()
        Me.UserLoginLabel = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.UserFullnameLabel = New System.Windows.Forms.Label()
        Me.UserLoginTextBox = New System.Windows.Forms.TextBox()
        Me.UserNoTextBox = New System.Windows.Forms.TextBox()
        Me.UserFullnameTextBox = New System.Windows.Forms.TextBox()
        Me.UserPasswordLabel = New System.Windows.Forms.Label()
        Me.UserPhoneTextBox = New System.Windows.Forms.TextBox()
        Me.UserPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.UserFacebookTextBox = New System.Windows.Forms.TextBox()
        Me.UserEmailTextBox = New System.Windows.Forms.TextBox()
        Me.UserFacebookLabel = New System.Windows.Forms.Label()
        Me.UserPhoneLabel = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.UserEmailLabel = New System.Windows.Forms.Label()
        CType(Me.UploadPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SexGroupBox.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CMDTextBox
        '
        Me.CMDTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CMDTextBox.Location = New System.Drawing.Point(-1, 545)
        Me.CMDTextBox.Multiline = True
        Me.CMDTextBox.Name = "CMDTextBox"
        Me.CMDTextBox.Size = New System.Drawing.Size(732, 120)
        Me.CMDTextBox.TabIndex = 34
        '
        'UploadPictureBox
        '
        Me.UploadPictureBox.BackgroundImage = CType(resources.GetObject("UploadPictureBox.BackgroundImage"), System.Drawing.Image)
        Me.UploadPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.UploadPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.UploadPictureBox.Location = New System.Drawing.Point(304, 31)
        Me.UploadPictureBox.Name = "UploadPictureBox"
        Me.UploadPictureBox.Size = New System.Drawing.Size(204, 197)
        Me.UploadPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.UploadPictureBox.TabIndex = 30
        Me.UploadPictureBox.TabStop = False
        '
        'ChangepassButton
        '
        Me.ChangepassButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.ChangepassButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ChangepassButton.ImageIndex = 2
        Me.ChangepassButton.ImageList = Me.ImageList1
        Me.ChangepassButton.Location = New System.Drawing.Point(132, 419)
        Me.ChangepassButton.Name = "ChangepassButton"
        Me.ChangepassButton.Size = New System.Drawing.Size(132, 34)
        Me.ChangepassButton.TabIndex = 9
        Me.ChangepassButton.Text = "ប្តូរលេខសម្ងាត់"
        Me.ChangepassButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ChangepassButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "cancel.png")
        Me.ImageList1.Images.SetKeyName(1, "floppy-icon.png")
        Me.ImageList1.Images.SetKeyName(2, "grey-padlock.png")
        Me.ImageList1.Images.SetKeyName(3, "folder-yellow-explorer-icon.png")
        Me.ImageList1.Images.SetKeyName(4, "loysaevhusmyqimlzgpy.png")
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.CloseToolStripMenuItem.Text = "&បិទ"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.ImageIndex = 4
        Me.Button1.ImageList = Me.ImageList1
        Me.Button1.Location = New System.Drawing.Point(409, 231)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(99, 34)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "ថតរូប"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button1.UseVisualStyleBackColor = True
        '
        'UploadsButton
        '
        Me.UploadsButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!)
        Me.UploadsButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.UploadsButton.ImageIndex = 3
        Me.UploadsButton.ImageList = Me.ImageList1
        Me.UploadsButton.Location = New System.Drawing.Point(303, 231)
        Me.UploadsButton.Name = "UploadsButton"
        Me.UploadsButton.Size = New System.Drawing.Size(99, 34)
        Me.UploadsButton.TabIndex = 5
        Me.UploadsButton.Text = "ជ្រើសរើស"
        Me.UploadsButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.UploadsButton.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.Label4.Location = New System.Drawing.Point(368, 4)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 27)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "រូបភាព"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Image = CType(resources.GetObject("SaveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.SaveToolStripMenuItem.Text = "រក្សាទុក"
        '
        'FileToolStripButton
        '
        Me.FileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.FileToolStripButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileToolStripButton.Image = CType(resources.GetObject("FileToolStripButton.Image"), System.Drawing.Image)
        Me.FileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileToolStripButton.Name = "FileToolStripButton"
        Me.FileToolStripButton.Size = New System.Drawing.Size(59, 26)
        Me.FileToolStripButton.Text = "ឯកសារ"
        '
        'SexGroupBox
        '
        Me.SexGroupBox.Controls.Add(Me.ChooseSexLabel)
        Me.SexGroupBox.Controls.Add(Me.FemaleRadioButton)
        Me.SexGroupBox.Controls.Add(Me.MaleRadioButton)
        Me.SexGroupBox.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.SexGroupBox.Location = New System.Drawing.Point(10, 190)
        Me.SexGroupBox.Name = "SexGroupBox"
        Me.SexGroupBox.Size = New System.Drawing.Size(256, 76)
        Me.SexGroupBox.TabIndex = 32
        Me.SexGroupBox.TabStop = False
        Me.SexGroupBox.Text = "ភេទ"
        '
        'ChooseSexLabel
        '
        Me.ChooseSexLabel.AutoSize = True
        Me.ChooseSexLabel.Location = New System.Drawing.Point(94, 14)
        Me.ChooseSexLabel.Name = "ChooseSexLabel"
        Me.ChooseSexLabel.Size = New System.Drawing.Size(60, 27)
        Me.ChooseSexLabel.TabIndex = 34
        Me.ChooseSexLabel.Text = "choose"
        '
        'FemaleRadioButton
        '
        Me.FemaleRadioButton.AutoSize = True
        Me.FemaleRadioButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.FemaleRadioButton.Location = New System.Drawing.Point(152, 30)
        Me.FemaleRadioButton.Name = "FemaleRadioButton"
        Me.FemaleRadioButton.Size = New System.Drawing.Size(50, 31)
        Me.FemaleRadioButton.TabIndex = 32
        Me.FemaleRadioButton.Text = "ស្រី"
        Me.FemaleRadioButton.UseVisualStyleBackColor = True
        '
        'MaleRadioButton
        '
        Me.MaleRadioButton.AutoSize = True
        Me.MaleRadioButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.MaleRadioButton.Location = New System.Drawing.Point(44, 30)
        Me.MaleRadioButton.Name = "MaleRadioButton"
        Me.MaleRadioButton.Size = New System.Drawing.Size(60, 31)
        Me.MaleRadioButton.TabIndex = 33
        Me.MaleRadioButton.Text = "ប្រុស"
        Me.MaleRadioButton.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(731, 29)
        Me.ToolStrip1.TabIndex = 35
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'UserEditButton
        '
        Me.UserEditButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UserEditButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserEditButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.UserEditButton.ImageIndex = 1
        Me.UserEditButton.ImageList = Me.ImageList1
        Me.UserEditButton.Location = New System.Drawing.Point(432, 469)
        Me.UserEditButton.Name = "UserEditButton"
        Me.UserEditButton.Size = New System.Drawing.Size(98, 30)
        Me.UserEditButton.TabIndex = 12
        Me.UserEditButton.Text = "កែប្រែ"
        Me.UserEditButton.UseVisualStyleBackColor = True
        '
        'UserCancelButton
        '
        Me.UserCancelButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UserCancelButton.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserCancelButton.ImageIndex = 0
        Me.UserCancelButton.ImageList = Me.ImageList1
        Me.UserCancelButton.Location = New System.Drawing.Point(9, 469)
        Me.UserCancelButton.Name = "UserCancelButton"
        Me.UserCancelButton.Size = New System.Drawing.Size(105, 30)
        Me.UserCancelButton.TabIndex = 11
        Me.UserCancelButton.Text = "បោះបង់"
        Me.UserCancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.UserCancelButton.UseVisualStyleBackColor = True
        '
        'UserGroupComboBox
        '
        Me.UserGroupComboBox.DropDownHeight = 200
        Me.UserGroupComboBox.Enabled = False
        Me.UserGroupComboBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserGroupComboBox.FormattingEnabled = True
        Me.UserGroupComboBox.IntegralHeight = False
        Me.UserGroupComboBox.Location = New System.Drawing.Point(8, 93)
        Me.UserGroupComboBox.Name = "UserGroupComboBox"
        Me.UserGroupComboBox.Size = New System.Drawing.Size(256, 32)
        Me.UserGroupComboBox.TabIndex = 2
        '
        'UserGroupLabel
        '
        Me.UserGroupLabel.AutoSize = True
        Me.UserGroupLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserGroupLabel.Location = New System.Drawing.Point(5, 66)
        Me.UserGroupLabel.Name = "UserGroupLabel"
        Me.UserGroupLabel.Size = New System.Drawing.Size(37, 27)
        Me.UserGroupLabel.TabIndex = 0
        Me.UserGroupLabel.Text = "ក្រុម"
        '
        'UserNoLabel
        '
        Me.UserNoLabel.AutoSize = True
        Me.UserNoLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserNoLabel.Location = New System.Drawing.Point(4, 4)
        Me.UserNoLabel.Name = "UserNoLabel"
        Me.UserNoLabel.Size = New System.Drawing.Size(67, 27)
        Me.UserNoLabel.TabIndex = 0
        Me.UserNoLabel.Text = "លេខរៀង"
        '
        'UserLoginLabel
        '
        Me.UserLoginLabel.AutoSize = True
        Me.UserLoginLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserLoginLabel.Location = New System.Drawing.Point(5, 269)
        Me.UserLoginLabel.Name = "UserLoginLabel"
        Me.UserLoginLabel.Size = New System.Drawing.Size(159, 27)
        Me.UserLoginLabel.TabIndex = 0
        Me.UserLoginLabel.Text = "សម្រាប់ចូលប្រើ ( Login )"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Location = New System.Drawing.Point(-1, 27)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(193, 515)
        Me.Panel2.TabIndex = 36
        '
        'UserFullnameLabel
        '
        Me.UserFullnameLabel.AutoSize = True
        Me.UserFullnameLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserFullnameLabel.Location = New System.Drawing.Point(5, 128)
        Me.UserFullnameLabel.Name = "UserFullnameLabel"
        Me.UserFullnameLabel.Size = New System.Drawing.Size(50, 27)
        Me.UserFullnameLabel.TabIndex = 0
        Me.UserFullnameLabel.Text = "ឈ្មោះ"
        '
        'UserLoginTextBox
        '
        Me.UserLoginTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.UserLoginTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList
        Me.UserLoginTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserLoginTextBox.Location = New System.Drawing.Point(8, 296)
        Me.UserLoginTextBox.Name = "UserLoginTextBox"
        Me.UserLoginTextBox.Size = New System.Drawing.Size(256, 32)
        Me.UserLoginTextBox.TabIndex = 4
        '
        'UserNoTextBox
        '
        Me.UserNoTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.UserNoTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList
        Me.UserNoTextBox.Enabled = False
        Me.UserNoTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserNoTextBox.Location = New System.Drawing.Point(8, 31)
        Me.UserNoTextBox.Name = "UserNoTextBox"
        Me.UserNoTextBox.Size = New System.Drawing.Size(256, 32)
        Me.UserNoTextBox.TabIndex = 1
        '
        'UserFullnameTextBox
        '
        Me.UserFullnameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.UserFullnameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList
        Me.UserFullnameTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserFullnameTextBox.Location = New System.Drawing.Point(8, 155)
        Me.UserFullnameTextBox.Name = "UserFullnameTextBox"
        Me.UserFullnameTextBox.Size = New System.Drawing.Size(256, 32)
        Me.UserFullnameTextBox.TabIndex = 3
        '
        'UserPasswordLabel
        '
        Me.UserPasswordLabel.AutoSize = True
        Me.UserPasswordLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserPasswordLabel.Location = New System.Drawing.Point(5, 393)
        Me.UserPasswordLabel.Name = "UserPasswordLabel"
        Me.UserPasswordLabel.Size = New System.Drawing.Size(82, 27)
        Me.UserPasswordLabel.TabIndex = 28
        Me.UserPasswordLabel.Text = "លេខសម្ងាត់"
        '
        'UserPhoneTextBox
        '
        Me.UserPhoneTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserPhoneTextBox.Location = New System.Drawing.Point(277, 420)
        Me.UserPhoneTextBox.Name = "UserPhoneTextBox"
        Me.UserPhoneTextBox.Size = New System.Drawing.Size(253, 32)
        Me.UserPhoneTextBox.TabIndex = 10
        '
        'UserPasswordTextBox
        '
        Me.UserPasswordTextBox.Enabled = False
        Me.UserPasswordTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserPasswordTextBox.Location = New System.Drawing.Point(9, 420)
        Me.UserPasswordTextBox.Name = "UserPasswordTextBox"
        Me.UserPasswordTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.UserPasswordTextBox.Size = New System.Drawing.Size(115, 32)
        Me.UserPasswordTextBox.TabIndex = 8
        '
        'UserFacebookTextBox
        '
        Me.UserFacebookTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserFacebookTextBox.Location = New System.Drawing.Point(277, 359)
        Me.UserFacebookTextBox.Name = "UserFacebookTextBox"
        Me.UserFacebookTextBox.Size = New System.Drawing.Size(253, 32)
        Me.UserFacebookTextBox.TabIndex = 7
        '
        'UserEmailTextBox
        '
        Me.UserEmailTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserEmailTextBox.Location = New System.Drawing.Point(10, 359)
        Me.UserEmailTextBox.Name = "UserEmailTextBox"
        Me.UserEmailTextBox.Size = New System.Drawing.Size(256, 32)
        Me.UserEmailTextBox.TabIndex = 6
        '
        'UserFacebookLabel
        '
        Me.UserFacebookLabel.AutoSize = True
        Me.UserFacebookLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserFacebookLabel.Location = New System.Drawing.Point(272, 334)
        Me.UserFacebookLabel.Name = "UserFacebookLabel"
        Me.UserFacebookLabel.Size = New System.Drawing.Size(67, 27)
        Me.UserFacebookLabel.TabIndex = 2
        Me.UserFacebookLabel.Text = "ហ្វេសបុក"
        '
        'UserPhoneLabel
        '
        Me.UserPhoneLabel.AutoSize = True
        Me.UserPhoneLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserPhoneLabel.Location = New System.Drawing.Point(272, 393)
        Me.UserPhoneLabel.Name = "UserPhoneLabel"
        Me.UserPhoneLabel.Size = New System.Drawing.Size(52, 27)
        Me.UserPhoneLabel.TabIndex = 4
        Me.UserPhoneLabel.Text = "ទូរស័ព្ទ"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.SexGroupBox)
        Me.Panel1.Controls.Add(Me.UploadPictureBox)
        Me.Panel1.Controls.Add(Me.ChangepassButton)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.UploadsButton)
        Me.Panel1.Controls.Add(Me.UserEditButton)
        Me.Panel1.Controls.Add(Me.UserCancelButton)
        Me.Panel1.Controls.Add(Me.UserGroupComboBox)
        Me.Panel1.Controls.Add(Me.UserGroupLabel)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.UserNoLabel)
        Me.Panel1.Controls.Add(Me.UserLoginLabel)
        Me.Panel1.Controls.Add(Me.UserFullnameLabel)
        Me.Panel1.Controls.Add(Me.UserLoginTextBox)
        Me.Panel1.Controls.Add(Me.UserNoTextBox)
        Me.Panel1.Controls.Add(Me.UserFullnameTextBox)
        Me.Panel1.Controls.Add(Me.UserPasswordLabel)
        Me.Panel1.Controls.Add(Me.UserPhoneTextBox)
        Me.Panel1.Controls.Add(Me.UserPasswordTextBox)
        Me.Panel1.Controls.Add(Me.UserFacebookTextBox)
        Me.Panel1.Controls.Add(Me.UserEmailTextBox)
        Me.Panel1.Controls.Add(Me.UserFacebookLabel)
        Me.Panel1.Controls.Add(Me.UserEmailLabel)
        Me.Panel1.Controls.Add(Me.UserPhoneLabel)
        Me.Panel1.Location = New System.Drawing.Point(190, 31)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(541, 511)
        Me.Panel1.TabIndex = 37
        '
        'UserEmailLabel
        '
        Me.UserEmailLabel.AutoSize = True
        Me.UserEmailLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.UserEmailLabel.Location = New System.Drawing.Point(4, 334)
        Me.UserEmailLabel.Name = "UserEmailLabel"
        Me.UserEmailLabel.Size = New System.Drawing.Size(52, 27)
        Me.UserEmailLabel.TabIndex = 2
        Me.UserEmailLabel.Text = "អ៊ីម៉ែល"
        '
        'FrmLibraryUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(731, 538)
        Me.Controls.Add(Me.CMDTextBox)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryUser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.UploadPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SexGroupBox.ResumeLayout(False)
        Me.SexGroupBox.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CMDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UploadPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ChangepassButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents UploadsButton As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents SexGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ChooseSexLabel As System.Windows.Forms.Label
    Friend WithEvents FemaleRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents MaleRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents UserEditButton As System.Windows.Forms.Button
    Friend WithEvents UserCancelButton As System.Windows.Forms.Button
    Friend WithEvents UserGroupComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents UserGroupLabel As System.Windows.Forms.Label
    Friend WithEvents UserNoLabel As System.Windows.Forms.Label
    Friend WithEvents UserLoginLabel As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents UserFullnameLabel As System.Windows.Forms.Label
    Friend WithEvents UserLoginTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserFullnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserPasswordLabel As System.Windows.Forms.Label
    Friend WithEvents UserPhoneTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserFacebookTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserEmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserFacebookLabel As System.Windows.Forms.Label
    Friend WithEvents UserPhoneLabel As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents UserEmailLabel As System.Windows.Forms.Label
End Class
