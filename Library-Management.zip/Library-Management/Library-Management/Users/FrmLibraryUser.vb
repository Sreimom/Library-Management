﻿Imports System.IO

Public Class FrmLibraryUser
    Private Sub IsEmpty()
        If UserFullnameTextBox.Text = "" Then
            UserFullnameLabel.ForeColor = Color.Red
            UserFullnameTextBox.Focus()
        ElseIf ChooseSexLabel.Text = "choose" Then
            SexGroupBox.ForeColor = Color.Red
        ElseIf UserLoginTextBox.Text = "" Then
            UserLoginTextBox.Focus()
            UserLoginLabel.ForeColor = Color.Red
        ElseIf UserEmailTextBox.Text = "" Then
            UserEmailTextBox.Focus()
            UserEmailLabel.ForeColor = Color.Red
        ElseIf UserFacebookTextBox.Text = "" Then
            UserFacebookTextBox.Focus()
            UserFacebookLabel.ForeColor = Color.Red
        ElseIf UserPhoneTextBox.Text = "" Then
            UserPhoneTextBox.Focus()
            UserPhoneLabel.ForeColor = Color.Red
        Else

            UserFullnameLabel.ForeColor = Color.Black
            SexGroupBox.ForeColor = Color.Black
            UserLoginLabel.ForeColor = Color.Black
            UserEmailLabel.ForeColor = Color.Black
            UserFacebookLabel.ForeColor = Color.Black
            UserPhoneLabel.ForeColor = Color.Black

        End If
    End Sub

    Private Sub MaleRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles MaleRadioButton.CheckedChanged
        ChooseSexLabel.text = "Male"
    End Sub

    Private Sub FemaleRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles FemaleRadioButton.CheckedChanged
        ChooseSexLabel.Text = "Female"
    End Sub
    Private Sub UserEditButton_Click(sender As Object, e As EventArgs) Handles UserEditButton.Click
        Call IsEmpty()
        If UserFullnameTextBox.Text <> "" And ChooseSexLabel.Text <> "choose" And UserLoginTextBox.Text <> "" And UserEmailTextBox.Text <> "" And UserFacebookTextBox.Text <> "" And UserPhoneTextBox.Text <> "" Then
            FrmLibraryProcessing.Timer1.Start()
            FrmLibraryProcessing.Timer1.Enabled = True
            FrmLibraryProcessing.Timer1.Interval = 5

            Dim PicRename As String = TimeOfDay.ToString("hh-mm-ss")
            PicRename = Replace(PicRename, "-", "")
            Dim Sex As String
            If MaleRadioButton.Checked = True Then
                Sex = "ប្រុស"
            Else
                Sex = "ស្រី"
            End If
            If IsNothing(UploadPictureBox.Image) Then
                PicRename = "User.png"
            Else
                PicRename = "User.png"
                'PicRename = PicRename & ".jpg"
                'Dim path As String = Replace(Directory.GetCurrentDirectory(), "\Debug", "\Library-Management\Photo\Users\Photo\ " & PicRename)
                'UploadPictureBox.Image.Save(path, Drawing.Imaging.ImageFormat.Jpeg)
            End If


            CMDTextBox.Text = "UPDATE users SET " & _
                "user_fullname='" & UserFullnameTextBox.Text & _
                "', user_login='" & UserLoginTextBox.Text & _
                "', user_email='" & UserEmailTextBox.Text & _
                "', user_fb='" & UserFacebookTextBox.Text & _
                "',user_phone='" & UserPhoneTextBox.Text & _
                "',user_pic='" & PicRename & _
                "',user_sex='" & Sex & _
                "' WHERE user_id=" & UserNoTextBox.Text
            LibraryCommand.SQL(CMDTextBox.Text)
            Me.Close()
        End If
    End Sub

    Private Sub frmuser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call LibraryGetData.ToUser()
    End Sub

    Private Sub ChangepassButton_Click(sender As Object, e As EventArgs) Handles ChangepassButton.Click
        FrmLibraryChangePass.ShowDialog()
    End Sub

    Private Sub UserCancelButton_Click(sender As Object, e As EventArgs) Handles UserCancelButton.Click
        Me.Close()
    End Sub
End Class