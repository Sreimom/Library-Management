﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLibraryRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLibraryRegister))
        Me.LoginLabel = New System.Windows.Forms.Label()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.loginTextBox = New System.Windows.Forms.TextBox()
        Me.UpdateButton = New System.Windows.Forms.Button()
        Me.closeButton = New System.Windows.Forms.Button()
        Me.checkLabel = New System.Windows.Forms.Label()
        Me.NewpassagainLabel = New System.Windows.Forms.Label()
        Me.checkloginLabel = New System.Windows.Forms.Label()
        Me.PrepareLabel = New System.Windows.Forms.Label()
        Me.NewpassLabel = New System.Windows.Forms.Label()
        Me.NewpassagainTextBox = New System.Windows.Forms.TextBox()
        Me.NewpassTextBox = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'LoginLabel
        '
        Me.LoginLabel.BackColor = System.Drawing.Color.Transparent
        Me.LoginLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.LoginLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LoginLabel.ImageIndex = 3
        Me.LoginLabel.ImageList = Me.ImageList1
        Me.LoginLabel.Location = New System.Drawing.Point(16, 11)
        Me.LoginLabel.Name = "LoginLabel"
        Me.LoginLabel.Size = New System.Drawing.Size(159, 24)
        Me.LoginLabel.TabIndex = 34
        Me.LoginLabel.Text = "អ្នកប្រើប្រាស់ (Login)"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "No.png")
        Me.ImageList1.Images.SetKeyName(1, "Yes_check.png")
        Me.ImageList1.Images.SetKeyName(2, "lock-24-512.png")
        Me.ImageList1.Images.SetKeyName(3, "Users-Name-icon.png")
        '
        'loginTextBox
        '
        Me.loginTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loginTextBox.Location = New System.Drawing.Point(20, 38)
        Me.loginTextBox.Name = "loginTextBox"
        Me.loginTextBox.Size = New System.Drawing.Size(288, 32)
        Me.loginTextBox.TabIndex = 29
        '
        'UpdateButton
        '
        Me.UpdateButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UpdateButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.UpdateButton.ImageIndex = 1
        Me.UpdateButton.ImageList = Me.ImageList1
        Me.UpdateButton.Location = New System.Drawing.Point(216, 214)
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.Size = New System.Drawing.Size(92, 30)
        Me.UpdateButton.TabIndex = 33
        Me.UpdateButton.Text = "ចុះឈ្មោះ"
        Me.UpdateButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.UpdateButton.UseVisualStyleBackColor = True
        '
        'closeButton
        '
        Me.closeButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.closeButton.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.closeButton.ImageIndex = 0
        Me.closeButton.ImageList = Me.ImageList1
        Me.closeButton.Location = New System.Drawing.Point(20, 214)
        Me.closeButton.Name = "closeButton"
        Me.closeButton.Size = New System.Drawing.Size(92, 30)
        Me.closeButton.TabIndex = 32
        Me.closeButton.Text = "បោះបង់"
        Me.closeButton.UseVisualStyleBackColor = True
        '
        'checkLabel
        '
        Me.checkLabel.AutoSize = True
        Me.checkLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkLabel.Location = New System.Drawing.Point(227, 133)
        Me.checkLabel.Name = "checkLabel"
        Me.checkLabel.Size = New System.Drawing.Size(0, 24)
        Me.checkLabel.TabIndex = 35
        '
        'NewpassagainLabel
        '
        Me.NewpassagainLabel.BackColor = System.Drawing.Color.Transparent
        Me.NewpassagainLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.NewpassagainLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.NewpassagainLabel.ImageIndex = 2
        Me.NewpassagainLabel.ImageList = Me.ImageList1
        Me.NewpassagainLabel.Location = New System.Drawing.Point(16, 133)
        Me.NewpassagainLabel.Name = "NewpassagainLabel"
        Me.NewpassagainLabel.Size = New System.Drawing.Size(178, 24)
        Me.NewpassagainLabel.TabIndex = 36
        Me.NewpassagainLabel.Text = "វាយលេខសម្ងាត់ម្តងទៀត"
        '
        'checkloginLabel
        '
        Me.checkloginLabel.AutoSize = True
        Me.checkloginLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkloginLabel.Location = New System.Drawing.Point(227, 11)
        Me.checkloginLabel.Name = "checkloginLabel"
        Me.checkloginLabel.Size = New System.Drawing.Size(0, 24)
        Me.checkloginLabel.TabIndex = 37
        '
        'PrepareLabel
        '
        Me.PrepareLabel.AutoSize = True
        Me.PrepareLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrepareLabel.Location = New System.Drawing.Point(225, 73)
        Me.PrepareLabel.Name = "PrepareLabel"
        Me.PrepareLabel.Size = New System.Drawing.Size(0, 24)
        Me.PrepareLabel.TabIndex = 38
        '
        'NewpassLabel
        '
        Me.NewpassLabel.BackColor = System.Drawing.Color.Transparent
        Me.NewpassLabel.Font = New System.Drawing.Font("Khmer OS Battambang", 10.75!)
        Me.NewpassLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.NewpassLabel.ImageIndex = 2
        Me.NewpassLabel.ImageList = Me.ImageList1
        Me.NewpassLabel.Location = New System.Drawing.Point(16, 72)
        Me.NewpassLabel.Name = "NewpassLabel"
        Me.NewpassLabel.Size = New System.Drawing.Size(106, 24)
        Me.NewpassLabel.TabIndex = 39
        Me.NewpassLabel.Text = "លេខសម្ងាត់"
        '
        'NewpassagainTextBox
        '
        Me.NewpassagainTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewpassagainTextBox.Location = New System.Drawing.Point(20, 160)
        Me.NewpassagainTextBox.Name = "NewpassagainTextBox"
        Me.NewpassagainTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.NewpassagainTextBox.Size = New System.Drawing.Size(288, 32)
        Me.NewpassagainTextBox.TabIndex = 31
        '
        'NewpassTextBox
        '
        Me.NewpassTextBox.Font = New System.Drawing.Font("Khmer OS Battambang", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewpassTextBox.Location = New System.Drawing.Point(20, 98)
        Me.NewpassTextBox.Name = "NewpassTextBox"
        Me.NewpassTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.NewpassTextBox.Size = New System.Drawing.Size(288, 32)
        Me.NewpassTextBox.TabIndex = 30
        '
        'FrmLibraryRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(325, 254)
        Me.Controls.Add(Me.LoginLabel)
        Me.Controls.Add(Me.loginTextBox)
        Me.Controls.Add(Me.UpdateButton)
        Me.Controls.Add(Me.closeButton)
        Me.Controls.Add(Me.checkLabel)
        Me.Controls.Add(Me.NewpassagainLabel)
        Me.Controls.Add(Me.checkloginLabel)
        Me.Controls.Add(Me.PrepareLabel)
        Me.Controls.Add(Me.NewpassLabel)
        Me.Controls.Add(Me.NewpassagainTextBox)
        Me.Controls.Add(Me.NewpassTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLibraryRegister"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LoginLabel As System.Windows.Forms.Label
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents loginTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UpdateButton As System.Windows.Forms.Button
    Friend WithEvents closeButton As System.Windows.Forms.Button
    Friend WithEvents checkLabel As System.Windows.Forms.Label
    Friend WithEvents NewpassagainLabel As System.Windows.Forms.Label
    Friend WithEvents checkloginLabel As System.Windows.Forms.Label
    Friend WithEvents PrepareLabel As System.Windows.Forms.Label
    Friend WithEvents NewpassLabel As System.Windows.Forms.Label
    Friend WithEvents NewpassagainTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NewpassTextBox As System.Windows.Forms.TextBox
End Class
