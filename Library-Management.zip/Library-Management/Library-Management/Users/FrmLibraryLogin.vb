﻿
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient

Public Class FrmLibraryLogin
    Dim Current As Integer = 100

    Private Sub txtuser_GotFocus(sender As Object, e As EventArgs) Handles txtuser.GotFocus, txtpass.GotFocus
        InputLanguages.EnglishKeyboard() 'ប្តូរ Keyboard
    End Sub



    Private Sub login()
        'Me.btnlogin.Enabled = False


        Dim MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = My.Settings.ConnLibrary
        Dim READER As MySqlDataReader
        Dim Password As String
        Dim userlogin As String
        Dim userfullname As String
        Try
            MysqlConn.Open()
            Dim Query As String
            Query = " SELECT  * From users  WHERE   (user_login = '" & txtuser.Text & "' )AND (user_pass = '" & txtpass.Text & "')"
            Dim Command = New MySqlCommand(Query, MysqlConn)
            READER = Command.ExecuteReader


            If READER.HasRows Then
                While READER.Read()
                    userlogin = READER("user_login").ToString()
                    Password = READER("user_pass").ToString()
                    userfullname = READER("user_fullname").ToString()
                    FrmLibraryMain.UserFullnameToolStripLabel.Text = userfullname 'បញ្ចូនតម្លៃទៅអោយ frmlibrary.UserFullnameToolStripLabel.Text
                    FrmLibraryMain.IDToolStripLabel.Text = READER("user_id").ToString() 'បញ្ចូនតម្លៃទៅអោយ frmlibrary.IDToolStripLabel.Text
                    FrmLibraryMain.GroupToolStripLabel.Text = READER("group_id").ToString()
                    'FrmLibraryUser.PicnameTextBox.Text = READER("user_pic").ToString() 'បញ្ចូនតម្លៃទៅអោយ frmuser.PicnameTextBox.Text

                    If userlogin = txtuser.Text And Password = txtpass.Text Then
                        If RemmberCheckBox.Checked = True Then
                            My.Settings.Login = userlogin
                            My.Settings.Pass = Password
                            My.Settings.Save()
                            My.Settings.Reload()
                        Else
                            My.Settings.Login = ""
                            My.Settings.Pass = ""
                            My.Settings.Reset()
                        End If

                        'MessageBox.Show("Logged in successfully as " & userName, "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        'frmlibrary.Show()

                        FrmLibraryMain.PermissionIS()
                        LibraryGetData.ToListViewAll()
                        'FrmLibraryMain.cheakItemInItemlistView()
                        txtpass.Text = ""
                        txtuser.Text = ""
                        UserLabel.Hide()
                        PassLabel.Hide()
                        Me.Close()
                    End If

                End While

            Else

                CountLabel.Text = 1 + CountLabel.Text.ToString
                If CountLabel.Text = 4 Then
                    CountLabel.Text = 0
                    'Me.Close()
                    'frmlibrary.Close()
                    NavigateWebURL("http://mylibrary.freesite.host/", "default")
                End If

                MessageBox.Show("Username and Password do not match..", "Authentication Failure", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                'Clear all fields
                txtpass.Text = ""
                txtuser.Text = ""
                UserLabel.Show()
                PassLabel.Show()
                txtuser.Focus()
            End If






            MysqlConn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try

    End Sub


    Private Sub frmlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.AllowTransparency = True 'បិតផ្ទាំងខាងក្រោយ
        Me.TransparencyKey = BackColor 'បិតផ្ទាំងខាងក្រោយ
        UserLabel.Hide()
        PassLabel.Hide()
        txtpass.UseSystemPasswordChar = True
        txtuser.Text = My.Settings.Login
        txtpass.Text = My.Settings.Pass
        If RemmberCheckBox.Checked = True Then
            My.Settings.Login = txtuser.Text
            My.Settings.Pass = txtpass.Text
            My.Settings.Save()
            My.Settings.Reload()
        Else
            My.Settings.Login = ""
            My.Settings.Pass = ""
            My.Settings.Reset()
        End If



    End Sub



    Private Sub CloseLable_Click(sender As Object, e As EventArgs) Handles CloseLable.Click
        'Dim opt As String = MsgBox("Do you want to close?", vbYesNo)
        'If opt = vbYes Then
        '    Me.Close()
        '    frmlibrary.Close()
        'End If
        Me.Close()
        FrmLibraryMain.Close()
    End Sub
    Sub checklogin()
        If txtuser.Text = "" Or txtpass.Text = "" Then
            UserLabel.Show()
            PassLabel.Show()
            txtuser.Focus()
        Else
            login()
        End If
        If txtpass.Text = "" Then
            PassLabel.Show()
            txtpass.Focus()
        Else
            PassLabel.Hide()
        End If
        If txtuser.Text = "" Then
            UserLabel.Show()
            txtuser.Focus()
        Else
            UserLabel.Hide()
        End If
    End Sub


    Private Sub LoginLable_Click(sender As Object, e As EventArgs) Handles LoginLable.Click
        checklogin() 'Check លក្ខខ័ណ្ឌ

    End Sub
    Private Sub txtpass_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtuser.KeyDown, txtpass.KeyDown

        If e.KeyCode = Keys.Enter Then 'Enter key

            checklogin() 'Check លក្ខខ័ណ្ឌ

        End If

    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        FrmLibraryRegister.ShowDialog()
    End Sub



    Private Sub frmlogin_FormClosing(sender As Object, e As EventArgs) Handles Me.FormClosing
        FrmLibraryMain.MainPanel.Hide()
    End Sub


    Private Sub NavigateWebURL(ByVal URL As String, Optional browser As String = "default")

        If Not (browser = "default") Then
            Try
                '// try set browser if there was an error (browser not installed)
                Process.Start(browser, URL)
            Catch ex As Exception
                '// use default browser
                Process.Start(URL)
            End Try

        Else
            '// use default browser
            Process.Start(URL)

        End If

    End Sub

    Private Sub WLinkLabel_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles WLinkLabel.LinkClicked
        NavigateWebURL("http://mylibrary.freesite.host/", "default")
    End Sub
End Class
