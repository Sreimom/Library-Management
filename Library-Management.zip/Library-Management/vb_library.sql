-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for vb_library
CREATE DATABASE IF NOT EXISTS `vb_library` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `vb_library`;

-- Dumping structure for table vb_library.borrows
CREATE TABLE IF NOT EXISTS `borrows` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `bu_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `b_how_many` int(11) NOT NULL DEFAULT '0',
  `b_from` varchar(50) NOT NULL DEFAULT '0',
  `b_end` varchar(50) NOT NULL DEFAULT '0',
  `br_id` int(11) NOT NULL DEFAULT '2',
  `b_note` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`b_id`),
  KEY `FK_borrows_items` (`item_id`),
  KEY `FK_borrows_borrows_users` (`bu_id`),
  KEY `FK_borrows_users` (`user_id`),
  KEY `FK_borrows_borrows_returns` (`br_id`),
  CONSTRAINT `FK_borrows_borrows_returns` FOREIGN KEY (`br_id`) REFERENCES `borrows_returns` (`br_id`),
  CONSTRAINT `FK_borrows_borrows_users` FOREIGN KEY (`bu_id`) REFERENCES `borrows_users` (`bu_id`),
  CONSTRAINT `FK_borrows_items` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `FK_borrows_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.borrows_positions
CREATE TABLE IF NOT EXISTS `borrows_positions` (
  `bp_id` int(11) NOT NULL AUTO_INCREMENT,
  `bp_index` int(11) NOT NULL DEFAULT '0',
  `bp_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`bp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.borrows_returns
CREATE TABLE IF NOT EXISTS `borrows_returns` (
  `br_id` int(11) NOT NULL AUTO_INCREMENT,
  `br_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`br_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.borrows_users
CREATE TABLE IF NOT EXISTS `borrows_users` (
  `bu_id` int(11) NOT NULL AUTO_INCREMENT,
  `bp_id` int(11) NOT NULL DEFAULT '0',
  `bu_fullname` char(50) NOT NULL,
  `bu_sex` char(50) NOT NULL,
  `bu_phone` char(50) NOT NULL,
  `bu_email` char(50) NOT NULL,
  `bu_photo` char(50) NOT NULL,
  `bu_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bu_status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`bu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.communes
CREATE TABLE IF NOT EXISTS `communes` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `dist_id` int(11) NOT NULL DEFAULT '0',
  `communes` char(50) DEFAULT NULL,
  `other` char(50) DEFAULT NULL,
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`com_id`),
  KEY `FK_communes_districts` (`dist_id`),
  CONSTRAINT `FK_communes_districts` FOREIGN KEY (`dist_id`) REFERENCES `districts` (`dist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.districts
CREATE TABLE IF NOT EXISTS `districts` (
  `dist_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(11) NOT NULL DEFAULT '0',
  `districts` char(50) DEFAULT NULL,
  `other` char(50) DEFAULT NULL,
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`dist_id`),
  KEY `FK_districts_provinces` (`pro_id`),
  CONSTRAINT `FK_districts_provinces` FOREIGN KEY (`pro_id`) REFERENCES `provinces` (`pro_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.items
CREATE TABLE IF NOT EXISTS `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_title` char(50) DEFAULT NULL,
  `item_author` char(50) DEFAULT '',
  `item_editer` char(50) DEFAULT NULL,
  `item_publiser` char(50) DEFAULT NULL,
  `item_total_page` int(11) DEFAULT NULL,
  `item_stories` char(50) DEFAULT NULL,
  `note` char(50) DEFAULT '',
  `item_how_many` int(11) NOT NULL,
  `item_for_sell` int(11) DEFAULT NULL,
  `item_for_borrow` int(11) DEFAULT NULL,
  `item_pic` varchar(250) DEFAULT NULL,
  `item_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `item_delete` enum('Y','N') DEFAULT 'N',
  `cat_id` int(11) DEFAULT '1',
  `cab_id` int(11) DEFAULT '1',
  `she_id` int(11) DEFAULT '1',
  `lan_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '1',
  PRIMARY KEY (`item_id`),
  KEY `FK_items_cabinets` (`cab_id`),
  KEY `FK_items_shelfs` (`she_id`),
  KEY `FK_items_language` (`lan_id`),
  KEY `FK_items_category` (`cat_id`),
  KEY `FK_items_users` (`user_id`),
  CONSTRAINT `FK_items_cabinets` FOREIGN KEY (`cab_id`) REFERENCES `items_cabinets` (`cab_id`),
  CONSTRAINT `FK_items_category` FOREIGN KEY (`cat_id`) REFERENCES `items_categorys` (`cat_id`),
  CONSTRAINT `FK_items_language` FOREIGN KEY (`lan_id`) REFERENCES `items_languages` (`lan_id`),
  CONSTRAINT `FK_items_shelfs` FOREIGN KEY (`she_id`) REFERENCES `items_shelfs` (`she_id`),
  CONSTRAINT `FK_items_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.items_cabinets
CREATE TABLE IF NOT EXISTS `items_cabinets` (
  `cab_id` int(11) NOT NULL AUTO_INCREMENT,
  `cab_index` int(11) NOT NULL DEFAULT '0',
  `cab_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`cab_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.items_categorys
CREATE TABLE IF NOT EXISTS `items_categorys` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_index` int(11) NOT NULL DEFAULT '0',
  `cat_name` char(50) DEFAULT NULL,
  `cat_pic` char(50) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.items_languages
CREATE TABLE IF NOT EXISTS `items_languages` (
  `lan_id` int(11) NOT NULL AUTO_INCREMENT,
  `lan_index` int(11) NOT NULL DEFAULT '0',
  `lan_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`lan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.items_sells
CREATE TABLE IF NOT EXISTS `items_sells` (
  `sell_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `sell_date` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sell_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.items_shelfs
CREATE TABLE IF NOT EXISTS `items_shelfs` (
  `she_id` int(11) NOT NULL AUTO_INCREMENT,
  `she_index` int(11) NOT NULL DEFAULT '0',
  `she_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`she_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.provinces
CREATE TABLE IF NOT EXISTS `provinces` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `provinces` char(50) DEFAULT NULL,
  `other` char(50) DEFAULT NULL,
  PRIMARY KEY (`pro_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.users
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT '3',
  `user_fullname` char(50) DEFAULT NULL,
  `user_sex` char(50) DEFAULT NULL,
  `user_login` char(50) DEFAULT NULL,
  `user_email` char(50) DEFAULT NULL,
  `user_fb` char(50) DEFAULT NULL,
  `user_phone` char(50) DEFAULT NULL,
  `user_pass` char(50) DEFAULT NULL,
  `user_pic` char(50) DEFAULT NULL,
  `user_create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`user_id`),
  KEY `FK_users_group` (`group_id`),
  CONSTRAINT `FK_users_group` FOREIGN KEY (`group_id`) REFERENCES `users_groups` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.users_groups
CREATE TABLE IF NOT EXISTS `users_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` char(50) DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table vb_library.villages
CREATE TABLE IF NOT EXISTS `villages` (
  `vill_id` int(11) NOT NULL AUTO_INCREMENT,
  `com_id` int(11) NOT NULL DEFAULT '0',
  `villages` char(50) DEFAULT NULL,
  `other` char(50) DEFAULT NULL,
  PRIMARY KEY (`vill_id`),
  KEY `FK_villages_communes` (`com_id`),
  CONSTRAINT `FK_villages_communes` FOREIGN KEY (`com_id`) REFERENCES `communes` (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=831 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
